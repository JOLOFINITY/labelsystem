﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_2_unitMaster
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Me.pmain = New System.Windows.Forms.Panel()
		Me.llblrefresh = New System.Windows.Forms.LinkLabel()
		Me.llbladdSave = New System.Windows.Forms.LinkLabel()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.griditemList = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
		Me.label_textCounter = New System.Windows.Forms.Label()
		Me.txtprocessUnit = New System.Windows.Forms.TextBox()
		Me.lblbuildNo = New System.Windows.Forms.Label()
		Me.lblheaderSub = New System.Windows.Forms.Label()
		Me.llblhide = New System.Windows.Forms.LinkLabel()
		Me.llblmaximized = New System.Windows.Forms.LinkLabel()
		Me.lblclose = New System.Windows.Forms.LinkLabel()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.lblheader = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.pmain.SuspendLayout()
		Me.Panel1.SuspendLayout()
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'pmain
		'
		Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.White
		Me.pmain.Controls.Add(Me.llblrefresh)
		Me.pmain.Controls.Add(Me.llbladdSave)
		Me.pmain.Controls.Add(Me.Panel1)
		Me.pmain.Controls.Add(Me.label_textCounter)
		Me.pmain.Controls.Add(Me.txtprocessUnit)
		Me.pmain.Controls.Add(Me.lblbuildNo)
		Me.pmain.Controls.Add(Me.lblheaderSub)
		Me.pmain.Controls.Add(Me.llblhide)
		Me.pmain.Controls.Add(Me.llblmaximized)
		Me.pmain.Controls.Add(Me.lblclose)
		Me.pmain.Controls.Add(Me.Label1)
		Me.pmain.Controls.Add(Me.lblheader)
		Me.pmain.Controls.Add(Me.Label2)
		Me.pmain.Location = New System.Drawing.Point(2, 5)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(708, 683)
		Me.pmain.TabIndex = 0
		'
		'llblrefresh
		'
		Me.llblrefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblrefresh.AutoSize = True
		Me.llblrefresh.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblrefresh.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblrefresh.Location = New System.Drawing.Point(327, 167)
		Me.llblrefresh.Name = "llblrefresh"
		Me.llblrefresh.Size = New System.Drawing.Size(119, 19)
		Me.llblrefresh.TabIndex = 13
		Me.llblrefresh.TabStop = True
		Me.llblrefresh.Text = "Refresh...."
		'
		'llbladdSave
		'
		Me.llbladdSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llbladdSave.AutoSize = True
		Me.llbladdSave.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llbladdSave.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llbladdSave.Location = New System.Drawing.Point(467, 167)
		Me.llbladdSave.Name = "llbladdSave"
		Me.llbladdSave.Size = New System.Drawing.Size(229, 19)
		Me.llbladdSave.TabIndex = 12
		Me.llbladdSave.TabStop = True
		Me.llbladdSave.Text = "Add / Save to List...."
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.Controls.Add(Me.griditemList)
		Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Panel1.Location = New System.Drawing.Point(3, 207)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(702, 473)
		Me.Panel1.TabIndex = 11
		'
		'griditemList
		'
		Me.griditemList.AllowUserToAddRows = False
		Me.griditemList.AllowUserToDeleteRows = False
		Me.griditemList.AllowUserToResizeColumns = False
		Me.griditemList.AllowUserToResizeRows = False
		Me.griditemList.BackgroundColor = System.Drawing.Color.White
		Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
		Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
		Me.griditemList.ColumnHeadersHeight = 36
		Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
		DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.griditemList.DefaultCellStyle = DataGridViewCellStyle2
		Me.griditemList.Dock = System.Windows.Forms.DockStyle.Fill
		Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.griditemList.EnableHeadersVisualStyles = False
		Me.griditemList.Location = New System.Drawing.Point(0, 0)
		Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
		Me.griditemList.MultiSelect = False
		Me.griditemList.Name = "griditemList"
		Me.griditemList.ReadOnly = True
		Me.griditemList.RowHeadersVisible = False
		Me.griditemList.RowTemplate.Height = 30
		Me.griditemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.griditemList.ShowCellErrors = False
		Me.griditemList.ShowCellToolTips = False
		Me.griditemList.ShowEditingIcon = False
		Me.griditemList.ShowRowErrors = False
		Me.griditemList.Size = New System.Drawing.Size(702, 473)
		Me.griditemList.TabIndex = 1
		'
		'Column1
		'
		Me.Column1.HeaderText = "Remove"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		'
		'label_textCounter
		'
		Me.label_textCounter.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.label_textCounter.Location = New System.Drawing.Point(539, 93)
		Me.label_textCounter.Name = "label_textCounter"
		Me.label_textCounter.Size = New System.Drawing.Size(159, 24)
		Me.label_textCounter.TabIndex = 9
		Me.label_textCounter.Text = "0 / 64"
		Me.label_textCounter.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'txtprocessUnit
		'
		Me.txtprocessUnit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.txtprocessUnit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
		Me.txtprocessUnit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
		Me.txtprocessUnit.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtprocessUnit.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtprocessUnit.Location = New System.Drawing.Point(39, 122)
		Me.txtprocessUnit.MaxLength = 64
		Me.txtprocessUnit.Name = "txtprocessUnit"
		Me.txtprocessUnit.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.txtprocessUnit.Size = New System.Drawing.Size(659, 26)
		Me.txtprocessUnit.TabIndex = 8
		'
		'lblbuildNo
		'
		Me.lblbuildNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblbuildNo.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblbuildNo.Location = New System.Drawing.Point(572, 47)
		Me.lblbuildNo.Name = "lblbuildNo"
		Me.lblbuildNo.Size = New System.Drawing.Size(128, 20)
		Me.lblbuildNo.TabIndex = 7
		Me.lblbuildNo.Text = "Build.210713.01"
		Me.lblbuildNo.TextAlign = System.Drawing.ContentAlignment.BottomRight
		'
		'lblheaderSub
		'
		Me.lblheaderSub.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblheaderSub.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheaderSub.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.lblheaderSub.Location = New System.Drawing.Point(35, 47)
		Me.lblheaderSub.Name = "lblheaderSub"
		Me.lblheaderSub.Size = New System.Drawing.Size(531, 20)
		Me.lblheaderSub.TabIndex = 5
		Me.lblheaderSub.Text = "• Maintenance [ Add / Remove ]"
		Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
		'
		'llblhide
		'
		Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblhide.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblhide.Location = New System.Drawing.Point(581, 9)
		Me.llblhide.Name = "llblhide"
		Me.llblhide.Size = New System.Drawing.Size(37, 25)
		Me.llblhide.TabIndex = 2
		Me.llblhide.TabStop = True
		Me.llblhide.Text = "◣"
		Me.llblhide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.llblhide.Visible = False
		'
		'llblmaximized
		'
		Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblmaximized.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblmaximized.Location = New System.Drawing.Point(622, 9)
		Me.llblmaximized.Name = "llblmaximized"
		Me.llblmaximized.Size = New System.Drawing.Size(37, 25)
		Me.llblmaximized.TabIndex = 1
		Me.llblmaximized.TabStop = True
		Me.llblmaximized.Text = "☐"
		Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.llblmaximized.Visible = False
		'
		'lblclose
		'
		Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblclose.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblclose.Location = New System.Drawing.Point(663, 9)
		Me.lblclose.Name = "lblclose"
		Me.lblclose.Size = New System.Drawing.Size(37, 25)
		Me.lblclose.TabIndex = 1
		Me.lblclose.TabStop = True
		Me.lblclose.Text = "✕"
		Me.lblclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label1
		'
		Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label1.BackColor = System.Drawing.Color.DimGray
		Me.Label1.Location = New System.Drawing.Point(0, 72)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(710, 6)
		Me.Label1.TabIndex = 0
		'
		'lblheader
		'
		Me.lblheader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheader.Location = New System.Drawing.Point(10, 9)
		Me.lblheader.Name = "lblheader"
		Me.lblheader.Size = New System.Drawing.Size(563, 60)
		Me.lblheader.TabIndex = 6
		Me.lblheader.Text = "P R O C E S S / U N I T   M A S T E R"
		'
		'Label2
		'
		Me.Label2.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(11, 93)
		Me.Label2.Name = "Label2"
		Me.Label2.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label2.Size = New System.Drawing.Size(451, 24)
		Me.Label2.TabIndex = 10
		Me.Label2.Text = "PROCESS / UNIT :"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'vw_2_unitMaster
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.RoyalBlue
		Me.ClientSize = New System.Drawing.Size(712, 690)
		Me.Controls.Add(Me.pmain)
		Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_2_unitMaster"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ITEM / PRODUCT MASTER"
		Me.pmain.ResumeLayout(False)
		Me.pmain.PerformLayout()
		Me.Panel1.ResumeLayout(False)
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
    Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
    Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
    Friend WithEvents lblbuildNo As System.Windows.Forms.Label
    Friend WithEvents lblheaderSub As System.Windows.Forms.Label
    Friend WithEvents lblheader As System.Windows.Forms.Label
    Friend WithEvents txtprocessUnit As System.Windows.Forms.TextBox
    Friend WithEvents label_textCounter As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents griditemList As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents llbladdSave As System.Windows.Forms.LinkLabel
    Friend WithEvents llblrefresh As System.Windows.Forms.LinkLabel
End Class
