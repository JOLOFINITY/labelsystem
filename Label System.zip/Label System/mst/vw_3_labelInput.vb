﻿Imports System.Runtime.InteropServices
Public Class vw_3_labelInput
#Region "MOVING"
    Public Const WM_NCLBUTTONDOWN As Integer = 161
    Public Const HT_CAPTION As Integer = 2

    <DllImportAttribute("User32.dll")> _
    Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
    End Function
    <DllImportAttribute("User32.dll")> _
    Public Shared Function ReleaseCapture() As Boolean
    End Function

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown, lblheader.MouseDown, lblheaderSub.MouseDown, lblbuildNo.MouseDown
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
        End If
    End Sub

    Private Const SM_CXSCREEN As Integer = 0
    Private Const SM_CYSCREEN As Integer = 1
    Private Shared HWND_TOP As IntPtr = IntPtr.Zero
    Private Const SWP_SHOWWINDOW As Integer = 64

    Private winState As FormWindowState
    Private brdStyle As FormBorderStyle
    Private isTopMost As Boolean
    Private isBounds As Rectangle

    <DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
    Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

    End Function
    <DllImport("user32.dll")>
    Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

    End Sub
    Public Shared ReadOnly Property ScreenX As Integer
        Get
            Return GetSystemMetrics(SM_CXSCREEN)
        End Get
    End Property

    Public Shared ReadOnly Property ScreenY As Integer
        Get
            Return GetSystemMetrics(SM_CYSCREEN)
        End Get
    End Property

    Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
        SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
    End Sub

    Private IsMaximized As Boolean = False
    Public Sub Maximize(ByVal targetForm As Form)
        If Not IsMaximized Then
            IsMaximized = True
            Save(targetForm)
            targetForm.WindowState = FormWindowState.Maximized
            targetForm.FormBorderStyle = FormBorderStyle.None
            targetForm.TopMost = True
            SetWinFullScreen(targetForm.Handle)
        End If
    End Sub
    Public Sub Save(ByVal targetForm As Form)
        winState = targetForm.WindowState
        brdStyle = targetForm.FormBorderStyle
        isTopMost = targetForm.TopMost
        isBounds = targetForm.Bounds
    End Sub
    Public Sub Restore(ByVal targetForm As Form)
        targetForm.WindowState = winState
        targetForm.FormBorderStyle = brdStyle
        targetForm.TopMost = isTopMost
        targetForm.Bounds = isBounds
        IsMaximized = False
    End Sub

    Private Sub me_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        If WindowState = FormWindowState.Maximized Then
            Maximize(Me)
        Else
            'Restore(Me)
            If llblmaximized.Text = "☒" Then
                llblmaximized.Text = "☐"
            End If
        End If
    End Sub
    Private Sub lblclose_MouseEnter(sender As Object, e As EventArgs) Handles lblclose.MouseEnter, llblmaximized.MouseEnter
        Dim llbl As LinkLabel = sender

        llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size + 2, FontStyle.Bold)
    End Sub

    Private Sub lblclose_MouseLeave(sender As Object, e As EventArgs) Handles lblclose.MouseLeave, llblmaximized.MouseLeave
        Dim llbl As LinkLabel = sender

        llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size - 2, FontStyle.Regular)
    End Sub

    Private Sub llblmaximized_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblmaximized.LinkClicked
        If llblmaximized.Text = "☐" Then
            llblmaximized.Text = "☒"
            WindowState = FormWindowState.Maximized
            Maximize(Me)
        Else
            llblmaximized.Text = "☐"
            WindowState = FormWindowState.Normal
            'Restore(Me)
        End If
    End Sub
    Private Sub lblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblclose.LinkClicked
        Dispose()
    End Sub
    Private Sub llblhide_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblhide.LinkClicked
        WindowState = FormWindowState.Minimized
    End Sub
#End Region
    Private mst_items As New DataTable("result")
    Private Sub cboitems_KeyPress(sender As Object, e As KeyPressEventArgs) Handles _
        cboitems.KeyPress, _
        cbocondition.KeyPress, _
        cbotenure.KeyPress, _
        cboterm.KeyPress, _
        cboquantity.KeyPress, _
        cboprocess.KeyPress, _
        cbounit.KeyPress, _
        cboemployee.KeyPress, _
        cbomanager.KeyPress, _
        cboremarks.KeyPress

        e.KeyChar = e.KeyChar.ToString.ToUpper

        If sender.Name = cboquantity.Name Then
            Dim KeyAscii As Integer = Asc(e.KeyChar)
            Select Case KeyAscii
                Case 8, 27, 48 To 57, 9
                Case Else
                    KeyAscii = 0
            End Select

            If KeyAscii = 0 Then
                e.Handled = True
            Else
                e.Handled = False
            End If
        End If
    End Sub

    Private Sub vw_3_labelInput_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Call get_itemListA(cboitems, mst_items)

        Call tableConditionSet(cbocondition, cboterm, cbostorage, cboprocess, cbounit)

        Call get_itemListC(griditemList)

		dtTimeIn.Value = DateAndTime.Now.ToString("yyyy/MM/dd 07:00:00")

		With My.Settings
			cboemployee.Text = .nameOfEmployee
			cbomanager.Text = .nameOfManager
		End With
    End Sub

    Private tConditionExist As New DataTable("result")
    Private Sub cboitems_TextChanged(sender As Object, e As EventArgs) Handles cboitems.TextChanged
        cbocondition.Text = String.Empty
        cbotenure.Text = String.Empty
        cboterm.Text = Nothing
        cboquantity.Text = String.Empty
        cboprocess.Text = String.Empty
        cbounit.Text = String.Empty
        cbostorage.Text = String.Empty

        dateProduction.Checked = False
        lblproduction.Text = String.Empty

        dtTimeIn.Text = String.Empty

        'cboemployee.Text = String.Empty
        'cbomanager.Text = String.Empty
        'cboremarks.Text = String.Empty

        _exec_gridSearch(griditemList, cboitems.Text)
    End Sub
    Private Sub cboitems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboitems.SelectedIndexChanged
        If cboitems.Text <> String.Empty Then
            Call tableConditionList(cboitems.Text, tConditionExist)

            If tConditionExist.Rows.Count >= 1 Then
                With cbocondition
                    .Items.Clear()

                    For i = 0 To tConditionExist.Rows.Count - 1
                        .Items.Add(tConditionExist.Rows(i)("Condition").ToString.Trim)
                    Next
                End With
            End If
        End If
    End Sub
    Private Sub cbocondition_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbocondition.SelectedIndexChanged
        If cbocondition.Text <> String.Empty Then
         
            Dim filtered = tConditionExist.Select("`Name` = '" & cboitems.Text & "' AND `Condition` = '" & cbocondition.Text & "'")

            If filtered.Length = 1 Then
                cbotenure.Text = filtered.ToArray(0)("Tenure").ToString.Trim
                cboterm.Text = filtered.ToArray(0)("Term").ToString.Trim
                cboprocess.Text = filtered.ToArray(0)("Process").ToString.Trim
                cbounit.Text = filtered.ToArray(0)("Unit").ToString.Trim
                cbostorage.Text = filtered.ToArray(0)("Storage").ToString.Trim

                If filtered.ToArray(0)("Production").ToString.Trim = 1 Then
                    dateProduction.Checked = True
                    lblproduction.Text = "Enter the PRODUCTION DATE."
                    'dateProduction.Focus()
                Else
                    dateProduction.Checked = False
                    lblproduction.Text = "** Production Date is not Required."
                    'cboquantity.Focus()
                End If

                cboquantity.Focus()
            End If
        End If
    End Sub

    Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
        If e.RowIndex >= 0 And e.ColumnIndex = 0 Then
            With griditemList
                Dim strItem As String = .Rows(e.RowIndex).Cells(1).Value.ToString.Trim
                Dim strCon As String = .Rows(e.RowIndex).Cells(2).Value.ToString.Trim

                cboitems.Text = strItem
                cbocondition.Text = strCon
            End With
        End If
    End Sub

    Private Sub cboitems_Enter(sender As Object, e As EventArgs) Handles _
        dateProduction.Enter, _
        cbounit.Enter, _
        cboterm.Enter, _
        cbotenure.Enter, _
        cbostorage.Enter, _
        cboquantity.Enter, _
        cboprocess.Enter, _
        cboitems.Enter, _
        cbocondition.Enter, _
        dtTimeIn.Enter, _
        cboemployee.Enter, _
        cboremarks.Enter, _
        cbomanager.Enter

        Dim strTag As String = sender.Tag

        If strTag = "A" Then
            lblA.BackColor = Color.Lime

        ElseIf strTag = "B" Then
            lblB.BackColor = Color.Lime

        ElseIf strTag = "C" Then
            lblC.BackColor = Color.Lime

        ElseIf strTag = "D" Then
            lblD.BackColor = Color.Lime

        ElseIf strTag = "E" Then
            lblE.BackColor = Color.Lime

        ElseIf strTag = "F" Then
            lblF.BackColor = Color.Lime

        ElseIf strTag = "G" Then
            lblG.BackColor = Color.Lime

        ElseIf strTag = "H" Then
            lblH.BackColor = Color.Lime

        ElseIf strTag = "I" Then
            lblI.BackColor = Color.Lime

            If cbotenure.Text <> String.Empty Then
                If cboterm.Text = "MINUTES" Then
                    lblusedBy.Text = dtTimeIn.Value.AddMinutes(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")

                ElseIf cboterm.Text = "HOUR(S)" Then
                    lblusedBy.Text = dtTimeIn.Value.AddHours(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")

                ElseIf cboterm.Text = "DAY(S)" Then
                    lblusedBy.Text = dtTimeIn.Value.AddDays(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")

                ElseIf cboterm.Text = "WEEK(S)" Then
                    Dim toDays = Decimal.Parse(cbotenure.Text) * 7.0
                    lblusedBy.Text = dtTimeIn.Value.AddDays(toDays).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")

                ElseIf cboterm.Text = "MONTH(S)" Then
                    lblusedBy.Text = dtTimeIn.Value.AddMonths(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")

                ElseIf cboterm.Text = "YEAR(S)" Then
                    lblusedBy.Text = dtTimeIn.Value.AddYears(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")

                End If
            End If

        ElseIf strTag = "J" Then
            lblJ.BackColor = Color.Lime

        ElseIf strTag = "K" Then
            lblK.BackColor = Color.Lime

        ElseIf strTag = "L" Then
            lblL.BackColor = Color.Lime

        End If

    End Sub
    Private Sub cboitems_Leave(sender As Object, e As EventArgs) Handles _
        dateProduction.Leave, _
        cbounit.Leave, _
        cboterm.Leave, _
        cbotenure.Leave, _
        cbostorage.Leave, _
        cboquantity.Leave, _
        cboprocess.Leave, _
        cboitems.Leave, _
        cbocondition.Leave, _
        dtTimeIn.Leave, _
        cboemployee.Leave, _
        cbomanager.Leave, _
        cboremarks.Leave

        Dim strTag As String = sender.Tag

        If strTag = "A" Then
            lblA.BackColor = Color.Firebrick

        ElseIf strTag = "B" Then
            lblB.BackColor = Color.Firebrick

        ElseIf strTag = "C" Then
            lblC.BackColor = Color.Firebrick

        ElseIf strTag = "D" Then
            lblD.BackColor = Color.Firebrick

        ElseIf strTag = "E" Then
            lblE.BackColor = Color.Firebrick

        ElseIf strTag = "F" Then
            lblF.BackColor = Color.Firebrick

        ElseIf strTag = "G" Then
            lblG.BackColor = Color.Firebrick

        ElseIf strTag = "H" Then
            lblH.BackColor = Color.Firebrick

        ElseIf strTag = "I" Then
            lblI.BackColor = Color.Firebrick

        ElseIf strTag = "J" Then
            lblJ.BackColor = Color.Firebrick

        ElseIf strTag = "K" Then
            lblK.BackColor = Color.Firebrick

        ElseIf strTag = "L" Then
            lblL.BackColor = Color.Firebrick

        End If

    End Sub

    Private Sub dtTimeIn_ValueChanged(sender As Object, e As EventArgs) Handles dtTimeIn.ValueChanged, cbotenure.TextChanged, cboterm.SelectedIndexChanged
        UseByUntil()
    End Sub

    Public Sub UseByUntil()
        If cbotenure.Text <> String.Empty Then
            Dim days As String = String.Empty
            If cboterm.Text = "MINUTES" Then
                lblusedBy.Text = dtTimeIn.Value.AddMinutes(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
                lblusedBy.Tag = dtTimeIn.Value.AddMinutes(cbotenure.Text)
                days = dtTimeIn.Value.AddMinutes(cbotenure.Text).ToString("dddd")

            ElseIf cboterm.Text = "HOUR(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddHours(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
                lblusedBy.Tag = dtTimeIn.Value.AddHours(cbotenure.Text)
                days = dtTimeIn.Value.AddHours(cbotenure.Text).ToString("dddd")

            ElseIf cboterm.Text = "DAY(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddDays(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
                lblusedBy.Tag = dtTimeIn.Value.AddDays(cbotenure.Text)
                days = dtTimeIn.Value.AddDays(cbotenure.Text).ToString("dddd")

            ElseIf cboterm.Text = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(cbotenure.Text) * 7.0
                lblusedBy.Text = dtTimeIn.Value.AddDays(toDays).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
                lblusedBy.Tag = dtTimeIn.Value.AddDays(toDays)
                days = dtTimeIn.Value.AddDays(toDays).ToString("dddd")

            ElseIf cboterm.Text = "MONTH(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddMonths(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
                lblusedBy.Tag = dtTimeIn.Value.AddMonths(cbotenure.Text)
                days = dtTimeIn.Value.AddMonths(cbotenure.Text).ToString("dddd")

            ElseIf cboterm.Text = "YEAR(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddYears(cbotenure.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
                lblusedBy.Tag = dtTimeIn.Value.AddYears(cbotenure.Text)
                days = dtTimeIn.Value.AddYears(cbotenure.Text).ToString("dddd")

            End If

            lbldays.Text = String.Empty
            For Each ch In days
                lbldays.Text = String.Format("{0}{1}{2}", lbldays.Text, vbNewLine, ch).ToUpper()
            Next

        End If
    End Sub

    Private Sub lbldays_Click(sender As Object, e As EventArgs) Handles lbldays.Click

    End Sub

    Private Sub lbldays_TextChanged(sender As Object, e As EventArgs) Handles lbldays.TextChanged
		If cbotenure.Text <> String.Empty Then
			If dtTimeIn.Value.ToString("dddd").ToUpper = "MONDAY" Then
				lbldays.BackColor = Color.DarkBlue
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "TUESDAY" Then
				lbldays.BackColor = Color.Goldenrod
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "WEDNESDAY" Then
				lbldays.BackColor = Color.Firebrick
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "THURSDAY" Then
				lbldays.BackColor = Color.SaddleBrown
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "FRIDAY" Then
				lbldays.BackColor = Color.ForestGreen
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "SATURDAY" Then
				lbldays.BackColor = Color.DarkOrange
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "SUNDAY" Then
				lbldays.BackColor = Color.Black
			Else
				'lbldays.BackColor = Color.DimGray
			End If
		End If
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnsave.Click, btnsavePrint.Click
        Dim btn As Button = sender

		saveRecord(CBool(btn.Tag))
	End Sub
	Private Sub saveRecord(ByRef toPrint As Boolean)
		If cboitems.SelectedIndex = -1 Then
			MessageBox.Show("Please Select Item and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
			cboitems.SelectAll() : cboitems.Focus()
		ElseIf cbocondition.SelectedIndex = -1 Then
			MessageBox.Show("Please select Condition and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
			cbocondition.SelectAll() : cbocondition.Focus()
		ElseIf (cboquantity.Text = String.Empty) Then
			MessageBox.Show("Quantity Required! and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
			cboquantity.SelectAll() : cboquantity.Focus()
		Else
			Dim strDay As String = lbldays.Text
			Dim itemName As String = cboitems.Text
			Dim productionDate As Date = dateProduction.Value.Date
			Dim qty As Decimal = Decimal.Parse(IIf(cboquantity.Text = String.Empty, 0, cboquantity.Text))
			Dim shelfLife As String = String.Format("{0} {1}", cbotenure.Text, cboterm.Text)
			Dim timeIn As DateTime = dtTimeIn.Value
			Dim employee As String = cboemployee.Text
			Dim manager As String = cbomanager.Text
			Dim remarks As String = cboremarks.Text
			Dim useBy As String = lblusedBy.Tag
			Dim timeAMPM As String = DateTime.Parse(lblusedBy.Tag).ToString("tt")

			With My.Settings
				.nameOfEmployee = employee
				.nameOfManager = manager
				.remarks = cboremarks.Text
				.Save()
			End With
		
			AddForPrint(strDay, itemName, productionDate, qty, shelfLife, timeIn, employee, manager, remarks, useBy, timeAMPM)

			If toPrint Then

			End If

			MessageBox.Show("Record successfully save, Printing can be done later.", "Record Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)

			cboitems.Text = String.Empty
		End If
	End Sub
End Class