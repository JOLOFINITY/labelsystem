﻿Public Class vw_5_settings
	Private Sub vw_5_settings_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
		Dispose()
	End Sub
	Private Sub vw_5_settings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		Call getSettings()
	End Sub
	Private Sub getSettings()

		With gridsettings
			.Rows.Clear()
			.Rows.Add()
			.Rows(.Rows.Count - 1).Cells(0).Value = "EDIT"
			.Rows(.Rows.Count - 1).Cells(1).Value = "Connection"
			.Rows(.Rows.Count - 1).Cells(2).Value = My.Settings.connection

			.Rows.Add()
			.Rows(.Rows.Count - 1).Cells(0).Value = "EDIT"
			.Rows(.Rows.Count - 1).Cells(1).Value = "POS Printer"
			.Rows(.Rows.Count - 1).Cells(2).Value = My.Settings.defaultPrinter

			.ClearSelection()
		End With
	End Sub
	Private Sub gridsettings_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridsettings.CellClick
		If e.RowIndex >= 0 Then
			With gridsettings

				Dim boolSAVE As Boolean = False

				For i = 0 To .Rows.Count - 1
					If .Rows(i).Cells(0).Value = "SAVE" Then
						boolSAVE = True
						Exit For
					End If
				Next

				If boolSAVE Then
					If .Rows(e.RowIndex).Cells(0).Value = "SAVE" Then
						.Rows(e.RowIndex).Cells(0).Value = "EDIT"
						.Rows(e.RowIndex).Cells(2).Value = txtvalues.Text

						If .Rows(e.RowIndex).Cells(1).Value = "Connection" Then
							My.Settings.connection = txtvalues.Text

						ElseIf .Rows(e.RowIndex).Cells(1).Value = "POS Printer" Then
							My.Settings.defaultPrinter = txtvalues.Text

						End If
						My.Settings.Save()

						.ClearSelection()
						txtvalues.Clear()

					Else
						.ClearSelection()
					End If
				Else
					.Rows(e.RowIndex).Cells(0).Value = "SAVE"
					.ClearSelection()

					txtvalues.Text = .Rows(e.RowIndex).Cells(2).Value
					txtvalues.SelectAll()
					txtvalues.Focus()
				End If
			End With
		End If
	End Sub
End Class