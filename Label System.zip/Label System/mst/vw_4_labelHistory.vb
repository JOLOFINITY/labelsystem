﻿Imports System.Runtime.InteropServices
Public Class vw_4_labelHistory
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown, lblheader.MouseDown, lblheaderSub.MouseDown, lblbuildNo.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub

	Private Sub me_Resize(sender As Object, e As EventArgs) Handles Me.Resize
		If WindowState = FormWindowState.Maximized Then
			Maximize(Me)
		Else
			'Restore(Me)
			If llblmaximized.Text = "☒" Then
				llblmaximized.Text = "☐"
			End If
		End If
	End Sub
	Private Sub lblclose_MouseEnter(sender As Object, e As EventArgs) Handles lblclose.MouseEnter, llblmaximized.MouseEnter
		Dim llbl As LinkLabel = sender

		llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size + 2, FontStyle.Bold)
	End Sub

	Private Sub lblclose_MouseLeave(sender As Object, e As EventArgs) Handles lblclose.MouseLeave, llblmaximized.MouseLeave
		Dim llbl As LinkLabel = sender

		llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size - 2, FontStyle.Regular)
	End Sub

	Private Sub llblmaximized_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblmaximized.LinkClicked
		If llblmaximized.Text = "☐" Then
			llblmaximized.Text = "☒"
			WindowState = FormWindowState.Maximized
			Maximize(Me)
		Else
			llblmaximized.Text = "☐"
			WindowState = FormWindowState.Normal
			'Restore(Me)
		End If
	End Sub
	Private Sub lblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblclose.LinkClicked
		Dispose()
	End Sub
	Private Sub llblhide_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblhide.LinkClicked
		WindowState = FormWindowState.Minimized
	End Sub
#End Region
	Private Sub vw_4_labelHistory_Load(sender As Object, e As EventArgs) Handles MyBase.Load

	End Sub
	Private Sub vw_4_labelHistory_Shown(sender As Object, e As EventArgs) Handles Me.Shown

	End Sub

	Private Sub rbprint_CheckedChanged(sender As Object, e As EventArgs) Handles rbprint.CheckedChanged
		Call getPrintLabelHistory(0, griditemList)
	End Sub
	Private Sub llblprint_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblprint.LinkClicked
		With griditemList
			For i = 0 To .Rows.Count - 1
				If rbprint.Checked Then
					.Rows(i).Cells(2).Value = False
					If .Rows(i).Cells(1).Value = True Then
						.Rows(i).Cells(1).Value = False
					Else
						.Rows(i).Cells(1).Value = True
					End If
				End If
			Next
		End With
	End Sub
	Private Sub rbprinted_CheckedChanged(sender As Object, e As EventArgs) Handles rbprinted.CheckedChanged
		Call getPrintLabelHistory(1, griditemList)
	End Sub

	Private Sub rbdeleted_CheckedChanged(sender As Object, e As EventArgs) Handles rbdeleted.CheckedChanged
		Call getPrintLabelHistory(2, griditemList)
	End Sub
	Private Sub llblprinted_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblprinted.LinkClicked
		With griditemList
			For i = 0 To .Rows.Count - 1
				If rbprint.Checked Or rbprinted.Checked Then
					.Rows(i).Cells(1).Value = False
					If .Rows(i).Cells(2).Value = True Then
						.Rows(i).Cells(2).Value = False
					Else
						.Rows(i).Cells(2).Value = True
					End If
				End If
			Next
		End With
	End Sub
	Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
		With griditemList
			If e.RowIndex >= 0 And e.ColumnIndex = 1 And rbprint.Checked Then
				.Rows(e.RowIndex).Cells(2).Value = False
				If .Rows(e.RowIndex).Cells(1).Value = True Then
					.Rows(e.RowIndex).Cells(1).Value = False
				Else
					.Rows(e.RowIndex).Cells(1).Value = True
				End If
			ElseIf e.RowIndex >= 0 And e.ColumnIndex = 2 And (rbprint.Checked Or rbprinted.Checked) Then
				.Rows(e.RowIndex).Cells(1).Value = False
				If .Rows(e.RowIndex).Cells(2).Value = True Then
					.Rows(e.RowIndex).Cells(2).Value = False
				Else
					.Rows(e.RowIndex).Cells(2).Value = True
				End If
			End If
		End With
	End Sub
	
	
	Private Sub btncommand_Click(sender As Object, e As EventArgs) Handles btncommand.Click
		With griditemList
			Using cReport As New rptLABELv001
				For i = 0 To griditemList.Rows.Count - 1
					If .Rows(i).Cells(2).Value = True Then
						Call updateLabelHistory(.Rows(i).Cells(15).Value, 2)
					ElseIf .Rows(i).Cells(1).Value = True Then
						REM FOR PRINTING
						cReport.DataSourceConnections.Clear()
						cReport.SetDataSource(getLabeltoPrint(.Rows(i).Cells(15).Value))
						cReport.PrintToPrinter(1, False, 0, 0)
						Application.DoEvents()
					End If
				Next
			End Using
		End With

		If rbprint.Checked Then
			Call getPrintLabelHistory(0, griditemList)
		ElseIf rbprinted.Checked Then
			Call getPrintLabelHistory(1, griditemList)
		Else
			Call getPrintLabelHistory(2, griditemList)
		End If
	End Sub

	
	
End Class