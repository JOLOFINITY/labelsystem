﻿Module mod_search
    Public Function _exec_gridSearch(ByRef grid As DataGridView, ByRef string_lookup As String) As DataGridView
        Dim st As New System.Text.StringBuilder()

        Dim tmp As DataTable = DirectCast(grid.DataSource, DataTable)

        For Each dgCol As DataGridViewColumn In grid.Columns
            If dgCol.ValueType IsNot Nothing Then
                If dgCol.ValueType.FullName.ToString() = "System.String" Then
                    Dim b As Boolean = (st.ToString() = "")

                    If b Then
                        st.Append(String.Format("[{0}] LIKE '%{1}%' ", dgCol.Name, string_lookup))
                    Else
                        st.Append(String.Format(" or [{0}] LIKE '%{1}%' ", dgCol.Name, string_lookup))
                    End If
                End If
            End If
        Next

        tmp.DefaultView.RowFilter = st.ToString()
        grid.ClearSelection()

        Return grid
    End Function
End Module
