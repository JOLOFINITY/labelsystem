﻿Imports System.IO

Module mod_onlineUpdate
	Public version As String = String.Empty
	Public updateVersion As String = String.Empty
	Public Sub initializedUpdater()
		If Directory.Exists(Application.StartupPath & "\_") = False Then Directory.CreateDirectory(Application.StartupPath & "\_")

		If File.Exists(Application.StartupPath & "\version.dll") = False Then IO.File.WriteAllText(Application.StartupPath & "\version.dll", "19880529.529") : Application.DoEvents()

		version = IO.File.ReadAllText(Application.StartupPath & "\version.dll")
	End Sub

	Public Function checkUpdate(ByRef wb As WebBrowser, ByRef projectName As String) As Boolean
		Try
			Dim address As String = "https://raw.githubusercontent.com/JOLOFINITY/" & projectName & "/main/README.md"
			wb.Navigate(address)

			Return True
		Catch ex As Exception
			Return False
		End Try
	End Function

	Public Sub updateFile(ByRef execName As String)
		Dim fileName = Application.StartupPath & "\updater.bat"

		Using sw As New StreamWriter(fileName)
			sw.WriteLine("@ECHO OFF")
			sw.WriteLine("")
			sw.WriteLine("TITLE Programmer In-Charge : Jose Lorenzo Punto (Sir JOLo)")
			sw.WriteLine("")
			sw.WriteLine("SETLOCAL")
			sw.WriteLine("CALL :setESC")
			sw.WriteLine("")
			sw.WriteLine("CLS")
			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m  S Y S T E M   C A L L   :   S Y S T E M   U P D A T E R   v . 1  %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m  P L E A S E   D O N ' T   C L O S E   T H I S   W I N D O W .  %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m Forcely Terminating " & "" & execName & "" & " for Updating!! %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")
			sw.WriteLine("TASKKILL /F /IM """ & "" & execName & "" & """ /T")
			sw.WriteLine("ECHO %ESC%[101;93m P R O C E S S   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("DEL """ & "" & execName & "" & """ ")
			sw.WriteLine("ECHO %ESC%[101;93m D E L E T I N G   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 2")

			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m U P D A T E R   W I L L   C O P Y   S O M E   F I L E S . .  %ESC%[1m")

			For Each f In Directory.GetFiles(Application.StartupPath & "\_\")
				Dim fileC As String = f.Split("\")(f.Split("\").Length - 1)

				sw.WriteLine("xcopy """ & f & """ """ & Application.StartupPath & "\" & "" & """ /S /Y")
			Next

			sw.WriteLine("TIMEOUT 5")

			sw.WriteLine("REN update.zip """ & "" & execName & "" & """ ")
			sw.WriteLine("ECHO %ESC%[101;93m D E L E T I N G   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m EXECUTING PROGRAM, PLEASE WAIT... %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")

			sw.WriteLine("DEL """ & "" & Application.StartupPath & "\_\update.zip" & "" & """ ")
			sw.WriteLine("ECHO %ESC%[101;93m D E L E T I N G   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("echo " & updateVersion & " > version.dll")
			sw.WriteLine("ECHO %ESC%[101;93m S A V I N G   V E R S I O N   U P D A T E ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("if not exist """ & "" & execName & "" & """ (")
			sw.WriteLine("msg " & My.User.Name & " /SERVER:" & My.Computer.Name & " /time:3 ""Program not found or failed to Copy, Call Local I.T. to fix the Problem!!!""")
			sw.WriteLine("GOTO EXIT0")
			sw.WriteLine(")")
			sw.WriteLine("")

			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("start /b """" cmd /c del ""%~f0""&exit /b")
			sw.WriteLine("")
			sw.WriteLine(":setESC")
			sw.WriteLine("for /F ""tokens=1,2 delims=#"" %%a in ('""prompt #$H#$E# & echo on & for %%b in (1) do rem""') do (")
			sw.WriteLine("  set ESC=%%b")
			sw.WriteLine("  exit /B 0")
			sw.WriteLine(")")
			sw.WriteLine(":EXIT0")
			sw.WriteLine("exit /B 0")
		End Using

		Dim start As New ProcessStartInfo
		start.FileName = fileName
		start.WindowStyle = ProcessWindowStyle.Normal
		start.CreateNoWindow = False

		Process.Start(start)
		End
	End Sub
	Public Sub getUpdate(ByRef projectName As String)
		Using p As Process = New Process()
			Dim pi As ProcessStartInfo = New ProcessStartInfo()
			pi.Arguments = "https://raw.githubusercontent.com/JOLOFINITY/" & projectName & "/main/update.zip --output """ & Application.StartupPath & "\_\update.zip" & """"
			pi.FileName = "curl.exe"
			pi.CreateNoWindow = False

			p.StartInfo = pi
			p.StartInfo.CreateNoWindow = False
			p.Start()
		End Using
	End Sub
End Module
