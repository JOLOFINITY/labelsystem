﻿Module mod_functions
	Public boolConnected As Boolean = False
	Public Sub _connectDB(Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys")
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()

				Connection.Close()
			End Using

			boolConnected = True
		Catch ex As Exception
			Call createErrorLogs(ex, "CONNECTION TEST.", connectionString)
			boolConnected = False
		End Try
	End Sub
	Private Sub _saveDATA(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys")
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()
				Using Comm = New MySqlCommand(query, Connection)
					Comm.ExecuteNonQuery()
				End Using
				Connection.Close()
			End Using
		Catch ex As Exception
			Call createErrorLogs(ex, query, connectionString)
		End Try
	End Sub
	Private Function _createTable(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys") As DataTable
		Dim temp As New DataTable
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()
				Using dA = New MySqlDataAdapter(query, Connection)
					Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
				End Using
				Connection.Close()
			End Using
		Catch ex As Exception
			Call createErrorLogs(ex, query, connectionString)
		End Try
		Return temp
	End Function

	Public Sub get_itemListA(ByRef cbo As ComboBox, ByRef result As DataTable)
		Dim query As String = _
			"SELECT `Item Code`,`Name` FROM `t_mst_items` ORDER BY `Name` ASC;"

		result = _createTable(query)

		With cbo
			.Items.Clear()

			For i = 0 To result.Rows.Count - 1
				.Items.Add(result.Rows(i)("Name").ToString.Trim)
			Next
		End With
	End Sub
	Public Sub get_itemListB(ByRef txt As TextBox, ByRef result As DataTable, ByRef grid As DataGridView)
		Dim query As String = _
			"SELECT `Name`,`Item Code` FROM `t_mst_items` ORDER BY `Name` ASC;"

		result = _createTable(query)

		With grid
			.DataSource = result
			.ClearSelection()

			.Columns(1).Width = .Width - 120 : .Columns(1).Frozen = True
			.Columns(2).Width = 0
		End With

		Dim suggestions As New AutoCompleteStringCollection

		For i = 0 To result.Rows.Count - 1
			suggestions.Add(result.Rows(i)("Name").ToString.Trim)
		Next

		With txt
			.AutoCompleteCustomSource = suggestions
			.AutoCompleteMode = AutoCompleteMode.SuggestAppend
			.AutoCompleteSource = AutoCompleteSource.CustomSource
		End With
	End Sub
	Public Sub get_itemListC(ByRef grid As DataGridView)
		Dim query As String = _
			"SELECT " & vbNewLine & _
			"`mst`.`Name`, " & vbNewLine & _
			"`lst`.`Condition`, " & vbNewLine & _
			"`lst`.`Tenure`,`lst`.`Term`,`lst`.`Storage`, " & vbNewLine & _
			"`lst`.`Quantity`, " & vbNewLine & _
			"`lst`.`Process`,`lst`.`Unit`, " & vbNewLine & _
			"`lst`.`ID`,`lst`.`Item Code` " & vbNewLine & _
			"FROM `t_item_list` `lst` LEFT JOIN " & vbNewLine & _
			"`t_mst_items` `mst` ON `mst`.`Item Code` = `lst`.`Item Code` " & vbNewLine & _
			"ORDER BY CASE " & vbNewLine & _
			"WHEN `lst`.`Term` = 'N/A' THEN 99 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'EOD' THEN 1 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'MINUTES' THEN 2 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'HOUR(S)' THEN 3 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'DAY(S)' THEN 4 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'WEEK(S)' THEN 5 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'MONTH(S)' THEN 6 " & vbNewLine & _
			"WHEN `lst`.`Term` = 'YEAR(S)' THEN 7 " & vbNewLine & _
			"END ASC , `Storage` ASC;"

		Dim result = _createTable(query)

		With grid
			.DataSource = result
			.ClearSelection()

			.Columns(0).Width = 80
			.Columns(1).Width = .Width / 2.8 : .Columns(1).Frozen = True
			.Columns(2).Width = 0
			.Columns(3).Width = 70
			.Columns(4).Width = 90
			.Columns(5).Width = 200
			.Columns(6).Width = 70
		End With
	End Sub
	Public Function check_itemExist(ByRef name As String) As Boolean
		Dim query As String = _
			"SELECT `Name`,`Item Code` FROM `t_mst_items` WHERE `Name` = '" & name & "';"

		Dim result = _createTable(query)

		If result.Rows.Count = 0 Then
			Return False
		Else
			Return True
		End If
	End Function
	Public Function check_processUnitExist(ByRef name As String) As Boolean
		Dim query As String = _
			"SELECT `Process / Unit` FROM `t_mst_unit` WHERE `Process / Unit` = '" & name & "';"

		Dim result = _createTable(query)

		If result.Rows.Count = 0 Then
			Return False
		Else
			Return True
		End If
	End Function
#Region "ITEM MAINTENANCE"
	Public Sub additem(ByRef itemName As String)
		_saveDATA("INSERT INTO `t_mst_items`(`Item Code`,`Name`) VALUES(UPPER(LEFT(UUID(),8)),'" & itemName & "');")

		MessageBox.Show("Product successfully added, List is now updated!", "Item Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)
	End Sub
	Public Sub removeitem(ByRef itemCode As String)
		_saveDATA("DELETE FROM `t_mst_items` WHERE `Item Code` = '" & itemCode & "';")

		MessageBox.Show("Product successfully remove from DATABASE, List is now updated!", "Item/Product Deleted.", MessageBoxButtons.OK, MessageBoxIcon.Information)
	End Sub

	Public Sub addProcessUnit(ByRef processUnit As String)
		_saveDATA("INSERT INTO `t_mst_unit`(`No`,`Process / Unit`) VALUES((SELECT (`x`.`No`+1) `No` FROM `t_mst_unit` `x` WHERE `x`.`No` <> 999 ORDER BY `x`.`No` DESC LIMIT 1),'" & processUnit & "');")

		MessageBox.Show("Process/Unit successfully added, List is now updated!", "Process/Unit Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)
	End Sub
	Public Sub removeProcessUnit(ByRef idNo As String)
		_saveDATA("DELETE FROM `t_mst_unit` WHERE `No` = '" & idNo & "';")

		MessageBox.Show("Process/Unit successfully remove from DATABASE, List is now updated!", "Process/Unit Deleted.", MessageBoxButtons.OK, MessageBoxIcon.Information)
	End Sub
#End Region

	Public Function tableConditionList(ByRef itemName As String, ByRef tableExist As DataTable) As DataTable
		tableExist = New DataTable

		tableExist = _createTable( _
			"SELECT " & vbNewLine & _
			"`mst`.`Name`, " & vbNewLine & _
			"`lst`.`Condition`, " & vbNewLine & _
			"`lst`.`Tenure`,`lst`.`Term`,`lst`.`Storage`, " & vbNewLine & _
			"`lst`.`Quantity`, " & vbNewLine & _
			"`lst`.`Process`,`lst`.`Unit`, " & vbNewLine & _
			"`lst`.`ID`,`lst`.`Item Code`, " & vbNewLine & _
			"`mst`.`Production` " & vbNewLine & _
			"FROM `t_item_list` `lst` LEFT JOIN " & vbNewLine & _
			"`t_mst_items` `mst` ON `mst`.`Item Code` = `lst`.`Item Code` " & vbNewLine & _
			"WHERE `mst`.`Name` = '" & itemName & "' " & vbNewLine & _
			"ORDER BY `ID`;")

		'table = _createTable( _
		'    "SELECT `Condition`,`Term`,`Storage` FROM `t_item_list` " & vbNewLine & _
		'    "WHERE `Condition` = '" & condition & "' " & vbNewLine & _
		'    "GROUP BY `Term`,`Storage` " & vbNewLine & _
		'    "ORDER BY CASE " & vbNewLine & _
		'    "WHEN `Term` = 'N/A' THEN 99 " & vbNewLine & _
		'    "WHEN `Term` = 'EOD' THEN 1 " & vbNewLine & _
		'    "WHEN `Term` = 'MINUTES' THEN 2 " & vbNewLine & _
		'    "WHEN `Term` = 'HOUR(S)' THEN 3 " & vbNewLine & _
		'    "WHEN `Term` = 'DAY(S)' THEN 4 " & vbNewLine & _
		'    "WHEN `Term` = 'WEEK(S)' THEN 5 " & vbNewLine & _
		'    "WHEN `Term` = 'MONTH(S)' THEN 6 " & vbNewLine & _
		'    "WHEN `Term` = 'YEAR(S)' THEN 7 " & vbNewLine & _
		'    "END ASC , `Storage` ASC;")

		Return tableExist
	End Function
	Public Sub tableConditionSet( _
		ByRef condition As ComboBox, _
		ByRef term As ComboBox, _
		ByRef storage As ComboBox, _
		ByRef process As ComboBox, _
		ByRef unit As ComboBox)

		Dim result = _createTable( _
			"SELECT `lst`.`ID`,`lst`.`Item Code`, " & vbNewLine & _
			"`mst`.`Name`, " & vbNewLine & _
			"`lst`.`Condition`, " & vbNewLine & _
			"`lst`.`Tenure`,`lst`.`Term`,`lst`.`Storage`, " & vbNewLine & _
			"`lst`.`Quantity`, " & vbNewLine & _
			"`lst`.`Process`,`lst`.`Unit` " & vbNewLine & _
			"FROM `t_item_list` `lst` LEFT JOIN " & vbNewLine & _
			"`t_mst_items` `mst` ON `mst`.`Item Code` = `lst`.`Item Code` " & vbNewLine & _
			"ORDER BY `ID`;")

		condition.Items.Clear()
		With condition
			Dim filtered = result.DefaultView.ToTable("result", True, "Condition").Select("`Condition` <> '' AND `Condition` <> '-' AND `Condition` <> 'N/A'")
			For i = 0 To filtered.Length - 1
				.Items.Add(filtered.ToArray(i)(0).ToString.Trim)
			Next
		End With

		term.Items.Clear()
		With term
			Dim filtered = result.DefaultView.ToTable("result", True, "Term").Select("`Term` <> '' AND `Term` <> '-' AND `Term` <> 'N/A'")
			For i = 0 To filtered.Length - 1
				.Items.Add(filtered.ToArray(i)(0).ToString.Trim)
			Next
		End With

		storage.Items.Clear()
		With storage
			Dim filtered = result.DefaultView.ToTable("result", True, "Storage").Select("`Storage` <> '' AND `Storage` <> '-' AND `Storage` <> 'N/A'")
			For i = 0 To filtered.Length - 1
				.Items.Add(filtered.ToArray(i)(0).ToString.Trim)
			Next
		End With

		process.Items.Clear()
		With process
			Dim filtered = result.DefaultView.ToTable("result", True, "Process").Select("`Process` <> '' AND `Process` <> '-' AND `Process` <> 'N/A'")
			For i = 0 To filtered.Length - 1
				.Items.Add(filtered.ToArray(i)(0).ToString.Trim)
			Next
		End With

		unit.Items.Clear()
		With unit
			Dim filtered = result.DefaultView.ToTable("result", True, "Unit").Select("`Unit` <> '' AND `Unit` <> '-' AND `Unit` <> 'N/A'")
			For i = 0 To filtered.Length - 1
				.Items.Add(filtered.ToArray(i)(0).ToString.Trim)
			Next
		End With
	End Sub
	Public Function tableUnitMaster(Optional ByRef txt As TextBox = Nothing)
		Dim result As New DataTable

		result = _createTable(
			"SELECT `Process / Unit`,`No` FROM `t_mst_unit` " & vbNewLine &
			"ORDER BY CASE WHEN `Process / Unit` = 'N/A' THEN 1 ELSE 2 END DESC , `Process / Unit` ASC;")

		If IsNothing(txt) = False Then
			Dim suggestions As New AutoCompleteStringCollection

			For i = 0 To result.Rows.Count - 1
				suggestions.Add(result.Rows(i)("Process / Unit").ToString.Trim)
			Next

			With txt
				.AutoCompleteCustomSource = suggestions
				.AutoCompleteMode = AutoCompleteMode.SuggestAppend
				.AutoCompleteSource = AutoCompleteSource.CustomSource
			End With
		End If

		Return result
	End Function

#Region "Label Print Input"

	'Public Function CheckProduct(ItemName As String, Term As String, Storage As String) As DataTable
	'    Dim Query As String = "SELECT * FROM t_mst_items INNER JOIN t_item_list using(`Item Code`) WHERE `Name` = '{0}' AND `Term` = '{1}' AND `Storage` = '{2}' LIMIT 1"
	'    Dim result = _createTable(String.Format(Query, ItemName, Term, Storage))
	'    Return result
	'End Function

	'Public Sub AddProduct(ItemName As String, Condintion As String, Tenure As Decimal, Term As String, Storage As String, Quantity As Decimal, Process As String, Unit As String)
	'    Dim Query = "INSERT INTO `t_item_list` ( `Item Code`, `Codition`, `Tenure`, `Term`, `Storage`, `Quantity`, `Process`, `Unit` ) VALUES ('{0}', '{1}', {2}, '{3}', '{4}', {5}, '{6}', '{7}', '{8}' )"
	'    _saveDATA(String.Format(Query, ItemName, Condintion, Tenure, Term, Storage, Quantity, Process, Unit))
	'End Sub

	Public Sub AddForPrint(dy As String, ItemName As String, ProductionDate As Date, Qty As Decimal, ShelfLife As String, TimeIn As DateTime, Employee As String, Manager As String, Remarks As String, UsedBy As String, TimeAMPM As String)
		Dim Query As String = "INSERT INTO t_for_print "
		Query &= "(Day, ItemName, ProductionDate, Qty, ShelfLife, TimeIn, Employee, Manager, Remarks, UseBy, TimeAMPM ) "
		Query &= "VALUES ( '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}' )"
		_saveDATA(String.Format(Query, dy, ItemName, ProductionDate.ToString("yyyy-MM-dd"), Qty, ShelfLife, TimeIn.ToString("yyyy-MM-dd HH:mm:00"), Employee, Manager, Remarks, DateTime.Parse(UsedBy).ToString("yyyy-MM-dd HH:mm:00"), TimeAMPM))
	End Sub


	Public Sub getPrintLabelHistory(ByRef status As Integer, ByRef grid As DataGridView)
		Dim query As String =
			"SELECT " & vbNewLine & _
			"CASE WHEN `IsPrinted` = 0 THEN 'FOR PRINTING' " & vbNewLine & _
			"WHEN `IsPrinted` = 1 THEN 'PRINTED' " & vbNewLine & _
			"WHEN `IsPrinted` = 2 THEN 'DELETED' END `Status`, " & vbNewLine & _
			"`Day`, " & vbNewLine & _
			"`ItemName` `Item Name`, " & vbNewLine & _
			"`ProductionDate` `Date`, " & vbNewLine & _
			"`Qty` `Quantity`, " & vbNewLine & _
			"`ShelfLife` `Shelf Life`, " & vbNewLine & _
			"`TimeIn` `Time-IN`, " & vbNewLine & _
			"`Employee`,`Manager`,`Remarks`, " & vbNewLine & _
			"`UseBy` `Use By`, " & vbNewLine & _
			"`TimeAMPM` `AM/PM`, " & vbNewLine & _
			"`ID` " & vbNewLine & _
			"FROM `t_for_print` WHERE `IsPrinted` = " & status & "; " & vbNewLine
		Dim result = _createTable(query)

		With grid
			.DataSource = result
			.ClearSelection()
			Try
				.Columns(3).Width = 100
				.Columns(4).Width = 110
				.Columns(5).Width = 250
				.Columns(6).Width = 85 : .Columns(5).DefaultCellStyle.Format = "yyyy/MM/dd"
				.Columns(7).Width = 70
				.Columns(8).Width = 110
				.Columns(9).Width = 130 : .Columns(8).DefaultCellStyle.Format = "yyyy/MM/dd hh:mm tt"

				.Columns(10).Width = 110
				.Columns(11).Width = 110
				.Columns(12).Width = 110

				.Columns(13).Width = 130 : .Columns(12).DefaultCellStyle.Format = "yyyy/MM/dd hh:mm tt"
				.Columns(14).Width = 60
				.Columns(15).Width = 0

				.Columns(5).Frozen = True
			Catch ex As Exception

			End Try

		End With
	End Sub
	Public Sub updateLabelHistory(ByRef ID As Int64, ByRef status As Int64)
		_saveDATA("UPDATE `t_for_print` SET `IsPrinted` = " & status & " WHERE `ID` = '" & ID & "';")
	End Sub
	Public Function getLabeltoPrint(ByRef ID As Int64) As DataTable
		Dim query As String = _
			"SELECT " & vbNewLine & _
			"`ID`, " & vbNewLine & _
			"CASE WHEN `IsPrinted` = 0 THEN 'FOR PRINTING' " & vbNewLine & _
			"WHEN `IsPrinted` = 1 THEN 'PRINTED' " & vbNewLine & _
			"WHEN `IsPrinted` = 2 THEN 'DELETED' END `Status`, " & vbNewLine & _
			"`Day`, " & vbNewLine & _
			"`ItemName` `Item Name`, " & vbNewLine & _
			"DATE(`ProductionDate`) `Date`, " & vbNewLine & _
			"`Qty` `Quantity`, " & vbNewLine & _
			"`ShelfLife` `Shelf Life`, " & vbNewLine & _
			"`TimeIn` `Time-IN`, " & vbNewLine & _
			"`Employee`,`Manager`,`Remarks`, " & vbNewLine & _
			"`UseBy` `Use By`, " & vbNewLine & _
			"`TimeAMPM` `AM/PM` " & vbNewLine & _
			"FROM `t_for_print` WHERE `ID` = " & ID & ";"

		Return _createTable(query)
	End Function
#End Region

End Module
