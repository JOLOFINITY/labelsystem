﻿Imports System.Net
Module mod_ip
    Public Function publicIPAdd() As String

        Dim s As String = Dns.GetHostEntry(Dns.GetHostName()).AddressList _
    .Where(Function(a As IPAddress) Not a.IsIPv6LinkLocal AndAlso Not a.IsIPv6Multicast AndAlso Not a.IsIPv6SiteLocal) _
    .First() _
    .ToString()

        Return s
    End Function

End Module
