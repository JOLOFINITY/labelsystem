﻿Module mod_user_maintenance
    Private Sub _saveDATA(ByRef query As String)
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using Comm = New MySqlCommand(query, Connection)
                    Comm.ExecuteNonQuery()
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
    End Sub
    Private Function _createTable(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=root;password=master;database=db_lblsys") As DataTable
        Dim temp As New DataTable
        Try
            Using Connection = New MySqlConnection(connectionString)
                Connection.Open()
                Using dA = New MySqlDataAdapter(query, Connection)
                    Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, connectionString)
        End Try
        Return temp
    End Function
    Public Function getPrintCount() As Integer
        Dim tmp = _createTable("SELECT COUNT(`UID`) `Printed` FROM `db_lblsys`.`t_for_print`;")
        Return tmp.Rows(0)("Printed")
    End Function
    Public Sub resetData()
        _saveDATA("DELETE FROM `db_lblsys`.`t_for_print`;")
    End Sub
    Public Sub loadEmployees(cbo As ComboBox)
        Dim tmp = _createTable("SELECT `EMPLOYEE` FROM `t_for_print` WHERE `EMPLOYEE` NOT IN('','-') GROUP BY `EMPLOYEE` ORDER BY `EMPLOYEE` ASC;")
        With cbo
            .Items.Clear()
            For i = 0 To tmp.Rows.Count - 1
                cbo.Items.Add(tmp.Rows(i)(0).ToString.Trim)
            Next
        End With
    End Sub
    Public Sub loadManagers(cbo As ComboBox)
        Dim tmp = _createTable("SELECT `MANAGER` FROM `t_for_print` WHERE `MANAGER` NOT IN('','-') GROUP BY `MANAGER` ORDER BY `MANAGER` ASC;")
        With cbo
            .Items.Clear()
            For i = 0 To tmp.Rows.Count - 1
                cbo.Items.Add(tmp.Rows(i)(0).ToString.Trim)
            Next
        End With
    End Sub
End Module
