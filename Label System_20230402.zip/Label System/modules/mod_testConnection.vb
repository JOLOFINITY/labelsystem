﻿Module mod_testConnection
    Public boolConnected As Boolean = tryConnection()

    Public Function tryConnection() As Boolean
        Try
            Using connection As New MySqlConnection(My.Settings.connection.ToString)
                connection.Open()

                connection.Close()
            End Using

            boolConnected = True
        Catch ex As Exception
            boolConnected = False
        End Try

        Return boolConnected
    End Function
End Module
