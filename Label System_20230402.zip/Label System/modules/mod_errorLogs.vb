﻿Imports System.Windows.Forms
Module mod_errorLogs
    Public Sub createErrorLogs(ByRef ex As Exception, ByRef query As String, ByRef connectionString As String)
        Try
            Dim errorFolder As String = Application.StartupPath & "\errorLogs"

            If IO.Directory.Exists(errorFolder) = False Then IO.Directory.CreateDirectory(errorFolder)

            Dim errorMessage As String = "Connection error occurred, Please notify Sir JOLO for this Error.." & vbNewLine & vbNewLine & vbNewLine & _
                "Error : " & ex.Message.ToString & vbNewLine & vbNewLine & _
                "Details : " & ex.StackTrace.ToString & vbNewLine & vbNewLine & vbNewLine & _
                "Connection String : " & connectionString & vbNewLine & vbNewLine &
                "Query : " & vbNewLine & query & vbNewLine & vbNewLine & vbNewLine & _
                "Date and Time Log : " & DateAndTime.Now.ToString("yyyy-MM-dd hh:mm:ss tt")

            Dim errorFileName As String = My.Computer.Name.ToUpper & "_" & DateAndTime.Now.ToString("yyyyMMddHHmmss") & ".jolofinity"

            IO.File.WriteAllText(errorFolder & "\" & errorFileName, errorMessage)

            MessageBox.Show($"An Error occured during Downloading/Uploading of RECORD.{vbNewLine}{vbNewLine}{ex.Message.ToString}{vbNewLine}{vbNewLine}Please notify Sir JOLo for this matter.." & vbNewLine & vbNewLine & "• SYSTEM WILL AUTOMATICALLY CLOSE AFTER THIS MESSAGE!!", "ERROR DURING SAVING!!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch exTra As Exception

        End Try

        End
    End Sub
End Module
