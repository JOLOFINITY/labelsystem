﻿Imports MySql.Data.MySqlClient
Module mod_functions
    Public boolConnected As Boolean = False
    Public Sub _connectDB()
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()

                Connection.Close()
            End Using

            boolConnected = True
        Catch ex As Exception
            Call createErrorLogs(ex, "CONNECTION TEST.", My.Settings.connection)
            boolConnected = False
        End Try
    End Sub
    Private Sub _saveDATA(ByRef query As String)
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using Comm = New MySqlCommand(query, Connection)
                    Comm.ExecuteNonQuery()
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
    End Sub
    Private Function _createTable(ByRef query As String) As DataTable
        Dim temp As New DataTable
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using dA = New MySqlDataAdapter(query, Connection)
                    Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
        Return temp
    End Function
    Public Sub get_itemListA(ByRef cboITEM As modComboBox, ByRef cboCONDITION As modComboBox, ByRef result As DataTable)
        Dim query As String =
            "SELECT `Item Name`,`Condition`,`Shelflife`,`Shelflife By`,`Unit`,`Storage`,CASE WHEN `Default` IS NULL OR `Default` = '' THEN 0.0 ELSE `Default` END `Default`,`Default By`,`Add Days`,`Add By` FROM `t_mst_items` ORDER BY `Item Name` ASC;"

        result = _createTable(query)

        Dim filtered = result.DefaultView.ToTable("result", True, "Item Name")
        filtered.DefaultView.Sort = "Item Name ASC"
        filtered = filtered.DefaultView.ToTable()
        cboITEM.Items.Clear()
        For i = 0 To filtered.Rows.Count - 1
            cboITEM.Items.Add(filtered.Rows(i)("Item Name").ToString.Trim)
        Next

        filtered = result.DefaultView.ToTable("result", True, "Condition")
        filtered.DefaultView.Sort = "Condition ASC"
        filtered = filtered.DefaultView.ToTable()
        cboCONDITION.Items.Clear()
        For i = 0 To filtered.Rows.Count - 1
            cboCONDITION.Items.Add(filtered.Rows(i)("Condition").ToString.Trim)
        Next
    End Sub
    Public Sub get_itemListC(ByRef grid As DataGridView)
        Dim query As String =
            "SELECT `Item Name`,`Condition`,`Shelflife`,`Shelflife By`,`Unit`,`Storage`,CASE WHEN `Default` IS NULL OR `Default` = '' THEN 0.0 ELSE `Default` END `Default`,`Default By`,`Add Days`,`Add By` FROM `t_mst_items` " & vbNewLine &
            "ORDER BY CASE " & vbNewLine &
            "WHEN `Shelflife By` = 'N/A' THEN 99 " & vbNewLine &
            "WHEN `Shelflife By` = 'EOD' THEN 1 " & vbNewLine &
            "WHEN `Shelflife By` = 'MINUTES' THEN 2 " & vbNewLine &
            "WHEN `Shelflife By` = 'HOUR(S)' THEN 3 " & vbNewLine &
            "WHEN `Shelflife By` = 'DAY(S)' THEN 4 " & vbNewLine &
            "WHEN `Shelflife By` = 'WEEK(S)' THEN 5 " & vbNewLine &
            "WHEN `Shelflife By` = 'MONTH(S)' THEN 6 " & vbNewLine &
            "WHEN `Shelflife By` = 'YEAR(S)' THEN 7 " & vbNewLine &
            "END ASC , `Storage` ASC; " & vbNewLine

        Dim result = _createTable(query)

        With grid
            .DataSource = result
            .ClearSelection()

            .Columns(0).Width = 60
            .Columns(1).Width = .Width / 2.5 : .Columns(1).Frozen = True

            .Columns(2).Width = 100
            .Columns(3).Width = 70
            .Columns(4).Width = 90
            .Columns(5).Width = 70
            .Columns(6).Width = 100

            .Columns(7).Width = 70
            .Columns(8).Width = 90
        End With
    End Sub
    Public Function check_itemExistA(ByRef name As String, ByRef condition As String) As Boolean
        Dim query As String =
            "SELECT `Item Name`,`Condition` FROM `t_mst_items` WHERE `Item Name` = '" & name & "' AND `Condition` = '" & condition & "';"

        Dim result = _createTable(query)

        If result.Rows.Count = 0 Then
            Return False
        Else
            Return True
        End If
    End Function
    Public Sub check_itenExistUpdate(ByRef name As String, ByRef condition As String,
                                     ByRef shelflife As String, ByRef shelflifeBy As String, ByRef unit As String, ByRef storage As String,
                                     ByRef shelflifeDef As String, ByRef shelflifeByDef As String, ByRef addDays As Decimal, ByRef addDaysBy As String)
        Dim query As String =
            "UPDATE `t_mst_items`" & vbNewLine &
            "SET" & vbNewLine &
            "`Shelflife` = '" & shelflife & "'," & vbNewLine &
            "`Shelflife By` = '" & shelflifeBy & "'," & vbNewLine &
            "`Unit` = '" & unit & "'," & vbNewLine

        If shelflifeDef <> String.Empty And shelflifeByDef <> String.Empty Then
            query &= "`Default` = '" & shelflifeDef & "', " & vbNewLine &
                "`Default By` = '" & shelflifeByDef & "', " & vbNewLine
        Else
            query &= "`Default` = NULL, " & vbNewLine &
                "`Default By` = NULL, " & vbNewLine

        End If

        query &= "`Add Days` = '" & addDays & "', " & vbNewLine
        query &= "`Add By` = '" & addDaysBy & "', " & vbNewLine

        query &= "`Storage` = '" & storage & "' " & vbNewLine &
            "WHERE `Item Name` = '" & name & "' AND `Condition` = '" & condition & "';"

        _saveDATA(query)

    End Sub

#Region "Label Print Input"
    Public Sub AddForPrint(ByRef query As String)
        _saveDATA(query)
    End Sub
    Public Function quickPrint(ByRef query As String) As DataTable
        Return _createTable(query)
    End Function
    Public Sub getPrintLabelHistory(ByRef status As Integer, ByRef grid As DataGridView)
        _saveDATA("UPDATE `t_for_print` SET `IsPrinted` = 2 WHERE `Validity` <= NOW();")

        Dim query As String =
            "SELECT " & vbNewLine &
            "CASE WHEN `IsPrinted` = 0 THEN 'FOR PRINTING' " & vbNewLine &
            "WHEN `IsPrinted` = 1 THEN 'PRINTED' " & vbNewLine &
            "WHEN `IsPrinted` = 2 THEN 'DELETED' END `STATUS`, " & vbNewLine &
            "`DAY`,`ITEM`,`DATE`,`QUANTITY`,`SHELFLIFE`,`TIME-IN`,`EMPLOYEE`,`USED BY`,`MANAGER`,`REMARKS`,`UID` " & vbNewLine &
            "FROM `t_for_print` WHERE `IsPrinted` = " & status & " ORDER BY `EMPLOYEE` ASC; " & vbNewLine
        Dim result = _createTable(query)

        With grid
            .DataSource = result
            .ClearSelection()
            Try


            Catch ex As Exception

            End Try

        End With
    End Sub
    Public Function qPrint() As DataTable
        Return _createTable("SELECT `UID`,`DAY`,`ITEM`,`DATE`,`QUANTITY`,`SHELFLIFE`,`TIME-IN`,`EMPLOYEE`,`AM`,`PM`,`USED BY`,`MANAGER`,`REMARKS`" & vbNewLine &
            "FROM `t_for_print` WHERE `IsPrinted` = '0'  ORDER BY `DATE` ASC;")

    End Function
    Public Sub updateLabelHistory(ByRef ID As Int64, ByRef status As Int64)
        _saveDATA("UPDATE `t_for_print` SET `IsPrinted` = " & status & " WHERE `UID` = '" & ID & "';")
    End Sub
    Public Sub updateUIDs(ByRef ID As String)
        _saveDATA("UPDATE `t_for_print` SET `IsPrinted` = 1 WHERE `UID` IN(" & ID & ");")
    End Sub
    Public Function getLabeltoPrint(ByRef ID As Int64) As DataTable
        Dim query As String =
            "SELECT `DAY`,`ITEM`,`DATE`,`QUANTITY`,`SHELFLIFE`,`TIME-IN`,`EMPLOYEE`,`AM`,`PM`,`USED BY`,`MANAGER`,`REMARKS`" & vbNewLine &
            "FROM `t_for_print` WHERE `UID` = '" & ID & "';"
        Return _createTable(query)
    End Function
#End Region
End Module
