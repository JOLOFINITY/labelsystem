﻿'Add Reference > COM > Windows Script Host Object Model.
Imports IWshRuntimeLibrary

Module mod_shotcut
    Public Sub createShortCut(ByRef nameOfApplication As String)
        Dim objShell, strDesktopPath, objLink
        objShell = CreateObject("WScript.Shell")
        strDesktopPath = objShell.SpecialFolders("Desktop")
        objLink = objShell.CreateShortcut(strDesktopPath & "\" & nameOfApplication & ".lnk")

        'objLink.Arguments = "c:\windows\tips.txt"
        objLink.Description = "Shortcut to " & nameOfApplication
        objLink.TargetPath = Application.ExecutablePath
        objLink.WindowStyle = 1
        objLink.IconLocation = Application.StartupPath & "\icon.ico"
        objLink.WorkingDirectory = Application.StartupPath & "\"
        objLink.Hotkey = "Ctrl+Shift+M"
        objLink.Save()
    End Sub
End Module
