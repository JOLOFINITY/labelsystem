﻿Module mod_userlogin
    Private Sub _saveDATA(ByRef query As String)
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using Comm = New MySqlCommand(query, Connection)
                    Comm.ExecuteNonQuery()
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
    End Sub
    Private Function _createTable(ByRef query As String) As DataTable
        Dim temp As New DataTable
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using dA = New MySqlDataAdapter(query, Connection)
                    Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
        Return temp
    End Function

    Public login_username As String = String.Empty

    Public Sub log_User(ByRef strAccess As String, ByRef username As String)
		_saveDATA( _
			"INSERT INTO `t_logins` " & vbNewLine & _
			"(`Access`,`Username`,`Terminal No`) " & vbNewLine & _
			"VALUES('" & strAccess & "','" & username & "','" & My.Computer.Name & "');")
	End Sub
End Module
