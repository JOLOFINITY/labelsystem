﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_0_menu
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.pmain = New System.Windows.Forms.Panel()
        Me.pController = New System.Windows.Forms.Panel()
        Me.pfooter = New System.Windows.Forms.Panel()
        Me.pmenus = New System.Windows.Forms.Panel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmsettings = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmexit = New System.Windows.Forms.ToolStripMenuItem()
        Me.MasterMaintenanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmitemMst = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmprocessUnitMst = New System.Windows.Forms.ToolStripMenuItem()
        Me.LabelPrintingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmlabelEntry = New System.Windows.Forms.ToolStripMenuItem()
        Me.cmlabelHistory = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblbuildNo = New System.Windows.Forms.Label()
        Me.lblheaderSub = New System.Windows.Forms.Label()
        Me.llblhide = New System.Windows.Forms.LinkLabel()
        Me.llblmaximized = New System.Windows.Forms.LinkLabel()
        Me.lblclose = New System.Windows.Forms.LinkLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblheader = New System.Windows.Forms.Label()
        Me.FinishGoodsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lbldt = New System.Windows.Forms.Label()
        Me.lblstatus = New System.Windows.Forms.Label()
        Me.dtGet = New System.Windows.Forms.Timer(Me.components)
        Me.pmain.SuspendLayout()
        Me.pfooter.SuspendLayout()
        Me.pmenus.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.pController)
        Me.pmain.Controls.Add(Me.pfooter)
        Me.pmain.Controls.Add(Me.pmenus)
        Me.pmain.Controls.Add(Me.lblbuildNo)
        Me.pmain.Controls.Add(Me.lblheaderSub)
        Me.pmain.Controls.Add(Me.llblhide)
        Me.pmain.Controls.Add(Me.llblmaximized)
        Me.pmain.Controls.Add(Me.lblclose)
        Me.pmain.Controls.Add(Me.Label1)
        Me.pmain.Controls.Add(Me.lblheader)
        Me.pmain.Location = New System.Drawing.Point(2, 5)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(1010, 793)
        Me.pmain.TabIndex = 0
        '
        'pController
        '
        Me.pController.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pController.Location = New System.Drawing.Point(2, 107)
        Me.pController.Name = "pController"
        Me.pController.Size = New System.Drawing.Size(1006, 641)
        Me.pController.TabIndex = 11
        '
        'pfooter
        '
        Me.pfooter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pfooter.BackColor = System.Drawing.Color.LightGray
        Me.pfooter.Controls.Add(Me.lblstatus)
        Me.pfooter.Controls.Add(Me.lbldt)
        Me.pfooter.Location = New System.Drawing.Point(1, 749)
        Me.pfooter.Name = "pfooter"
        Me.pfooter.Size = New System.Drawing.Size(1008, 43)
        Me.pfooter.TabIndex = 10
        '
        'pmenus
        '
        Me.pmenus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmenus.BackColor = System.Drawing.Color.Gainsboro
        Me.pmenus.Controls.Add(Me.MenuStrip1)
        Me.pmenus.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.pmenus.Location = New System.Drawing.Point(1, 79)
        Me.pmenus.Name = "pmenus"
        Me.pmenus.Size = New System.Drawing.Size(1009, 27)
        Me.pmenus.TabIndex = 9
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Gainsboro
        Me.MenuStrip1.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem, Me.MasterMaintenanceToolStripMenuItem, Me.LabelPrintingToolStripMenuItem, Me.FinishGoodsToolStripMenuItem, Me.InventoryToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1009, 27)
        Me.MenuStrip1.TabIndex = 8
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MenuToolStripMenuItem
        '
        Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmsettings, Me.ToolStripMenuItem1, Me.cmexit})
        Me.MenuToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
        Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(74, 23)
        Me.MenuToolStripMenuItem.Text = "Menu  "
        '
        'cmsettings
        '
        Me.cmsettings.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmsettings.Name = "cmsettings"
        Me.cmsettings.Size = New System.Drawing.Size(156, 22)
        Me.cmsettings.Text = "Setting(s)"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(153, 6)
        '
        'cmexit
        '
        Me.cmexit.Font = New System.Drawing.Font("MS Gothic", 12.0!)
        Me.cmexit.Name = "cmexit"
        Me.cmexit.Size = New System.Drawing.Size(156, 22)
        Me.cmexit.Text = "Exit"
        '
        'MasterMaintenanceToolStripMenuItem
        '
        Me.MasterMaintenanceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmitemMst, Me.cmprocessUnitMst})
        Me.MasterMaintenanceToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.MasterMaintenanceToolStripMenuItem.Name = "MasterMaintenanceToolStripMenuItem"
        Me.MasterMaintenanceToolStripMenuItem.Size = New System.Drawing.Size(200, 23)
        Me.MasterMaintenanceToolStripMenuItem.Text = "Master Maintenance  "
        '
        'cmitemMst
        '
        Me.cmitemMst.Font = New System.Drawing.Font("MS Gothic", 12.0!)
        Me.cmitemMst.Name = "cmitemMst"
        Me.cmitemMst.Size = New System.Drawing.Size(244, 22)
        Me.cmitemMst.Text = "Item(s) / Material(s)"
        '
        'cmprocessUnitMst
        '
        Me.cmprocessUnitMst.Font = New System.Drawing.Font("MS Gothic", 12.0!)
        Me.cmprocessUnitMst.Name = "cmprocessUnitMst"
        Me.cmprocessUnitMst.Size = New System.Drawing.Size(244, 22)
        Me.cmprocessUnitMst.Text = "Process / Unit"
        '
        'LabelPrintingToolStripMenuItem
        '
        Me.LabelPrintingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmlabelEntry, Me.cmlabelHistory})
        Me.LabelPrintingToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.LabelPrintingToolStripMenuItem.Name = "LabelPrintingToolStripMenuItem"
        Me.LabelPrintingToolStripMenuItem.Size = New System.Drawing.Size(164, 23)
        Me.LabelPrintingToolStripMenuItem.Text = "Label Printing  "
        '
        'cmlabelEntry
        '
        Me.cmlabelEntry.Font = New System.Drawing.Font("MS Gothic", 12.0!)
        Me.cmlabelEntry.Name = "cmlabelEntry"
        Me.cmlabelEntry.Size = New System.Drawing.Size(244, 22)
        Me.cmlabelEntry.Text = "Label Entry"
        '
        'cmlabelHistory
        '
        Me.cmlabelHistory.Font = New System.Drawing.Font("MS Gothic", 12.0!)
        Me.cmlabelHistory.Name = "cmlabelHistory"
        Me.cmlabelHistory.Size = New System.Drawing.Size(244, 22)
        Me.cmlabelHistory.Text = "Print / Label History"
        '
        'lblbuildNo
        '
        Me.lblbuildNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblbuildNo.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbuildNo.Location = New System.Drawing.Point(874, 47)
        Me.lblbuildNo.Name = "lblbuildNo"
        Me.lblbuildNo.Size = New System.Drawing.Size(128, 20)
        Me.lblbuildNo.TabIndex = 7
        Me.lblbuildNo.Text = "Build.210720.01"
        Me.lblbuildNo.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'lblheaderSub
        '
        Me.lblheaderSub.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheaderSub.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblheaderSub.Location = New System.Drawing.Point(35, 47)
        Me.lblheaderSub.Name = "lblheaderSub"
        Me.lblheaderSub.Size = New System.Drawing.Size(745, 20)
        Me.lblheaderSub.TabIndex = 5
        Me.lblheaderSub.Text = "• Label Printing • Finished Goods • Inventory System"
        Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'llblhide
        '
        Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblhide.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.llblhide.Location = New System.Drawing.Point(883, 9)
        Me.llblhide.Name = "llblhide"
        Me.llblhide.Size = New System.Drawing.Size(37, 25)
        Me.llblhide.TabIndex = 2
        Me.llblhide.TabStop = True
        Me.llblhide.Text = "◣"
        Me.llblhide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'llblmaximized
        '
        Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblmaximized.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.llblmaximized.Location = New System.Drawing.Point(924, 9)
        Me.llblmaximized.Name = "llblmaximized"
        Me.llblmaximized.Size = New System.Drawing.Size(37, 25)
        Me.llblmaximized.TabIndex = 1
        Me.llblmaximized.TabStop = True
        Me.llblmaximized.Text = "☐"
        Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblclose
        '
        Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblclose.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.lblclose.Location = New System.Drawing.Point(965, 9)
        Me.lblclose.Name = "lblclose"
        Me.lblclose.Size = New System.Drawing.Size(37, 25)
        Me.lblclose.TabIndex = 1
        Me.lblclose.TabStop = True
        Me.lblclose.Text = "✕"
        Me.lblclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(0, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1012, 6)
        Me.Label1.TabIndex = 0
        '
        'lblheader
        '
        Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheader.Location = New System.Drawing.Point(10, 9)
        Me.lblheader.Name = "lblheader"
        Me.lblheader.Size = New System.Drawing.Size(777, 60)
        Me.lblheader.TabIndex = 6
        Me.lblheader.Text = "Integrated LFI Syetem Menu"
        '
        'FinishGoodsToolStripMenuItem
        '
        Me.FinishGoodsToolStripMenuItem.Name = "FinishGoodsToolStripMenuItem"
        Me.FinishGoodsToolStripMenuItem.Size = New System.Drawing.Size(161, 23)
        Me.FinishGoodsToolStripMenuItem.Text = "Finish Good(s)"
        '
        'InventoryToolStripMenuItem
        '
        Me.InventoryToolStripMenuItem.Name = "InventoryToolStripMenuItem"
        Me.InventoryToolStripMenuItem.Size = New System.Drawing.Size(111, 23)
        Me.InventoryToolStripMenuItem.Text = "Inventory"
        '
        'lbldt
        '
        Me.lbldt.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbldt.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldt.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lbldt.Location = New System.Drawing.Point(10, 7)
        Me.lbldt.Name = "lbldt"
        Me.lbldt.Size = New System.Drawing.Size(495, 28)
        Me.lbldt.TabIndex = 0
        Me.lbldt.Text = "Label2"
        Me.lbldt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblstatus
        '
        Me.lblstatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblstatus.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus.ForeColor = System.Drawing.Color.RoyalBlue
        Me.lblstatus.Location = New System.Drawing.Point(511, 7)
        Me.lblstatus.Name = "lblstatus"
        Me.lblstatus.Size = New System.Drawing.Size(490, 28)
        Me.lblstatus.TabIndex = 1
        Me.lblstatus.Text = "Label2"
        Me.lblstatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dtGet
        '
        Me.dtGet.Enabled = True
        Me.dtGet.Interval = 1000
        '
        'vw_0_menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(1014, 800)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_0_menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.pmain.ResumeLayout(False)
        Me.pfooter.ResumeLayout(False)
        Me.pmenus.ResumeLayout(False)
        Me.pmenus.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
	Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
	Friend WithEvents lblbuildNo As System.Windows.Forms.Label
	Friend WithEvents lblheaderSub As System.Windows.Forms.Label
	Friend WithEvents lblheader As System.Windows.Forms.Label
	Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
	Friend WithEvents MenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents pmenus As System.Windows.Forms.Panel
	Friend WithEvents cmsettings As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents MasterMaintenanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents LabelPrintingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents cmexit As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmitemMst As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmprocessUnitMst As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmlabelEntry As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmlabelHistory As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents pfooter As System.Windows.Forms.Panel
    Friend WithEvents pController As System.Windows.Forms.Panel
    Friend WithEvents FinishGoodsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblstatus As System.Windows.Forms.Label
    Friend WithEvents lbldt As System.Windows.Forms.Label
    Friend WithEvents dtGet As System.Windows.Forms.Timer
End Class
