﻿Imports System.Runtime.InteropServices
Public Class vw_0_menu
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown, lblheader.MouseDown, lblheaderSub.MouseDown, lblbuildNo.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub

	Private Sub me_Resize(sender As Object, e As EventArgs) Handles Me.Resize
		If WindowState = FormWindowState.Maximized Then
			Maximize(Me)
		Else
			'Restore(Me)
			If llblmaximized.Text = "☒" Then
				llblmaximized.Text = "☐"
			End If
		End If

		If child.IsHandleCreated Then
			child.Size = pController.Size
		End If
	End Sub
	Private Sub lblclose_MouseEnter(sender As Object, e As EventArgs) Handles lblclose.MouseEnter, llblmaximized.MouseEnter
		Dim llbl As LinkLabel = sender

		llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size + 2, FontStyle.Bold)
	End Sub

	Private Sub lblclose_MouseLeave(sender As Object, e As EventArgs) Handles lblclose.MouseLeave, llblmaximized.MouseLeave
		Dim llbl As LinkLabel = sender

		llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size - 2, FontStyle.Regular)
	End Sub

	Private Sub llblmaximized_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblmaximized.LinkClicked
		If llblmaximized.Text = "☐" Then
			llblmaximized.Text = "☒"
			WindowState = FormWindowState.Maximized
			Maximize(Me)
		Else
			llblmaximized.Text = "☐"
			WindowState = FormWindowState.Normal
			'Restore(Me)
		End If
	End Sub
	Private Sub lblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblclose.LinkClicked
		Dispose()
	End Sub
	Private Sub llblhide_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblhide.LinkClicked
		WindowState = FormWindowState.Minimized
	End Sub
#End Region

	Private Sub cmsettings_Click(sender As Object, e As EventArgs) Handles cmsettings.Click
		MessageBox.Show("• Not yet available, Please wait for the Update.", "Access Denied.", MessageBoxButtons.OK, MessageBoxIcon.Information)
	End Sub

	Private Sub cmexit_Click(sender As Object, e As EventArgs) Handles cmexit.Click
		End
	End Sub

	Private child As New Form
    Private Sub showForm(ByRef frm As Form)
        If boolConnected Then
            If child.IsHandleCreated Then child.Dispose()
            With pController
                child = frm
                child.TopLevel = False
                child.Size = .Size
                .Controls.Add(child)
                child.Show()
            End With
        Else
            MessageBox.Show("Server not found, System will try to Reconnect to Server...", "Server Not Found.", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            Call connect()
        End If
    End Sub

	Private Sub cmitemMst_Click(sender As Object, e As EventArgs) Handles cmitemMst.Click
		showForm(New vw_1_itemMaster)
	End Sub
	Private Sub cmprocessUnitMst_Click(sender As Object, e As EventArgs) Handles cmprocessUnitMst.Click
		showForm(New vw_1_itemMaster)
	End Sub

	Private Sub cmlabelEntry_Click(sender As Object, e As EventArgs) Handles cmlabelEntry.Click
		showForm(New vw_3_labelInput)
	End Sub

	Private Sub cmlabelHistory_Click(sender As Object, e As EventArgs) Handles cmlabelHistory.Click
		showForm(New vw_4_labelHistory)
	End Sub

    Private Sub dtGet_Tick(sender As Object, e As EventArgs) Handles dtGet.Tick
        With dtGet
            .Stop()
            lbldt.Text = DateAndTime.Now.ToString("yyyy-MM-dd hh:mm:ss tt ( dddd )").ToUpper
            .Start()
        End With
    End Sub

    Private Sub vw_0_menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connect()
    End Sub
    Sub connect()
        Call tryConnection()

        If boolConnected Then
            lblstatus.Text = "SERVER STATUS : CONNECTED" : lblstatus.ForeColor = Color.Blue
        Else
            lblstatus.Text = "SERVER STATUS : DISCONNECTED" : lblstatus.ForeColor = Color.Red
        End If
    End Sub

    Private Sub lblstatus_Click(sender As Object, e As EventArgs) Handles lblstatus.Click
        Call connect()
    End Sub
End Class