﻿Imports System.Drawing.Printing.PrinterSettings

Imports CrystalDecisions.CrystalReports.Engine

Module rep_init
    Public cReport As New ReportDocument

    Public Sub initREPORT()
        cReport = New rptLABELv002
    End Sub
    Public Function PrinterExists() As Boolean
        Try
            If String.IsNullOrEmpty(My.Settings.defaultPrinter) Then
                Throw New ArgumentNullException("printerName")
            End If
            Return InstalledPrinters.Cast(Of String)().Any(Function(name) My.Settings.defaultPrinter.ToUpper().Trim() = name.ToUpper().Trim())
        Catch ex As Exception
            Return False
        End Try
    End Function
End Module
