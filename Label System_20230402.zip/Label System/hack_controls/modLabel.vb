﻿Imports System.Drawing.Drawing2D
Public Class modLabel
	Public Property Text As String
	Public Property Location As Point
	Public Property Angle As Integer
	Public Property Font As Font
	Public Property ForeColour As Color
	Public Sub New(Text As String, Location As Point)
		Me.New(Text, Location, 0, New Font("Arial", 10), Color.Black)
	End Sub
	Public Sub New(Text As String, Location As Point, Angle As Integer)
		Me.New(Text, Location, Angle, New Font("Arial", 10), Color.Black)
	End Sub
	Public Sub New(Text As String, Location As Point, Angle As Integer, Font As Font)
		Me.New(Text, Location, Angle, Font, Color.Black)
	End Sub
	Public Sub New(Text As String, Location As Point, Angle As Integer, Font As Font, ForeColour As Color)
		Me.Text = Text
		Me.Location = Location
		Me.Angle = Angle
		Me.Font = Font
		Me.ForeColour = ForeColour
	End Sub
	Public Sub Draw(g As Graphics)
		Dim State As GraphicsState = g.Save
		g.TranslateTransform(Location.X, Location.Y)
		g.RotateTransform(Angle)
		Using Brsh As New SolidBrush(ForeColour)
			g.DrawString(Text, Font, Brsh, New Point(0, 0))
		End Using
		g.Restore(State)
	End Sub
End Class

