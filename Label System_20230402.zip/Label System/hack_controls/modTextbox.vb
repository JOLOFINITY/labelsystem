﻿Imports System
Imports System.Diagnostics
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class modTextbox
	Inherits TextBox

	Public Sub New()
		Font = New Font("Tahoma", 12, FontStyle.Regular)
	End Sub

	

	Private Sub InitializeComponent()
		Me.SuspendLayout()
		Me.ResumeLayout(False)

	End Sub

	Private Sub modTextbox_Enter(sender As Object, e As EventArgs) Handles Me.Enter
		BackColor = Color.LightPink
	End Sub

	Private Sub modTextbox_Leave(sender As Object, e As EventArgs) Handles Me.Leave
		BackColor = Color.White
	End Sub
End Class