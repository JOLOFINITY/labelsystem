﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_4_labelInput
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_4_labelInput))
        Me.pmain = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.griditemList = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnsavePrint = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.paperOut = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblpreview_PM = New System.Windows.Forms.Label()
        Me.lblpreview_remarks = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblpreview_AM = New System.Windows.Forms.Label()
        Me.lblpreview_manager = New System.Windows.Forms.Label()
        Me.lblpreview_usedBy = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblpreview_employeeName = New System.Windows.Forms.Label()
        Me.lblpreview_timeIN = New System.Windows.Forms.Label()
        Me.lblpreview_shelftLife = New System.Windows.Forms.Label()
        Me.lblpreview_quantityUnit = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblpreview_productionDate = New System.Windows.Forms.Label()
        Me.lblpreview_itemName = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.lblpreview_days = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtTimeIn = New System.Windows.Forms.DateTimePicker()
        Me.lblshelflife = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblshelflifeBy = New System.Windows.Forms.Label()
        Me.lblvalidity = New System.Windows.Forms.Label()
        Me.lbldays = New System.Windows.Forms.Label()
        Me.cboquantity = New Label_System.modComboBox()
        Me.cboremarks = New Label_System.modComboBox()
        Me.cboemployee = New Label_System.modComboBox()
        Me.cbomanager = New Label_System.modComboBox()
        Me.lblusedBy = New System.Windows.Forms.Label()
        Me.dtDate = New System.Windows.Forms.DateTimePicker()
        Me.dateProduction = New System.Windows.Forms.DateTimePicker()
        Me.cboitems = New Label_System.modComboBox()
        Me.picNew = New System.Windows.Forms.PictureBox()
        Me.lblC = New System.Windows.Forms.Label()
        Me.lblstorage = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblG = New System.Windows.Forms.Label()
        Me.lblF = New System.Windows.Forms.Label()
        Me.lblunit = New System.Windows.Forms.Label()
        Me.lblE = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblD = New System.Windows.Forms.Label()
        Me.cbocondition = New Label_System.modComboBox()
        Me.lblB = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblI = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.lblJ = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.lblH = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblA = New System.Windows.Forms.Label()
        Me.setPreview = New System.Windows.Forms.Timer(Me.components)
        Me.tfocus = New System.Windows.Forms.Timer(Me.components)
        Me.lblproductionDefault = New System.Windows.Forms.Label()
        Me.pmain.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.paperOut.SuspendLayout()
        CType(Me.picNew, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.Panel1)
        Me.pmain.Controls.Add(Me.GroupBox1)
        Me.pmain.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.pmain.Location = New System.Drawing.Point(2, 2)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(1054, 784)
        Me.pmain.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.griditemList)
        Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(3, 380)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1048, 401)
        Me.Panel1.TabIndex = 15
        '
        'griditemList
        '
        Me.griditemList.AllowUserToAddRows = False
        Me.griditemList.AllowUserToDeleteRows = False
        Me.griditemList.AllowUserToResizeColumns = False
        Me.griditemList.AllowUserToResizeRows = False
        Me.griditemList.BackgroundColor = System.Drawing.Color.White
        Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.griditemList.ColumnHeadersHeight = 28
        Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.griditemList.DefaultCellStyle = DataGridViewCellStyle8
        Me.griditemList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.griditemList.EnableHeadersVisualStyles = False
        Me.griditemList.Location = New System.Drawing.Point(0, 0)
        Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.griditemList.MultiSelect = False
        Me.griditemList.Name = "griditemList"
        Me.griditemList.ReadOnly = True
        Me.griditemList.RowHeadersVisible = False
        Me.griditemList.RowTemplate.Height = 20
        Me.griditemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.griditemList.ShowCellErrors = False
        Me.griditemList.ShowCellToolTips = False
        Me.griditemList.ShowEditingIcon = False
        Me.griditemList.ShowRowErrors = False
        Me.griditemList.Size = New System.Drawing.Size(1048, 401)
        Me.griditemList.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Select"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.lblproductionDefault)
        Me.GroupBox1.Controls.Add(Me.btnsavePrint)
        Me.GroupBox1.Controls.Add(Me.btnsave)
        Me.GroupBox1.Controls.Add(Me.btnclear)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.paperOut)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtTimeIn)
        Me.GroupBox1.Controls.Add(Me.lblshelflife)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.lblshelflifeBy)
        Me.GroupBox1.Controls.Add(Me.lblvalidity)
        Me.GroupBox1.Controls.Add(Me.lbldays)
        Me.GroupBox1.Controls.Add(Me.cboquantity)
        Me.GroupBox1.Controls.Add(Me.cboremarks)
        Me.GroupBox1.Controls.Add(Me.cboemployee)
        Me.GroupBox1.Controls.Add(Me.cbomanager)
        Me.GroupBox1.Controls.Add(Me.lblusedBy)
        Me.GroupBox1.Controls.Add(Me.dtDate)
        Me.GroupBox1.Controls.Add(Me.cboitems)
        Me.GroupBox1.Controls.Add(Me.picNew)
        Me.GroupBox1.Controls.Add(Me.lblstorage)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.lblG)
        Me.GroupBox1.Controls.Add(Me.lblF)
        Me.GroupBox1.Controls.Add(Me.lblunit)
        Me.GroupBox1.Controls.Add(Me.lblE)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblD)
        Me.GroupBox1.Controls.Add(Me.cbocondition)
        Me.GroupBox1.Controls.Add(Me.lblB)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.lblI)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.lblJ)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.lblH)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.lblA)
        Me.GroupBox1.Controls.Add(Me.dateProduction)
        Me.GroupBox1.Controls.Add(Me.lblC)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 1.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1044, 375)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'btnsavePrint
        '
        Me.btnsavePrint.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsavePrint.ForeColor = System.Drawing.Color.Black
        Me.btnsavePrint.Location = New System.Drawing.Point(498, 299)
        Me.btnsavePrint.Name = "btnsavePrint"
        Me.btnsavePrint.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.btnsavePrint.Size = New System.Drawing.Size(147, 30)
        Me.btnsavePrint.TabIndex = 44
        Me.btnsavePrint.Tag = "0"
        Me.btnsavePrint.Text = "Save and Print [F2]"
        Me.btnsavePrint.UseVisualStyleBackColor = True
        Me.btnsavePrint.Visible = False
        '
        'btnsave
        '
        Me.btnsave.Font = New System.Drawing.Font("Arial", 11.25!)
        Me.btnsave.ForeColor = System.Drawing.Color.Black
        Me.btnsave.Location = New System.Drawing.Point(651, 299)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.btnsave.Size = New System.Drawing.Size(130, 30)
        Me.btnsave.TabIndex = 8
        Me.btnsave.Tag = "0"
        Me.btnsave.Text = "Save [F2]"
        Me.btnsave.UseVisualStyleBackColor = True
        Me.btnsave.Visible = False
        '
        'btnclear
        '
        Me.btnclear.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnclear.BackColor = System.Drawing.Color.White
        Me.btnclear.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnclear.FlatAppearance.BorderSize = 2
        Me.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnclear.Font = New System.Drawing.Font("Arial", 11.25!)
        Me.btnclear.ForeColor = System.Drawing.Color.Black
        Me.btnclear.Location = New System.Drawing.Point(899, 299)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.btnclear.Size = New System.Drawing.Size(140, 30)
        Me.btnclear.TabIndex = 9
        Me.btnclear.Tag = "1"
        Me.btnclear.Text = "Clear [F5]"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Cyan
        Me.Label8.Location = New System.Drawing.Point(492, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(200, 22)
        Me.Label8.TabIndex = 43
        Me.Label8.Text = "Label preview (Output)"
        '
        'paperOut
        '
        Me.paperOut.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.paperOut.BackColor = System.Drawing.Color.White
        Me.paperOut.Controls.Add(Me.Label19)
        Me.paperOut.Controls.Add(Me.lblpreview_PM)
        Me.paperOut.Controls.Add(Me.lblpreview_remarks)
        Me.paperOut.Controls.Add(Me.Label16)
        Me.paperOut.Controls.Add(Me.lblpreview_AM)
        Me.paperOut.Controls.Add(Me.lblpreview_manager)
        Me.paperOut.Controls.Add(Me.lblpreview_usedBy)
        Me.paperOut.Controls.Add(Me.Label28)
        Me.paperOut.Controls.Add(Me.lblpreview_employeeName)
        Me.paperOut.Controls.Add(Me.lblpreview_timeIN)
        Me.paperOut.Controls.Add(Me.lblpreview_shelftLife)
        Me.paperOut.Controls.Add(Me.lblpreview_quantityUnit)
        Me.paperOut.Controls.Add(Me.Label20)
        Me.paperOut.Controls.Add(Me.lblpreview_productionDate)
        Me.paperOut.Controls.Add(Me.lblpreview_itemName)
        Me.paperOut.Controls.Add(Me.Label33)
        Me.paperOut.Controls.Add(Me.Label34)
        Me.paperOut.Controls.Add(Me.Label35)
        Me.paperOut.Controls.Add(Me.Label36)
        Me.paperOut.Controls.Add(Me.Label37)
        Me.paperOut.Controls.Add(Me.Label38)
        Me.paperOut.Controls.Add(Me.Label39)
        Me.paperOut.Controls.Add(Me.Label40)
        Me.paperOut.Controls.Add(Me.Label41)
        Me.paperOut.Controls.Add(Me.lblpreview_days)
        Me.paperOut.Controls.Add(Me.Label32)
        Me.paperOut.Controls.Add(Me.Label30)
        Me.paperOut.Controls.Add(Me.Label26)
        Me.paperOut.Controls.Add(Me.Label24)
        Me.paperOut.Controls.Add(Me.Label22)
        Me.paperOut.Controls.Add(Me.Label18)
        Me.paperOut.Controls.Add(Me.Label12)
        Me.paperOut.Location = New System.Drawing.Point(498, 37)
        Me.paperOut.Name = "paperOut"
        Me.paperOut.Size = New System.Drawing.Size(541, 256)
        Me.paperOut.TabIndex = 10
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(255, 151)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(23, 16)
        Me.Label19.TabIndex = 44
        Me.Label19.Tag = "£"
        Me.Label19.Text = "PM"
        '
        'lblpreview_PM
        '
        Me.lblpreview_PM.Font = New System.Drawing.Font("Wingdings 2", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblpreview_PM.Location = New System.Drawing.Point(235, 151)
        Me.lblpreview_PM.Name = "lblpreview_PM"
        Me.lblpreview_PM.Size = New System.Drawing.Size(20, 16)
        Me.lblpreview_PM.TabIndex = 44
        Me.lblpreview_PM.Tag = "£"
        Me.lblpreview_PM.Text = "£"
        Me.lblpreview_PM.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'lblpreview_remarks
        '
        Me.lblpreview_remarks.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_remarks.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_remarks.Location = New System.Drawing.Point(122, 202)
        Me.lblpreview_remarks.Name = "lblpreview_remarks"
        Me.lblpreview_remarks.Size = New System.Drawing.Size(400, 28)
        Me.lblpreview_remarks.TabIndex = 16
        Me.lblpreview_remarks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Arial Narrow", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(255, 134)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(23, 17)
        Me.Label16.TabIndex = 27
        Me.Label16.Tag = "R"
        Me.Label16.Text = "AM"
        '
        'lblpreview_AM
        '
        Me.lblpreview_AM.Font = New System.Drawing.Font("Wingdings 2", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblpreview_AM.Location = New System.Drawing.Point(235, 134)
        Me.lblpreview_AM.Name = "lblpreview_AM"
        Me.lblpreview_AM.Size = New System.Drawing.Size(20, 17)
        Me.lblpreview_AM.TabIndex = 27
        Me.lblpreview_AM.Tag = "R"
        Me.lblpreview_AM.Text = "R"
        Me.lblpreview_AM.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'lblpreview_manager
        '
        Me.lblpreview_manager.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_manager.Location = New System.Drawing.Point(122, 169)
        Me.lblpreview_manager.Name = "lblpreview_manager"
        Me.lblpreview_manager.Size = New System.Drawing.Size(215, 28)
        Me.lblpreview_manager.TabIndex = 14
        Me.lblpreview_manager.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpreview_usedBy
        '
        Me.lblpreview_usedBy.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_usedBy.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_usedBy.Location = New System.Drawing.Point(358, 136)
        Me.lblpreview_usedBy.Name = "lblpreview_usedBy"
        Me.lblpreview_usedBy.Size = New System.Drawing.Size(164, 61)
        Me.lblpreview_usedBy.TabIndex = 12
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(279, 136)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(79, 28)
        Me.Label28.TabIndex = 13
        Me.Label28.Text = "USED BY :"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_employeeName
        '
        Me.lblpreview_employeeName.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_employeeName.Location = New System.Drawing.Point(122, 136)
        Me.lblpreview_employeeName.Name = "lblpreview_employeeName"
        Me.lblpreview_employeeName.Size = New System.Drawing.Size(112, 28)
        Me.lblpreview_employeeName.TabIndex = 10
        Me.lblpreview_employeeName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpreview_timeIN
        '
        Me.lblpreview_timeIN.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_timeIN.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_timeIN.Location = New System.Drawing.Point(122, 103)
        Me.lblpreview_timeIN.Name = "lblpreview_timeIN"
        Me.lblpreview_timeIN.Size = New System.Drawing.Size(400, 28)
        Me.lblpreview_timeIN.TabIndex = 8
        Me.lblpreview_timeIN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpreview_shelftLife
        '
        Me.lblpreview_shelftLife.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_shelftLife.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_shelftLife.Location = New System.Drawing.Point(122, 70)
        Me.lblpreview_shelftLife.Name = "lblpreview_shelftLife"
        Me.lblpreview_shelftLife.Size = New System.Drawing.Size(400, 28)
        Me.lblpreview_shelftLife.TabIndex = 6
        Me.lblpreview_shelftLife.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpreview_quantityUnit
        '
        Me.lblpreview_quantityUnit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_quantityUnit.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_quantityUnit.Location = New System.Drawing.Point(321, 37)
        Me.lblpreview_quantityUnit.Name = "lblpreview_quantityUnit"
        Me.lblpreview_quantityUnit.Size = New System.Drawing.Size(201, 28)
        Me.lblpreview_quantityUnit.TabIndex = 4
        Me.lblpreview_quantityUnit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(246, 37)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(75, 28)
        Me.Label20.TabIndex = 5
        Me.Label20.Text = "QTY :"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_productionDate
        '
        Me.lblpreview_productionDate.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_productionDate.Location = New System.Drawing.Point(122, 37)
        Me.lblpreview_productionDate.Name = "lblpreview_productionDate"
        Me.lblpreview_productionDate.Size = New System.Drawing.Size(122, 28)
        Me.lblpreview_productionDate.TabIndex = 2
        Me.lblpreview_productionDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpreview_itemName
        '
        Me.lblpreview_itemName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_itemName.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_itemName.Location = New System.Drawing.Point(122, 4)
        Me.lblpreview_itemName.Name = "lblpreview_itemName"
        Me.lblpreview_itemName.Size = New System.Drawing.Size(400, 28)
        Me.lblpreview_itemName.TabIndex = 1
        Me.lblpreview_itemName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label33
        '
        Me.Label33.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label33.BackColor = System.Drawing.Color.Black
        Me.Label33.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(122, 203)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(400, 28)
        Me.Label33.TabIndex = 26
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.Black
        Me.Label34.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(122, 170)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(215, 28)
        Me.Label34.TabIndex = 25
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label35.BackColor = System.Drawing.Color.Black
        Me.Label35.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(358, 137)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(164, 61)
        Me.Label35.TabIndex = 24
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Black
        Me.Label36.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(122, 137)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(112, 28)
        Me.Label36.TabIndex = 23
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label37.BackColor = System.Drawing.Color.Black
        Me.Label37.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(122, 104)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(400, 28)
        Me.Label37.TabIndex = 22
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label38.BackColor = System.Drawing.Color.Black
        Me.Label38.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(122, 71)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(400, 28)
        Me.Label38.TabIndex = 21
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label39.BackColor = System.Drawing.Color.Black
        Me.Label39.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(321, 38)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(201, 28)
        Me.Label39.TabIndex = 20
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.Black
        Me.Label40.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(122, 38)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(122, 28)
        Me.Label40.TabIndex = 19
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label41.BackColor = System.Drawing.Color.Black
        Me.Label41.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(122, 5)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(400, 28)
        Me.Label41.TabIndex = 18
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblpreview_days
        '
        Me.lblpreview_days.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_days.Location = New System.Drawing.Point(5, 4)
        Me.lblpreview_days.Name = "lblpreview_days"
        Me.lblpreview_days.Size = New System.Drawing.Size(31, 227)
        Me.lblpreview_days.TabIndex = 0
        Me.lblpreview_days.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(39, 202)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(82, 28)
        Me.Label32.TabIndex = 17
        Me.Label32.Text = "REMARKS :"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(39, 169)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(82, 28)
        Me.Label30.TabIndex = 15
        Me.Label30.Text = "MANAGER :"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(39, 136)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(82, 28)
        Me.Label26.TabIndex = 11
        Me.Label26.Text = "EMPLOYEE :"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(39, 103)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(82, 28)
        Me.Label24.TabIndex = 9
        Me.Label24.Text = "TIME-IN :"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(39, 70)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(82, 28)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "SHELFLIFE :"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(39, 37)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(82, 28)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "DATE :"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(39, 4)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 28)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "ITEM :"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(385, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 16)
        Me.Label2.TabIndex = 32
        Me.Label2.Tag = "C"
        Me.Label2.Text = "SHELFLIFE"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtTimeIn
        '
        Me.dtTimeIn.Checked = False
        Me.dtTimeIn.CustomFormat = "MM-dd-yyyy hh:mm tt"
        Me.dtTimeIn.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtTimeIn.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtTimeIn.Location = New System.Drawing.Point(211, 102)
        Me.dtTimeIn.MinDate = New Date(2020, 1, 29, 0, 0, 0, 0)
        Me.dtTimeIn.Name = "dtTimeIn"
        Me.dtTimeIn.Size = New System.Drawing.Size(165, 22)
        Me.dtTimeIn.TabIndex = 3
        Me.dtTimeIn.Tag = "D"
        Me.dtTimeIn.Value = New Date(2021, 8, 1, 7, 0, 0, 0)
        '
        'lblshelflife
        '
        Me.lblshelflife.BackColor = System.Drawing.Color.Transparent
        Me.lblshelflife.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshelflife.ForeColor = System.Drawing.Color.White
        Me.lblshelflife.Location = New System.Drawing.Point(371, 132)
        Me.lblshelflife.Name = "lblshelflife"
        Me.lblshelflife.Size = New System.Drawing.Size(38, 24)
        Me.lblshelflife.TabIndex = 41
        Me.lblshelflife.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.DimGray
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(61, 72)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(148, 22)
        Me.Label5.TabIndex = 10
        Me.Label5.Tag = "C"
        Me.Label5.Text = "PRODUCTION DATE :"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.DimGray
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(61, 40)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(148, 24)
        Me.Label6.TabIndex = 11
        Me.Label6.Tag = "B"
        Me.Label6.Text = "CONDITION :"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.DimGray
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(61, 132)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(148, 24)
        Me.Label10.TabIndex = 19
        Me.Label10.Tag = "E"
        Me.Label10.Text = "QUANTITY :"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblshelflifeBy
        '
        Me.lblshelflifeBy.BackColor = System.Drawing.Color.Transparent
        Me.lblshelflifeBy.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshelflifeBy.ForeColor = System.Drawing.Color.White
        Me.lblshelflifeBy.Location = New System.Drawing.Point(411, 132)
        Me.lblshelflifeBy.Name = "lblshelflifeBy"
        Me.lblshelflifeBy.Size = New System.Drawing.Size(79, 24)
        Me.lblshelflifeBy.TabIndex = 39
        Me.lblshelflifeBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblvalidity
        '
        Me.lblvalidity.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblvalidity.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvalidity.ForeColor = System.Drawing.Color.Lime
        Me.lblvalidity.Location = New System.Drawing.Point(65, 335)
        Me.lblvalidity.Name = "lblvalidity"
        Me.lblvalidity.Size = New System.Drawing.Size(965, 29)
        Me.lblvalidity.TabIndex = 29
        Me.lblvalidity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbldays
        '
        Me.lbldays.BackColor = System.Drawing.Color.DimGray
        Me.lbldays.Font = New System.Drawing.Font("Arial", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldays.ForeColor = System.Drawing.SystemColors.Window
        Me.lbldays.Location = New System.Drawing.Point(9, 8)
        Me.lbldays.Name = "lbldays"
        Me.lbldays.Size = New System.Drawing.Size(41, 319)
        Me.lbldays.TabIndex = 36
        Me.lbldays.Tag = ""
        Me.lbldays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cboquantity
        '
        Me.cboquantity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboquantity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboquantity.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.cboquantity.FormattingEnabled = True
        Me.cboquantity.Location = New System.Drawing.Point(211, 132)
        Me.cboquantity.Name = "cboquantity"
        Me.cboquantity.Size = New System.Drawing.Size(79, 24)
        Me.cboquantity.TabIndex = 4
        Me.cboquantity.Tag = "E"
        '
        'cboremarks
        '
        Me.cboremarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboremarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboremarks.DropDownHeight = 200
        Me.cboremarks.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboremarks.FormattingEnabled = True
        Me.cboremarks.IntegralHeight = False
        Me.cboremarks.Location = New System.Drawing.Point(211, 302)
        Me.cboremarks.Name = "cboremarks"
        Me.cboremarks.Size = New System.Drawing.Size(279, 24)
        Me.cboremarks.TabIndex = 7
        Me.cboremarks.Tag = "J"
        '
        'cboemployee
        '
        Me.cboemployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboemployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboemployee.DropDownHeight = 200
        Me.cboemployee.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboemployee.FormattingEnabled = True
        Me.cboemployee.IntegralHeight = False
        Me.cboemployee.Location = New System.Drawing.Point(211, 237)
        Me.cboemployee.Name = "cboemployee"
        Me.cboemployee.Size = New System.Drawing.Size(279, 24)
        Me.cboemployee.TabIndex = 5
        Me.cboemployee.Tag = "H"
        '
        'cbomanager
        '
        Me.cbomanager.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbomanager.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbomanager.DropDownHeight = 200
        Me.cbomanager.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbomanager.FormattingEnabled = True
        Me.cbomanager.IntegralHeight = False
        Me.cbomanager.Location = New System.Drawing.Point(211, 269)
        Me.cbomanager.Name = "cbomanager"
        Me.cbomanager.Size = New System.Drawing.Size(279, 24)
        Me.cbomanager.TabIndex = 6
        Me.cbomanager.Tag = "I"
        '
        'lblusedBy
        '
        Me.lblusedBy.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.lblusedBy.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusedBy.ForeColor = System.Drawing.Color.White
        Me.lblusedBy.Location = New System.Drawing.Point(211, 202)
        Me.lblusedBy.Name = "lblusedBy"
        Me.lblusedBy.Size = New System.Drawing.Size(279, 23)
        Me.lblusedBy.TabIndex = 17
        Me.lblusedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'dtDate
        '
        Me.dtDate.Checked = False
        Me.dtDate.CustomFormat = "MM-dd-yyyy"
        Me.dtDate.Font = New System.Drawing.Font("Arial", 9.75!)
        Me.dtDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtDate.Location = New System.Drawing.Point(211, 102)
        Me.dtDate.MinDate = New Date(2020, 1, 29, 0, 0, 0, 0)
        Me.dtDate.Name = "dtDate"
        Me.dtDate.Size = New System.Drawing.Size(165, 22)
        Me.dtDate.TabIndex = 2
        Me.dtDate.Tag = "D"
        '
        'dateProduction
        '
        Me.dateProduction.Checked = False
        Me.dateProduction.CustomFormat = "MM/dd/yyyy"
        Me.dateProduction.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dateProduction.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dateProduction.Location = New System.Drawing.Point(211, 72)
        Me.dateProduction.MinDate = New Date(2020, 1, 29, 0, 0, 0, 0)
        Me.dateProduction.Name = "dateProduction"
        Me.dateProduction.ShowCheckBox = True
        Me.dateProduction.Size = New System.Drawing.Size(165, 22)
        Me.dateProduction.TabIndex = 2
        Me.dateProduction.Tag = "C"
        '
        'cboitems
        '
        Me.cboitems.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboitems.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboitems.DropDownHeight = 400
        Me.cboitems.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboitems.FormattingEnabled = True
        Me.cboitems.IntegralHeight = False
        Me.cboitems.Location = New System.Drawing.Point(211, 8)
        Me.cboitems.Name = "cboitems"
        Me.cboitems.Size = New System.Drawing.Size(279, 24)
        Me.cboitems.TabIndex = 0
        Me.cboitems.Tag = "A"
        '
        'picNew
        '
        Me.picNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.picNew.Image = CType(resources.GetObject("picNew.Image"), System.Drawing.Image)
        Me.picNew.Location = New System.Drawing.Point(9, 332)
        Me.picNew.Name = "picNew"
        Me.picNew.Size = New System.Drawing.Size(41, 36)
        Me.picNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picNew.TabIndex = 38
        Me.picNew.TabStop = False
        Me.picNew.Visible = False
        '
        'lblC
        '
        Me.lblC.BackColor = System.Drawing.Color.Black
        Me.lblC.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblC.ForeColor = System.Drawing.Color.White
        Me.lblC.Location = New System.Drawing.Point(59, 70)
        Me.lblC.Name = "lblC"
        Me.lblC.Size = New System.Drawing.Size(433, 26)
        Me.lblC.TabIndex = 14
        Me.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblstorage
        '
        Me.lblstorage.BackColor = System.Drawing.Color.Transparent
        Me.lblstorage.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstorage.ForeColor = System.Drawing.Color.Lime
        Me.lblstorage.Location = New System.Drawing.Point(211, 167)
        Me.lblstorage.Name = "lblstorage"
        Me.lblstorage.Size = New System.Drawing.Size(279, 23)
        Me.lblstorage.TabIndex = 39
        Me.lblstorage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 321)
        Me.Label1.TabIndex = 40
        Me.Label1.Tag = ""
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.DimGray
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(61, 202)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(148, 23)
        Me.Label11.TabIndex = 34
        Me.Label11.Tag = "C"
        Me.Label11.Text = "USE BY ( UNTIL ) :"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.DimGray
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(61, 167)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(148, 23)
        Me.Label14.TabIndex = 25
        Me.Label14.Tag = "G"
        Me.Label14.Text = "STORAGE :"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblG
        '
        Me.lblG.BackColor = System.Drawing.Color.Black
        Me.lblG.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblG.ForeColor = System.Drawing.Color.White
        Me.lblG.Location = New System.Drawing.Point(59, 200)
        Me.lblG.Name = "lblG"
        Me.lblG.Size = New System.Drawing.Size(433, 27)
        Me.lblG.TabIndex = 33
        Me.lblG.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblF
        '
        Me.lblF.BackColor = System.Drawing.Color.White
        Me.lblF.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblF.ForeColor = System.Drawing.Color.White
        Me.lblF.Location = New System.Drawing.Point(59, 165)
        Me.lblF.Name = "lblF"
        Me.lblF.Size = New System.Drawing.Size(433, 27)
        Me.lblF.TabIndex = 26
        Me.lblF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblunit
        '
        Me.lblunit.BackColor = System.Drawing.Color.Transparent
        Me.lblunit.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblunit.ForeColor = System.Drawing.Color.White
        Me.lblunit.Location = New System.Drawing.Point(292, 132)
        Me.lblunit.Name = "lblunit"
        Me.lblunit.Size = New System.Drawing.Size(77, 24)
        Me.lblunit.TabIndex = 39
        Me.lblunit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblE
        '
        Me.lblE.BackColor = System.Drawing.Color.Black
        Me.lblE.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblE.ForeColor = System.Drawing.Color.White
        Me.lblE.Location = New System.Drawing.Point(59, 130)
        Me.lblE.Name = "lblE"
        Me.lblE.Size = New System.Drawing.Size(433, 28)
        Me.lblE.TabIndex = 20
        Me.lblE.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.DimGray
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(61, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(148, 22)
        Me.Label4.TabIndex = 32
        Me.Label4.Tag = "C"
        Me.Label4.Text = "TIME IN :"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblD
        '
        Me.lblD.BackColor = System.Drawing.Color.Black
        Me.lblD.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblD.ForeColor = System.Drawing.Color.White
        Me.lblD.Location = New System.Drawing.Point(59, 100)
        Me.lblD.Name = "lblD"
        Me.lblD.Size = New System.Drawing.Size(319, 26)
        Me.lblD.TabIndex = 30
        Me.lblD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'cbocondition
        '
        Me.cbocondition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbocondition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbocondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbocondition.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbocondition.FormattingEnabled = True
        Me.cbocondition.Location = New System.Drawing.Point(211, 40)
        Me.cbocondition.Name = "cbocondition"
        Me.cbocondition.Size = New System.Drawing.Size(279, 24)
        Me.cbocondition.TabIndex = 1
        Me.cbocondition.Tag = "B"
        '
        'lblB
        '
        Me.lblB.BackColor = System.Drawing.Color.Black
        Me.lblB.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblB.ForeColor = System.Drawing.Color.White
        Me.lblB.Location = New System.Drawing.Point(59, 38)
        Me.lblB.Name = "lblB"
        Me.lblB.Size = New System.Drawing.Size(433, 28)
        Me.lblB.TabIndex = 15
        Me.lblB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.DimGray
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(61, 269)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 24)
        Me.Label3.TabIndex = 25
        Me.Label3.Tag = "G"
        Me.Label3.Text = "MANAGER :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblI
        '
        Me.lblI.BackColor = System.Drawing.Color.Black
        Me.lblI.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblI.ForeColor = System.Drawing.Color.White
        Me.lblI.Location = New System.Drawing.Point(59, 267)
        Me.lblI.Name = "lblI"
        Me.lblI.Size = New System.Drawing.Size(433, 28)
        Me.lblI.TabIndex = 26
        Me.lblI.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.DimGray
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(61, 302)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(148, 24)
        Me.Label15.TabIndex = 25
        Me.Label15.Tag = "G"
        Me.Label15.Text = "REMARKS :"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblJ
        '
        Me.lblJ.BackColor = System.Drawing.Color.Black
        Me.lblJ.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblJ.ForeColor = System.Drawing.Color.White
        Me.lblJ.Location = New System.Drawing.Point(59, 300)
        Me.lblJ.Name = "lblJ"
        Me.lblJ.Size = New System.Drawing.Size(433, 28)
        Me.lblJ.TabIndex = 26
        Me.lblJ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.DimGray
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label17.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(61, 237)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(148, 24)
        Me.Label17.TabIndex = 25
        Me.Label17.Tag = "G"
        Me.Label17.Text = "EMPLOYEE :"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblH
        '
        Me.lblH.BackColor = System.Drawing.Color.Black
        Me.lblH.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblH.ForeColor = System.Drawing.Color.White
        Me.lblH.Location = New System.Drawing.Point(59, 235)
        Me.lblH.Name = "lblH"
        Me.lblH.Size = New System.Drawing.Size(433, 28)
        Me.lblH.TabIndex = 26
        Me.lblH.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.DimGray
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(61, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(148, 24)
        Me.Label7.TabIndex = 12
        Me.Label7.Tag = "A"
        Me.Label7.Text = "ITEM :"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblA
        '
        Me.lblA.BackColor = System.Drawing.Color.Black
        Me.lblA.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblA.ForeColor = System.Drawing.Color.White
        Me.lblA.Location = New System.Drawing.Point(59, 6)
        Me.lblA.Name = "lblA"
        Me.lblA.Size = New System.Drawing.Size(433, 28)
        Me.lblA.TabIndex = 16
        Me.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'setPreview
        '
        Me.setPreview.Enabled = True
        Me.setPreview.Interval = 1000
        '
        'tfocus
        '
        Me.tfocus.Enabled = True
        Me.tfocus.Interval = 500
        '
        'lblproductionDefault
        '
        Me.lblproductionDefault.BackColor = System.Drawing.Color.Transparent
        Me.lblproductionDefault.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblproductionDefault.ForeColor = System.Drawing.Color.Lime
        Me.lblproductionDefault.Location = New System.Drawing.Point(377, 72)
        Me.lblproductionDefault.Name = "lblproductionDefault"
        Me.lblproductionDefault.Size = New System.Drawing.Size(113, 22)
        Me.lblproductionDefault.TabIndex = 45
        Me.lblproductionDefault.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'vw_4_labelInput
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(1058, 788)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_4_labelInput"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.pmain.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.paperOut.ResumeLayout(False)
        CType(Me.picNew, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents cboitems As modComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbocondition As modComboBox
    Friend WithEvents dateProduction As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblC As System.Windows.Forms.Label
    Friend WithEvents lblB As System.Windows.Forms.Label
    Friend WithEvents lblA As System.Windows.Forms.Label
    Friend WithEvents lblusedBy As System.Windows.Forms.Label
    Friend WithEvents lblE As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblF As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents griditemList As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents lblD As System.Windows.Forms.Label
    Friend WithEvents cboquantity As modComboBox
    Friend WithEvents lblG As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents dtTimeIn As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblJ As System.Windows.Forms.Label
    Friend WithEvents lblH As System.Windows.Forms.Label
    Friend WithEvents lblI As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboremarks As modComboBox
    Friend WithEvents cboemployee As modComboBox
    Friend WithEvents cbomanager As modComboBox
    Friend WithEvents lbldays As System.Windows.Forms.Label
    Friend WithEvents btnsave As Button
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents picNew As System.Windows.Forms.PictureBox
    Friend WithEvents lblvalidity As System.Windows.Forms.Label
    Friend WithEvents lblshelflifeBy As System.Windows.Forms.Label
    Friend WithEvents lblstorage As System.Windows.Forms.Label
    Friend WithEvents lblunit As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblshelflife As System.Windows.Forms.Label
    Friend WithEvents dtDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents paperOut As System.Windows.Forms.Panel
    Friend WithEvents lblpreview_days As System.Windows.Forms.Label
    Friend WithEvents lblpreview_itemName As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_productionDate As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_quantityUnit As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_shelftLife As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_employeeName As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_timeIN As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_usedBy As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_remarks As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_manager As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_PM As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_AM As System.Windows.Forms.Label
    Friend WithEvents setPreview As System.Windows.Forms.Timer
    Friend WithEvents tfocus As System.Windows.Forms.Timer
    Friend WithEvents btnsavePrint As System.Windows.Forms.Button
    Friend WithEvents lblproductionDefault As System.Windows.Forms.Label
End Class
