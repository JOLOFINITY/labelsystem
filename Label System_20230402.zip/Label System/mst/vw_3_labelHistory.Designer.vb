﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_labelHistory
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pmain = New System.Windows.Forms.Panel()
        Me.btnprintALL = New System.Windows.Forms.Button()
        Me.llblprinted = New System.Windows.Forms.LinkLabel()
        Me.llblprint = New System.Windows.Forms.LinkLabel()
        Me.btncommand = New System.Windows.Forms.Button()
        Me.txtsearch = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.rbdeleted = New System.Windows.Forms.RadioButton()
        Me.rbprinted = New System.Windows.Forms.RadioButton()
        Me.rbprint = New System.Windows.Forms.RadioButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.griditemList = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DELETE = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.pmain.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.llblprinted)
        Me.pmain.Controls.Add(Me.llblprint)
        Me.pmain.Controls.Add(Me.btnprintALL)
        Me.pmain.Controls.Add(Me.btncommand)
        Me.pmain.Controls.Add(Me.txtsearch)
        Me.pmain.Controls.Add(Me.Label3)
        Me.pmain.Controls.Add(Me.Label2)
        Me.pmain.Controls.Add(Me.rbdeleted)
        Me.pmain.Controls.Add(Me.rbprinted)
        Me.pmain.Controls.Add(Me.rbprint)
        Me.pmain.Controls.Add(Me.Panel1)
        Me.pmain.Location = New System.Drawing.Point(2, 2)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(1064, 707)
        Me.pmain.TabIndex = 0
        '
        'btnprintALL
        '
        Me.btnprintALL.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnprintALL.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnprintALL.Location = New System.Drawing.Point(795, 67)
        Me.btnprintALL.Name = "btnprintALL"
        Me.btnprintALL.Size = New System.Drawing.Size(259, 34)
        Me.btnprintALL.TabIndex = 22
        Me.btnprintALL.Text = "(QUICK) PRINT ALL"
        Me.btnprintALL.UseVisualStyleBackColor = True
        '
        'llblprinted
        '
        Me.llblprinted.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblprinted.BackColor = System.Drawing.Color.White
        Me.llblprinted.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblprinted.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.llblprinted.Location = New System.Drawing.Point(773, 20)
        Me.llblprinted.Name = "llblprinted"
        Me.llblprinted.Size = New System.Drawing.Size(126, 41)
        Me.llblprinted.TabIndex = 21
        Me.llblprinted.TabStop = True
        Me.llblprinted.Text = ">CHECK ALL"
        Me.llblprinted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'llblprint
        '
        Me.llblprint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblprint.BackColor = System.Drawing.Color.White
        Me.llblprint.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblprint.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.llblprint.Location = New System.Drawing.Point(516, 20)
        Me.llblprint.Name = "llblprint"
        Me.llblprint.Size = New System.Drawing.Size(126, 41)
        Me.llblprint.TabIndex = 21
        Me.llblprint.TabStop = True
        Me.llblprint.Text = ">CHECK ALL"
        Me.llblprint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btncommand
        '
        Me.btncommand.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btncommand.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btncommand.Location = New System.Drawing.Point(464, 67)
        Me.btncommand.Name = "btncommand"
        Me.btncommand.Size = New System.Drawing.Size(326, 34)
        Me.btncommand.TabIndex = 20
        Me.btncommand.Text = "PRINT / DELETE CHECKED"
        Me.btncommand.UseVisualStyleBackColor = True
        '
        'txtsearch
        '
        Me.txtsearch.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtsearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtsearch.Font = New System.Drawing.Font("MS Gothic", 18.0!)
        Me.txtsearch.Location = New System.Drawing.Point(464, 113)
        Me.txtsearch.MaxLength = 32
        Me.txtsearch.Name = "txtsearch"
        Me.txtsearch.Size = New System.Drawing.Size(597, 31)
        Me.txtsearch.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("MS Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(461, 31)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "SEARCH LABEL INFORMATION:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.Label2.Location = New System.Drawing.Point(3, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(322, 41)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "LABEL STATUS   :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'rbdeleted
        '
        Me.rbdeleted.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbdeleted.BackColor = System.Drawing.Color.White
        Me.rbdeleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbdeleted.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbdeleted.Location = New System.Drawing.Point(928, 20)
        Me.rbdeleted.Name = "rbdeleted"
        Me.rbdeleted.Size = New System.Drawing.Size(126, 41)
        Me.rbdeleted.TabIndex = 17
        Me.rbdeleted.Text = "DELETED"
        Me.rbdeleted.UseVisualStyleBackColor = False
        '
        'rbprinted
        '
        Me.rbprinted.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbprinted.BackColor = System.Drawing.Color.White
        Me.rbprinted.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbprinted.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbprinted.Location = New System.Drawing.Point(664, 20)
        Me.rbprinted.Name = "rbprinted"
        Me.rbprinted.Size = New System.Drawing.Size(126, 41)
        Me.rbprinted.TabIndex = 17
        Me.rbprinted.Text = "PRINTED"
        Me.rbprinted.UseVisualStyleBackColor = False
        '
        'rbprint
        '
        Me.rbprint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbprint.BackColor = System.Drawing.Color.White
        Me.rbprint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rbprint.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbprint.Location = New System.Drawing.Point(346, 20)
        Me.rbprint.Name = "rbprint"
        Me.rbprint.Size = New System.Drawing.Size(180, 41)
        Me.rbprint.TabIndex = 17
        Me.rbprint.Text = "FOR PRINTING"
        Me.rbprint.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.griditemList)
        Me.Panel1.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(3, 147)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1058, 557)
        Me.Panel1.TabIndex = 16
        '
        'griditemList
        '
        Me.griditemList.AllowUserToAddRows = False
        Me.griditemList.AllowUserToDeleteRows = False
        Me.griditemList.AllowUserToResizeColumns = False
        Me.griditemList.AllowUserToResizeRows = False
        Me.griditemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.griditemList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.griditemList.BackgroundColor = System.Drawing.Color.White
        Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.griditemList.ColumnHeadersHeight = 36
        Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.DELETE})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.griditemList.DefaultCellStyle = DataGridViewCellStyle2
        Me.griditemList.Dock = System.Windows.Forms.DockStyle.Fill
        Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.griditemList.EnableHeadersVisualStyles = False
        Me.griditemList.Location = New System.Drawing.Point(0, 0)
        Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.griditemList.MultiSelect = False
        Me.griditemList.Name = "griditemList"
        Me.griditemList.ReadOnly = True
        Me.griditemList.RowHeadersVisible = False
        Me.griditemList.RowTemplate.Height = 28
        Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.griditemList.ShowCellErrors = False
        Me.griditemList.ShowCellToolTips = False
        Me.griditemList.ShowEditingIcon = False
        Me.griditemList.ShowRowErrors = False
        Me.griditemList.Size = New System.Drawing.Size(1058, 557)
        Me.griditemList.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "SELECT"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 68
        '
        'Column2
        '
        Me.Column2.HeaderText = "PRINT"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 59
        '
        'DELETE
        '
        Me.DELETE.HeaderText = "DELETE"
        Me.DELETE.Name = "DELETE"
        Me.DELETE.ReadOnly = True
        Me.DELETE.Width = 68
        '
        'vw_3_labelHistory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(1068, 711)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_3_labelHistory"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.pmain.ResumeLayout(False)
        Me.pmain.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents griditemList As System.Windows.Forms.DataGridView
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents rbprint As System.Windows.Forms.RadioButton
	Friend WithEvents rbprinted As System.Windows.Forms.RadioButton
	Friend WithEvents rbdeleted As System.Windows.Forms.RadioButton
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents txtsearch As System.Windows.Forms.TextBox
	Friend WithEvents btncommand As System.Windows.Forms.Button
	Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
	Friend WithEvents Column2 As System.Windows.Forms.DataGridViewCheckBoxColumn
	Friend WithEvents DELETE As System.Windows.Forms.DataGridViewCheckBoxColumn
	Friend WithEvents llblprint As System.Windows.Forms.LinkLabel
    Friend WithEvents llblprinted As System.Windows.Forms.LinkLabel
    Friend WithEvents btnprintALL As System.Windows.Forms.Button
End Class
