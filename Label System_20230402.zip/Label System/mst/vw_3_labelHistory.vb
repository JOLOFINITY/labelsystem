﻿Imports System.Runtime.InteropServices
Public Class vw_3_labelHistory
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
    End Function

    Private Sub vw_3_labelHistory_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dispose()
    End Sub

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
        End If
    End Sub

    Private Const SM_CXSCREEN As Integer = 0
    Private Const SM_CYSCREEN As Integer = 1
    Private Shared HWND_TOP As IntPtr = IntPtr.Zero
    Private Const SWP_SHOWWINDOW As Integer = 64

    Private winState As FormWindowState
    Private brdStyle As FormBorderStyle
    Private isTopMost As Boolean
    Private isBounds As Rectangle

    <DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
    Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

    End Function
    <DllImport("user32.dll")>
    Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

    End Sub
    Public Shared ReadOnly Property ScreenX As Integer
        Get
            Return GetSystemMetrics(SM_CXSCREEN)
        End Get
    End Property

    Public Shared ReadOnly Property ScreenY As Integer
        Get
            Return GetSystemMetrics(SM_CYSCREEN)
        End Get
    End Property

    Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
        SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
    End Sub

    Private IsMaximized As Boolean = False
    Public Sub Save(ByVal targetForm As Form)
        winState = targetForm.WindowState
        brdStyle = targetForm.FormBorderStyle
        isTopMost = targetForm.TopMost
        isBounds = targetForm.Bounds
    End Sub
#End Region
    Private Sub rbprint_CheckedChanged(sender As Object, e As EventArgs) Handles rbprint.CheckedChanged
        Call getPrintLabelHistory(0, griditemList)

        griditemList.Columns(1).Visible = True
        griditemList.Columns(2).Visible = True
    End Sub
    Private Sub rbprinted_CheckedChanged(sender As Object, e As EventArgs) Handles rbprinted.CheckedChanged
		Call getPrintLabelHistory(1, griditemList)

		griditemList.Columns(1).Visible = False
		griditemList.Columns(2).Visible = False
	End Sub

	Private Sub rbdeleted_CheckedChanged(sender As Object, e As EventArgs) Handles rbdeleted.CheckedChanged
		Call getPrintLabelHistory(2, griditemList)

		griditemList.Columns(1).Visible = False
		griditemList.Columns(2).Visible = False
	End Sub
	Private Sub llblprint_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblprint.LinkClicked
		With griditemList
			For i = 0 To .Rows.Count - 1
				If rbprint.Checked Then
					.Rows(i).Cells(2).Value = False
					If .Rows(i).Cells(1).Value = True Then
						.Rows(i).Cells(1).Value = False
					Else
						.Rows(i).Cells(1).Value = True
					End If
				End If
			Next
		End With
	End Sub
    Private Sub llblprinted_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblprinted.LinkClicked
        With griditemList
            For i = 0 To .Rows.Count - 1
                If rbprint.Checked Or rbprinted.Checked Then
                    .Rows(i).Cells(1).Value = False
                    If .Rows(i).Cells(2).Value = True Then
                        .Rows(i).Cells(2).Value = False
                    Else
                        .Rows(i).Cells(2).Value = True
                    End If
                End If
            Next
        End With
    End Sub
    Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
		With griditemList
			If e.RowIndex >= 0 And e.ColumnIndex = 1 And rbprint.Checked Then
				.Rows(e.RowIndex).Cells(2).Value = False
				If .Rows(e.RowIndex).Cells(1).Value = True Then
					.Rows(e.RowIndex).Cells(1).Value = False
				Else
					.Rows(e.RowIndex).Cells(1).Value = True
				End If
			ElseIf e.RowIndex >= 0 And e.ColumnIndex = 2 And (rbprint.Checked Or rbprinted.Checked) Then
				.Rows(e.RowIndex).Cells(1).Value = False
				If .Rows(e.RowIndex).Cells(2).Value = True Then
					.Rows(e.RowIndex).Cells(2).Value = False
				Else
					.Rows(e.RowIndex).Cells(2).Value = True
				End If
			End If
		End With
	End Sub
    Private Sub btncommand_Click(sender As Object, e As EventArgs) Handles btncommand.Click
        With griditemList
            For i = 0 To griditemList.Rows.Count - 1
                If .Rows(i).Cells(2).Value = True Then
                    Call updateLabelHistory(.Rows(i).Cells(14).Value, 2)
                ElseIf .Rows(i).Cells(1).Value = True Then
                    With cReport
                        .DataSourceConnections.Clear()
                        .SetDataSource(getLabeltoPrint(griditemList.Rows(i).Cells(14).Value))
                        .PrintToPrinter(1, False, 0, 0)
                    End With

                    Call updateLabelHistory(.Rows(i).Cells(14).Value, 1)

                    Application.DoEvents()
                End If
            Next
        End With

        If rbprint.Checked Then
            Call getPrintLabelHistory(0, griditemList)
        ElseIf rbprinted.Checked Then
            Call getPrintLabelHistory(1, griditemList)
        Else
            Call getPrintLabelHistory(2, griditemList)
        End If
    End Sub
    Private Sub txtsearch_TextChanged(sender As Object, e As EventArgs) Handles txtsearch.TextChanged
        _exec_gridSearch(griditemList, txtsearch.Text)
    End Sub

    Private Sub btnprintALL_Click(sender As Object, e As EventArgs) Handles btnprintALL.Click
        Dim UID As String = String.Empty
        If MessageBox.Show("this will print all PENDING labels not yet PRINTED" & vbNewLine & vbNewLine & "Select [YES] to print all, [NO] to cancel.", "User Input", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            rbprint.Checked = True

            Dim toPrint = qPrint()

            If toPrint.Rows.Count >= 1 Then
                For i = 0 To toPrint.Rows.Count - 1
                    Dim fil = toPrint.Select("`UID` = '" & toPrint.Rows(i)("UID").ToString.Trim & "'").CopyToDataTable()
                    With cReport
                        .DataSourceConnections.Clear()
                        .SetDataSource(fil)
                        .PrintToPrinter(1, False, 0, 0)
                    End With

                    UID &= "'" & toPrint.Rows(i)("UID").ToString.Trim & "',"
                Next

                UID = Mid(UID, 1, UID.Length - 1)

                updateUIDs(UID)

            End If

            Call getPrintLabelHistory(0, griditemList)
        End If
    End Sub
End Class