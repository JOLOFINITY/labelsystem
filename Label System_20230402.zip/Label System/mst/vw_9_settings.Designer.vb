﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class vw_9_settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_9_settings))
        Me.gridsettings = New System.Windows.Forms.DataGridView()
        Me.Column2 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtvalues = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblprinted = New System.Windows.Forms.Label()
        Me.llblresetData = New System.Windows.Forms.LinkLabel()
        CType(Me.gridsettings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'gridsettings
        '
        Me.gridsettings.AllowUserToAddRows = False
        Me.gridsettings.AllowUserToDeleteRows = False
        Me.gridsettings.AllowUserToResizeColumns = False
        Me.gridsettings.AllowUserToResizeRows = False
        Me.gridsettings.BackgroundColor = System.Drawing.Color.White
        Me.gridsettings.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.gridsettings.ColumnHeadersHeight = 30
        Me.gridsettings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.gridsettings.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column2, Me.Column1, Me.Column4, Me.Column3})
        Me.gridsettings.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gridsettings.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.gridsettings.Location = New System.Drawing.Point(0, 0)
        Me.gridsettings.Margin = New System.Windows.Forms.Padding(5)
        Me.gridsettings.Name = "gridsettings"
        Me.gridsettings.ReadOnly = True
        Me.gridsettings.RowHeadersVisible = False
        Me.gridsettings.RowTemplate.Height = 40
        Me.gridsettings.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.gridsettings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.gridsettings.ShowCellErrors = False
        Me.gridsettings.ShowCellToolTips = False
        Me.gridsettings.ShowEditingIcon = False
        Me.gridsettings.ShowRowErrors = False
        Me.gridsettings.Size = New System.Drawing.Size(1257, 327)
        Me.gridsettings.TabIndex = 0
        '
        'Column2
        '
        Me.Column2.HeaderText = ""
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.Column2.Width = 80
        '
        'Column1
        '
        Me.Column1.HeaderText = "PARAMETER"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.Column1.Width = 190
        '
        'Column4
        '
        Me.Column4.HeaderText = "VALUE"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        Me.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.Column4.Width = 180
        '
        'Column3
        '
        Me.Column3.HeaderText = "DESCRIPTION"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 800
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.gridsettings)
        Me.Panel1.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(3, 115)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1257, 327)
        Me.Panel1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1222, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "SETTING VALUE(S) : Please always check the coorect value before saving, this migh" &
    "t affect the System."
        '
        'txtvalues
        '
        Me.txtvalues.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtvalues.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtvalues.Location = New System.Drawing.Point(198, 72)
        Me.txtvalues.Name = "txtvalues"
        Me.txtvalues.Size = New System.Drawing.Size(1062, 34)
        Me.txtvalues.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(30, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(162, 27)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "NEW VALUE:"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("MS Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 489)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(410, 44)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "TOTAL NO OF PRINTED LABEL(S):"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblprinted
        '
        Me.lblprinted.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblprinted.BackColor = System.Drawing.Color.White
        Me.lblprinted.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblprinted.Font = New System.Drawing.Font("Consolas", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblprinted.Location = New System.Drawing.Point(414, 489)
        Me.lblprinted.Name = "lblprinted"
        Me.lblprinted.Size = New System.Drawing.Size(183, 44)
        Me.lblprinted.TabIndex = 2
        Me.lblprinted.Text = "0"
        Me.lblprinted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'llblresetData
        '
        Me.llblresetData.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.llblresetData.AutoSize = True
        Me.llblresetData.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblresetData.Location = New System.Drawing.Point(606, 500)
        Me.llblresetData.Name = "llblresetData"
        Me.llblresetData.Size = New System.Drawing.Size(208, 27)
        Me.llblresetData.TabIndex = 4
        Me.llblresetData.TabStop = True
        Me.llblresetData.Text = "RESET DATA...."
        '
        'vw_9_settings
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1263, 578)
        Me.Controls.Add(Me.llblresetData)
        Me.Controls.Add(Me.txtvalues)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblprinted)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(5)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "vw_9_settings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Local Setting(S)"
        CType(Me.gridsettings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents gridsettings As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtvalues As System.Windows.Forms.TextBox
    Friend WithEvents Column2 As DataGridViewButtonColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblprinted As Label
    Friend WithEvents llblresetData As LinkLabel
End Class
