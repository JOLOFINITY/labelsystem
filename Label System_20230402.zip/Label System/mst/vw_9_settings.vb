﻿Public Class vw_9_settings
    Private Sub vw_5_settings_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dispose()

        vw_1_menu.panelMenu.Visible = True
    End Sub
    Private Sub vw_5_settings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		Call getSettings()
	End Sub
	Private Sub getSettings()

        With gridsettings
            .Rows.Clear()
            .Rows.Add()
            .Rows(.Rows.Count - 1).Cells(0).Value = "EDIT"
            .Rows(.Rows.Count - 1).Cells(1).Value = "POS Printer"
            .Rows(.Rows.Count - 1).Cells(2).Value = My.Settings.defaultPrinter
            .Rows(.Rows.Count - 1).Cells(3).Value = "NAME OF PRITNER INSTALLED FOR LABEL PRINTING"

            .Rows.Add()
            .Rows(.Rows.Count - 1).Cells(0).Value = "EDIT"
            .Rows(.Rows.Count - 1).Cells(1).Value = "Check Prod.Date"
            .Rows(.Rows.Count - 1).Cells(2).Value = My.Settings.check_ProductionDate
            .Rows(.Rows.Count - 1).Cells(3).Value = "CHECK DEFAULT VALUE OF PRODUCTION DATE, 0 = NO CHECK , 1 = AUTO CHECKED"

            .Rows.Add()
            .Rows(.Rows.Count - 1).Cells(0).Value = "EDIT"
            .Rows(.Rows.Count - 1).Cells(1).Value = "AUTO LOGOUT"
            .Rows(.Rows.Count - 1).Cells(2).Value = My.Settings.CloseTime
            .Rows(.Rows.Count - 1).Cells(3).Value = "Idle time before Auto LOG-OUT of User"

            .Rows.Add()
            .Rows(.Rows.Count - 1).Cells(0).Value = "EDIT"
            .Rows(.Rows.Count - 1).Cells(1).Value = "LOGOUT WARNING"
            .Rows(.Rows.Count - 1).Cells(2).Value = My.Settings.WarningTime
            .Rows(.Rows.Count - 1).Cells(3).Value = "Warning Auto Logout"

            .ClearSelection()
        End With

        lblprinted.Text = getPrintCount()
    End Sub
	Private Sub gridsettings_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridsettings.CellClick
        If e.ColumnIndex = 0 And e.RowIndex >= 0 Then
            With gridsettings

                Dim boolSAVE As Boolean = False

                For i = 0 To .Rows.Count - 1
                    If .Rows(i).Cells(0).Value = "SAVE" Then
                        boolSAVE = True
                        Exit For
                    End If
                Next

                If boolSAVE Then
                    If .Rows(e.RowIndex).Cells(0).Value = "SAVE" Then
                        .Rows(e.RowIndex).Cells(0).Value = "EDIT"
                        .Rows(e.RowIndex).Cells(2).Value = txtvalues.Text

                        If .Rows(e.RowIndex).Cells(1).Value = "POS Printer" Then
                            My.Settings.defaultPrinter = txtvalues.Text

                        ElseIf .Rows(e.RowIndex).Cells(1).Value = "Check Prod.Date" Then
                            If txtvalues.Text = 0 Or txtvalues.Text = 1 Then
                                My.Settings.check_ProductionDate = txtvalues.Text
                            Else
                                MessageBox.Show("Invalid Value, Please enter 0 and 1 only.", "Invalid Iinput.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                        ElseIf .Rows(e.RowIndex).Cells(1).Value = "AUTO LOGOUT" Then
                            Dim tm As New TimeSpan
                            If TimeSpan.TryParse(txtvalues.Text, tm) Then
                                My.Settings.CloseTime = tm
                            Else
                                MessageBox.Show("Invalid Time FORMAT or TIME set.", "Invalid Iinput.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                        ElseIf .Rows(e.RowIndex).Cells(1).Value = "LOGOUT WARNING" Then
                            Dim tm As New TimeSpan
                            If TimeSpan.TryParse(txtvalues.Text, tm) Then
                                My.Settings.WarningTime = tm
                            Else
                                MessageBox.Show("Invalid Time FORMAT or TIME set.", "Invalid Iinput.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            End If

                        End If

                        My.Settings.Save()

                        .ClearSelection()
                        txtvalues.Clear()

                    Else
                        .ClearSelection()
                    End If
                Else
                    .Rows(e.RowIndex).Cells(0).Value = "SAVE"
                    .ClearSelection()

                    txtvalues.Text = .Rows(e.RowIndex).Cells(2).Value.ToString
                    txtvalues.SelectAll()
                    txtvalues.Focus()
                End If
            End With
        End If
    End Sub

    Private Sub llblresetData_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblresetData.LinkClicked
        lblprinted.Text = "0"

        resetData()
    End Sub
End Class