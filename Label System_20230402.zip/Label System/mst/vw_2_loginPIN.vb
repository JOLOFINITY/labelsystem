﻿Imports System.Runtime.InteropServices
Public Class vw_2_loginPIN
#Region "MOVING"
    Public Const WM_NCLBUTTONDOWN As Integer = 161
    Public Const HT_CAPTION As Integer = 2

    <DllImportAttribute("User32.dll")> _
    Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
    End Function
    <DllImportAttribute("User32.dll")> _
    Public Shared Function ReleaseCapture() As Boolean
    End Function

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
        End If
    End Sub

    Private Const SM_CXSCREEN As Integer = 0
    Private Const SM_CYSCREEN As Integer = 1
    Private Shared HWND_TOP As IntPtr = IntPtr.Zero
    Private Const SWP_SHOWWINDOW As Integer = 64

    Private winState As FormWindowState
    Private brdStyle As FormBorderStyle
    Private isTopMost As Boolean
    Private isBounds As Rectangle

    <DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
    Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

    End Function
    <DllImport("user32.dll")>
    Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

    End Sub
    Public Shared ReadOnly Property ScreenX As Integer
        Get
            Return GetSystemMetrics(SM_CXSCREEN)
        End Get
    End Property

    Public Shared ReadOnly Property ScreenY As Integer
        Get
            Return GetSystemMetrics(SM_CYSCREEN)
        End Get
    End Property

    Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
        SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
    End Sub

    Private IsMaximized As Boolean = False
    Public Sub Maximize(ByVal targetForm As Form)
        If Not IsMaximized Then
            IsMaximized = True
            Save(targetForm)
            targetForm.WindowState = FormWindowState.Maximized
            targetForm.FormBorderStyle = FormBorderStyle.None
            targetForm.TopMost = True
            SetWinFullScreen(targetForm.Handle)
        End If
    End Sub
    Public Sub Save(ByVal targetForm As Form)
        winState = targetForm.WindowState
        brdStyle = targetForm.FormBorderStyle
        isTopMost = targetForm.TopMost
        isBounds = targetForm.Bounds
    End Sub
    Public Sub Restore(ByVal targetForm As Form)
        targetForm.WindowState = winState
        targetForm.FormBorderStyle = brdStyle
        targetForm.TopMost = isTopMost
        targetForm.Bounds = isBounds
        IsMaximized = False
    End Sub


#End Region
    Private Sub vw_2_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Debugger.IsAttached Then txtname.Text = "JOLO"
        roundCorners(Me, Color.White)
    End Sub
    Sub login()
        If txtname.Text.Length > 2 Then
            login_username = txtname.Text

            Call log_User("LOGIN", login_username)

            vw_1_menu.menu_admin()
            vw_1_menu.applicationIdle.Start()

            Dispose()
        Else
            txtname.SelectAll()
            txtname.Focus()
        End If
    End Sub
    Private Sub vw_2_loginPIN_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Top = 0
    End Sub
    Private Sub txtname_KeyDown(sender As Object, e As KeyEventArgs) Handles txtname.KeyDown
        If e.KeyCode = Keys.Enter Then
            login()
        End If
    End Sub

    Private Sub btnlogin_Click_1(sender As Object, e As EventArgs)
        login()
    End Sub

    Private Sub btnP_Click(sender As Object, e As EventArgs) Handles btnZ.Click, btnY.Click, btnX.Click, btnW.Click, btnV.Click, btnU.Click, btnT.Click, btnSPACE.Click, btnS.Click, btnR.Click, btnQ.Click, btnP.Click, btnO.Click, btnN.Click, btnM.Click, btnL.Click, btnK.Click, btnJ.Click, btnI.Click, btnH.Click, btnG.Click, btnF.Click, btnENTER.Click, btnE.Click, btnDELETE.Click, btnD.Click, btnC.Click, btnB.Click, btnA.Click
        Dim btn As Button = sender

        If btn.Text = "" Then
            If txtname.Text <> String.Empty Then
                txtname.Text = Mid(txtname.Text, 1, txtname.TextLength - 1)
            End If
        ElseIf btn.Text = "SPACE" Then
            txtname.Text &= " "
        ElseIf btn.Text = "ENTER / LOGIN" Then
            login()
        Else
            txtname.Text &= btn.Text
        End If

        txtname.Focus()
    End Sub
End Class