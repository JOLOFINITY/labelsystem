﻿Public Class CALENDAR
	Private boolStart As Boolean = False
	Private _DateValue As Date
	Friend Property DateValue() As Date
		Get
			Return _DateValue
		End Get
		Set(ByVal Value As Date)
			_DateValue = Value
		End Set
	End Property



	Private Sub LoadYears()
		Dim ctr As Integer
		Dim start_year As Integer = 2018
		For ctr = 0 To (2050 - 2018) - 1
			With cboYear
				.Items.Add(start_year + ctr)
			End With
		Next
	End Sub
	Private Sub CALENDAR_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		LoadYears()

		cboMonth.Text = _DateValue.ToString("MMMM")
		cboday.Text = _DateValue.ToString("dd")
		cboYear.Text = _DateValue.ToString("yyyy")

		boolStart = True
	End Sub
	Private Sub cboMonth_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
		 Handles cboMonth.SelectedIndexChanged, cboday.SelectedIndexChanged, cboYear.SelectedIndexChanged

		If boolStart Then
			If cboMonth.Text.Length <> 0 And cboday.Text.Length <> 0 And cboYear.Text.Length <> 0 Then
				Dim strDate As String = "#" & cboMonth.Text & "/" & cboday.Text & "/" & cboYear.Text & "#"
				If IsDate(strDate) Then
					'MonthCalendar1.SelectionStart = CDate(strDate)
				Else
					MessageBox.Show("Not a Valid Date!", "Invalid Date!", MessageBoxButtons.OK, MessageBoxIcon.Error)
					cboMonth.Text = _DateValue.ToString("MMMM")
					cboday.Text = _DateValue.ToString("dd")
					cboYear.Text = _DateValue.ToString("yyyy")
				End If
			End If
		End If
	End Sub
	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnnext.Click
		If intFOCUS = 1 Then
			cboday.Focus()

			If IsNumeric(cboMonth.Text) Then
				If CInt(cboMonth.Text) >= 13 Then
				Else
					cboMonth.Text = cboMonth.Items(CInt(cboMonth.Text) - 1)
				End If
			Else
			End If
		ElseIf intFOCUS = 2 Then
			Dim d As String = "000" & cboday.Text
			d = Mid(d, d.Length - 1, 2)
			cboday.Text = d

			If cboday.Items.Contains(cboday.Text) Then
				cboYear.Focus()
			Else
				cboday.Text = String.Empty
				cboday.Focus()
			End If
		Else
			cboMonth.Focus()
		End If
	End Sub

	Private intFOCUS As Integer = 1
	Private Sub cboMonth_Enter(sender As Object, e As EventArgs) Handles cboYear.Enter, cboMonth.Enter, cboday.Enter
		Dim cb As ComboBox = sender

		If cb.Name = cboMonth.Name Then
			intFOCUS = 1
		ElseIf cb.Name = cboday.Name Then
			intFOCUS = 2
		Else
			intFOCUS = 3
		End If
	End Sub

	Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
		If intFOCUS = 1 Then
			cboMonth.Text = String.Empty
		ElseIf intFOCUS = 2 Then
			cboday.Text = String.Empty
		Else
			cboYear.Text = String.Empty
		End If
	End Sub

	Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn9.Click, btn8.Click, btn7.Click, btn6.Click, btn5.Click, btn4.Click, btn3.Click, btn2.Click, btn1.Click, btn0.Click
		Dim btn As Button = sender

		If intFOCUS = 1 Then
			If IsNumeric(cboMonth.Text) = False Then cboMonth.Text = ""
			cboMonth.Text &= btn.Text
		ElseIf intFOCUS = 2 Then
			cboday.Text &= btn.Text

			If IsNumeric(cboday.Text) Then
				If CInt(cboday.Text) >= 32 Then
					cboday.Text = ""
					cboday.Text = btn.Text
				Else

				End If
			End If
			
		Else
			cboYear.Text &= btn.Text

			If cboYear.Text.Length = 4 Then
				If CInt(cboYear.Text) <= cboYear.Items(cboYear.Items.Count - 1) And CInt(cboYear.Text) >= cboYear.Items(0) Then
				Else
					cboYear.Text = ""
				End If
			ElseIf cboYear.Text.Length > 4 Then
				cboYear.Text = ""
			End If
			
		End If
	End Sub

	Private Sub btnokayClose_Click(sender As Object, e As EventArgs) Handles btnokayClose.Click
		Dim toNo As String = ""

		If cboMonth.Items.Contains(cboMonth.Text) Then
			toNo = cboMonth.Items.IndexOf(cboMonth.Text) + 1
		Else
			toNo = cboMonth.Text
		End If

		Dim mons = "000" & toNo
		mons = Mid(mons, mons.Length - 1, 2)

		Dim day = "000" & cboday.Text
		day = Mid(day, day.Length - 1, 2)

		Dim strDate As String = cboYear.Text & "-" & mons & "-" & day
		If IsDate(strDate) Then
			_DateValue = CDate(strDate).ToString("yyyy-MM-dd")
			Close()
		Else
			MessageBox.Show("Not a Valid Date!", "Invalid Date!", MessageBoxButtons.OK, MessageBoxIcon.Error)
			cboMonth.Text = DateAndTime.Now.ToString("MM")
			cboday.Text = DateAndTime.Now.ToString("dd")
			cboYear.Text = DateAndTime.Now.ToString("yyyy")

			cboMonth.SelectAll() : cboMonth.Focus()

			intFOCUS = 0
		End If
	End Sub


End Class