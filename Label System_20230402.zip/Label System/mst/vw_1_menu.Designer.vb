﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class vw_1_menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_1_menu))
        Me.pmain = New System.Windows.Forms.Panel()
        Me.panelheader = New System.Windows.Forms.Panel()
        Me.llblhide = New System.Windows.Forms.LinkLabel()
        Me.llblmaximized = New System.Windows.Forms.LinkLabel()
        Me.updater = New System.Windows.Forms.PictureBox()
        Me.lblclose = New System.Windows.Forms.LinkLabel()
        Me.lblheader = New System.Windows.Forms.Label()
        Me.lblheaderSub = New System.Windows.Forms.Label()
        Me.pfooter = New System.Windows.Forms.Panel()
        Me.statusStrip = New System.Windows.Forms.StatusStrip()
        Me.lblRemainingCaption = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblRemaining = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblActivity = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblElapsedCaption = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblElapsed = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblstatus = New System.Windows.Forms.Label()
        Me.picdownloading = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pController = New System.Windows.Forms.Panel()
        Me.panelMenu = New System.Windows.Forms.Panel()
        Me.lbldatetime = New System.Windows.Forms.Label()
        Me.btnitemMain = New System.Windows.Forms.Button()
        Me.btnlabelHistory = New System.Windows.Forms.Button()
        Me.btnsetting = New System.Windows.Forms.Button()
        Me.btnlabelPrinting = New System.Windows.Forms.Button()
        Me.getDateTime = New System.Windows.Forms.Timer(Me.components)
        Me.applicationIdle = New Winforms.Components.ApplicationIdle()
        Me.PanelLocalDT = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.DTPickerLocalDateTime = New System.Windows.Forms.DateTimePicker()
        Me.ButtonSetLocalDT = New System.Windows.Forms.Button()
        Me.LabelLocalDateTime = New System.Windows.Forms.Label()
        Me.pmain.SuspendLayout()
        Me.panelheader.SuspendLayout()
        CType(Me.updater, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pfooter.SuspendLayout()
        Me.statusStrip.SuspendLayout()
        CType(Me.picdownloading, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pController.SuspendLayout()
        Me.panelMenu.SuspendLayout()
        Me.PanelLocalDT.SuspendLayout()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.panelheader)
        Me.pmain.Controls.Add(Me.pfooter)
        Me.pmain.Controls.Add(Me.Label1)
        Me.pmain.Controls.Add(Me.pController)
        Me.pmain.Location = New System.Drawing.Point(2, 4)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(1008, 750)
        Me.pmain.TabIndex = 0
        '
        'panelheader
        '
        Me.panelheader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelheader.BackColor = System.Drawing.Color.DodgerBlue
        Me.panelheader.Controls.Add(Me.PanelLocalDT)
        Me.panelheader.Controls.Add(Me.llblhide)
        Me.panelheader.Controls.Add(Me.llblmaximized)
        Me.panelheader.Controls.Add(Me.updater)
        Me.panelheader.Controls.Add(Me.lblclose)
        Me.panelheader.Controls.Add(Me.lblheader)
        Me.panelheader.Controls.Add(Me.lblheaderSub)
        Me.panelheader.Location = New System.Drawing.Point(1, 1)
        Me.panelheader.Name = "panelheader"
        Me.panelheader.Size = New System.Drawing.Size(1006, 54)
        Me.panelheader.TabIndex = 19
        '
        'llblhide
        '
        Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblhide.AutoSize = True
        Me.llblhide.Font = New System.Drawing.Font("Arial Narrow", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.llblhide.LinkColor = System.Drawing.Color.Black
        Me.llblhide.Location = New System.Drawing.Point(821, 2)
        Me.llblhide.Name = "llblhide"
        Me.llblhide.Size = New System.Drawing.Size(45, 42)
        Me.llblhide.TabIndex = 2
        Me.llblhide.TabStop = True
        Me.llblhide.Text = "◣"
        Me.llblhide.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'llblmaximized
        '
        Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblmaximized.AutoSize = True
        Me.llblmaximized.Font = New System.Drawing.Font("Arial Narrow", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.llblmaximized.LinkColor = System.Drawing.Color.Black
        Me.llblmaximized.Location = New System.Drawing.Point(888, 2)
        Me.llblmaximized.Name = "llblmaximized"
        Me.llblmaximized.Size = New System.Drawing.Size(45, 42)
        Me.llblmaximized.TabIndex = 1
        Me.llblmaximized.TabStop = True
        Me.llblmaximized.Text = "☐"
        Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'updater
        '
        Me.updater.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.updater.Image = CType(resources.GetObject("updater.Image"), System.Drawing.Image)
        Me.updater.Location = New System.Drawing.Point(4, -1)
        Me.updater.Name = "updater"
        Me.updater.Size = New System.Drawing.Size(155, 57)
        Me.updater.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.updater.TabIndex = 1
        Me.updater.TabStop = False
        '
        'lblclose
        '
        Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblclose.AutoSize = True
        Me.lblclose.Font = New System.Drawing.Font("Arial Narrow", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.lblclose.LinkColor = System.Drawing.Color.Black
        Me.lblclose.Location = New System.Drawing.Point(955, 2)
        Me.lblclose.Name = "lblclose"
        Me.lblclose.Size = New System.Drawing.Size(43, 42)
        Me.lblclose.TabIndex = 1
        Me.lblclose.TabStop = True
        Me.lblclose.Text = "✕"
        Me.lblclose.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblheader
        '
        Me.lblheader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheader.ForeColor = System.Drawing.Color.White
        Me.lblheader.Location = New System.Drawing.Point(162, 4)
        Me.lblheader.Name = "lblheader"
        Me.lblheader.Size = New System.Drawing.Size(653, 29)
        Me.lblheader.TabIndex = 6
        Me.lblheader.Tag = "Label Printing Application"
        Me.lblheader.Text = "Label Printing Application"
        '
        'lblheaderSub
        '
        Me.lblheaderSub.AutoSize = True
        Me.lblheaderSub.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheaderSub.ForeColor = System.Drawing.Color.White
        Me.lblheaderSub.Location = New System.Drawing.Point(162, 36)
        Me.lblheaderSub.Name = "lblheaderSub"
        Me.lblheaderSub.Size = New System.Drawing.Size(329, 15)
        Me.lblheaderSub.TabIndex = 5
        Me.lblheaderSub.Tag = "• Support Personnel : Sir JOLo # 0920-8925-887"
        Me.lblheaderSub.Text = "• Support Personnel : Sir JOLo # 0920-8925-887"
        Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'pfooter
        '
        Me.pfooter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pfooter.BackColor = System.Drawing.Color.LightGray
        Me.pfooter.Controls.Add(Me.statusStrip)
        Me.pfooter.Controls.Add(Me.lblstatus)
        Me.pfooter.Controls.Add(Me.picdownloading)
        Me.pfooter.Controls.Add(Me.PictureBox2)
        Me.pfooter.Location = New System.Drawing.Point(1, 719)
        Me.pfooter.Name = "pfooter"
        Me.pfooter.Size = New System.Drawing.Size(1006, 30)
        Me.pfooter.TabIndex = 10
        '
        'statusStrip
        '
        Me.statusStrip.AutoSize = False
        Me.statusStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.statusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblRemainingCaption, Me.lblRemaining, Me.lblActivity, Me.lblElapsedCaption, Me.lblElapsed})
        Me.statusStrip.Location = New System.Drawing.Point(0, 3)
        Me.statusStrip.Name = "statusStrip"
        Me.statusStrip.Size = New System.Drawing.Size(395, 24)
        Me.statusStrip.SizingGrip = False
        Me.statusStrip.TabIndex = 2
        Me.statusStrip.Text = "statusStrip"
        '
        'lblRemainingCaption
        '
        Me.lblRemainingCaption.Name = "lblRemainingCaption"
        Me.lblRemainingCaption.Size = New System.Drawing.Size(67, 19)
        Me.lblRemainingCaption.Text = "Remaining:"
        '
        'lblRemaining
        '
        Me.lblRemaining.Name = "lblRemaining"
        Me.lblRemaining.Size = New System.Drawing.Size(49, 19)
        Me.lblRemaining.Text = "00:00:00"
        '
        'lblActivity
        '
        Me.lblActivity.BorderSides = CType((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.lblActivity.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Italic)
        Me.lblActivity.Name = "lblActivity"
        Me.lblActivity.Size = New System.Drawing.Size(165, 19)
        Me.lblActivity.Spring = True
        '
        'lblElapsedCaption
        '
        Me.lblElapsedCaption.Name = "lblElapsedCaption"
        Me.lblElapsedCaption.Size = New System.Drawing.Size(50, 19)
        Me.lblElapsedCaption.Text = "Elapsed:"
        '
        'lblElapsed
        '
        Me.lblElapsed.Name = "lblElapsed"
        Me.lblElapsed.Size = New System.Drawing.Size(49, 19)
        Me.lblElapsed.Text = "00:00:00"
        '
        'lblstatus
        '
        Me.lblstatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblstatus.Font = New System.Drawing.Font("Consolas", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstatus.Location = New System.Drawing.Point(455, 4)
        Me.lblstatus.Name = "lblstatus"
        Me.lblstatus.Size = New System.Drawing.Size(510, 22)
        Me.lblstatus.TabIndex = 0
        Me.lblstatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'picdownloading
        '
        Me.picdownloading.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picdownloading.Image = CType(resources.GetObject("picdownloading.Image"), System.Drawing.Image)
        Me.picdownloading.Location = New System.Drawing.Point(973, 2)
        Me.picdownloading.Name = "picdownloading"
        Me.picdownloading.Size = New System.Drawing.Size(28, 24)
        Me.picdownloading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picdownloading.TabIndex = 0
        Me.picdownloading.TabStop = False
        Me.picdownloading.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(973, 2)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(28, 24)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(0, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1010, 3)
        Me.Label1.TabIndex = 0
        '
        'pController
        '
        Me.pController.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pController.Controls.Add(Me.panelMenu)
        Me.pController.Location = New System.Drawing.Point(2, 60)
        Me.pController.Name = "pController"
        Me.pController.Size = New System.Drawing.Size(1004, 658)
        Me.pController.TabIndex = 11
        '
        'panelMenu
        '
        Me.panelMenu.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelMenu.Controls.Add(Me.lbldatetime)
        Me.panelMenu.Controls.Add(Me.btnitemMain)
        Me.panelMenu.Controls.Add(Me.btnlabelHistory)
        Me.panelMenu.Controls.Add(Me.btnsetting)
        Me.panelMenu.Controls.Add(Me.btnlabelPrinting)
        Me.panelMenu.Location = New System.Drawing.Point(1, 0)
        Me.panelMenu.Name = "panelMenu"
        Me.panelMenu.Size = New System.Drawing.Size(1002, 321)
        Me.panelMenu.TabIndex = 18
        Me.panelMenu.Visible = False
        '
        'lbldatetime
        '
        Me.lbldatetime.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldatetime.Location = New System.Drawing.Point(8, 288)
        Me.lbldatetime.Name = "lbldatetime"
        Me.lbldatetime.Size = New System.Drawing.Size(629, 23)
        Me.lbldatetime.TabIndex = 0
        Me.lbldatetime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnitemMain
        '
        Me.btnitemMain.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnitemMain.Enabled = False
        Me.btnitemMain.FlatAppearance.BorderSize = 2
        Me.btnitemMain.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnitemMain.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnitemMain.ForeColor = System.Drawing.Color.Yellow
        Me.btnitemMain.Image = CType(resources.GetObject("btnitemMain.Image"), System.Drawing.Image)
        Me.btnitemMain.Location = New System.Drawing.Point(8, 147)
        Me.btnitemMain.Margin = New System.Windows.Forms.Padding(0)
        Me.btnitemMain.Name = "btnitemMain"
        Me.btnitemMain.Padding = New System.Windows.Forms.Padding(10, 10, 0, 0)
        Me.btnitemMain.Size = New System.Drawing.Size(313, 134)
        Me.btnitemMain.TabIndex = 18
        Me.btnitemMain.Tag = "1"
        Me.btnitemMain.Text = "LABEL" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "MAINTENANCE"
        Me.btnitemMain.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnitemMain.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btnitemMain.UseVisualStyleBackColor = False
        '
        'btnlabelHistory
        '
        Me.btnlabelHistory.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnlabelHistory.Enabled = False
        Me.btnlabelHistory.FlatAppearance.BorderSize = 2
        Me.btnlabelHistory.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnlabelHistory.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnlabelHistory.ForeColor = System.Drawing.Color.Yellow
        Me.btnlabelHistory.Image = CType(resources.GetObject("btnlabelHistory.Image"), System.Drawing.Image)
        Me.btnlabelHistory.Location = New System.Drawing.Point(328, 7)
        Me.btnlabelHistory.Margin = New System.Windows.Forms.Padding(0)
        Me.btnlabelHistory.Name = "btnlabelHistory"
        Me.btnlabelHistory.Padding = New System.Windows.Forms.Padding(10, 10, 0, 0)
        Me.btnlabelHistory.Size = New System.Drawing.Size(313, 134)
        Me.btnlabelHistory.TabIndex = 18
        Me.btnlabelHistory.Tag = "1"
        Me.btnlabelHistory.Text = "PRINTING" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "HISTORY"
        Me.btnlabelHistory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnlabelHistory.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btnlabelHistory.UseVisualStyleBackColor = False
        '
        'btnsetting
        '
        Me.btnsetting.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnsetting.Enabled = False
        Me.btnsetting.FlatAppearance.BorderSize = 2
        Me.btnsetting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnsetting.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnsetting.ForeColor = System.Drawing.Color.Yellow
        Me.btnsetting.Image = CType(resources.GetObject("btnsetting.Image"), System.Drawing.Image)
        Me.btnsetting.Location = New System.Drawing.Point(328, 147)
        Me.btnsetting.Margin = New System.Windows.Forms.Padding(0)
        Me.btnsetting.Name = "btnsetting"
        Me.btnsetting.Padding = New System.Windows.Forms.Padding(10, 10, 0, 0)
        Me.btnsetting.Size = New System.Drawing.Size(313, 134)
        Me.btnsetting.TabIndex = 17
        Me.btnsetting.Tag = "1"
        Me.btnsetting.Text = "APPLICATION" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "SETTING"
        Me.btnsetting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnsetting.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btnsetting.UseVisualStyleBackColor = False
        '
        'btnlabelPrinting
        '
        Me.btnlabelPrinting.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnlabelPrinting.Enabled = False
        Me.btnlabelPrinting.FlatAppearance.BorderSize = 2
        Me.btnlabelPrinting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnlabelPrinting.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Bold)
        Me.btnlabelPrinting.ForeColor = System.Drawing.Color.Yellow
        Me.btnlabelPrinting.Image = CType(resources.GetObject("btnlabelPrinting.Image"), System.Drawing.Image)
        Me.btnlabelPrinting.Location = New System.Drawing.Point(8, 7)
        Me.btnlabelPrinting.Margin = New System.Windows.Forms.Padding(0)
        Me.btnlabelPrinting.Name = "btnlabelPrinting"
        Me.btnlabelPrinting.Padding = New System.Windows.Forms.Padding(10, 10, 0, 0)
        Me.btnlabelPrinting.Size = New System.Drawing.Size(313, 134)
        Me.btnlabelPrinting.TabIndex = 17
        Me.btnlabelPrinting.Tag = "1"
        Me.btnlabelPrinting.Text = "LABEL" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "PRINTING"
        Me.btnlabelPrinting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnlabelPrinting.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.btnlabelPrinting.UseVisualStyleBackColor = False
        '
        'getDateTime
        '
        Me.getDateTime.Enabled = True
        Me.getDateTime.Interval = 1000
        '
        'applicationIdle
        '
        Me.applicationIdle.IdleTime = System.TimeSpan.Parse("00:00:10")
        Me.applicationIdle.WarnTime = System.TimeSpan.Parse("00:00:05")
        '
        'PanelLocalDT
        '
        Me.PanelLocalDT.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelLocalDT.Controls.Add(Me.ButtonSetLocalDT)
        Me.PanelLocalDT.Controls.Add(Me.Label2)
        Me.PanelLocalDT.Controls.Add(Me.LabelLocalDateTime)
        Me.PanelLocalDT.Controls.Add(Me.DTPickerLocalDateTime)
        Me.PanelLocalDT.Location = New System.Drawing.Point(4, -1)
        Me.PanelLocalDT.Name = "PanelLocalDT"
        Me.PanelLocalDT.Size = New System.Drawing.Size(811, 54)
        Me.PanelLocalDT.TabIndex = 7
        Me.PanelLocalDT.Visible = False
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(10, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(265, 39)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "SYSTEM DATE && TIME:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DTPickerLocalDateTime
        '
        Me.DTPickerLocalDateTime.CustomFormat = "  yyyy - MM - dd    hh : mm : ss  tt"
        Me.DTPickerLocalDateTime.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DTPickerLocalDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTPickerLocalDateTime.Location = New System.Drawing.Point(278, 9)
        Me.DTPickerLocalDateTime.Name = "DTPickerLocalDateTime"
        Me.DTPickerLocalDateTime.ShowUpDown = True
        Me.DTPickerLocalDateTime.Size = New System.Drawing.Size(380, 38)
        Me.DTPickerLocalDateTime.TabIndex = 1
        Me.DTPickerLocalDateTime.Visible = False
        '
        'ButtonSetLocalDT
        '
        Me.ButtonSetLocalDT.BackColor = System.Drawing.Color.Black
        Me.ButtonSetLocalDT.FlatAppearance.BorderSize = 2
        Me.ButtonSetLocalDT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ButtonSetLocalDT.Font = New System.Drawing.Font("Arial Narrow", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSetLocalDT.ForeColor = System.Drawing.Color.Lime
        Me.ButtonSetLocalDT.Location = New System.Drawing.Point(669, 7)
        Me.ButtonSetLocalDT.Margin = New System.Windows.Forms.Padding(0)
        Me.ButtonSetLocalDT.Name = "ButtonSetLocalDT"
        Me.ButtonSetLocalDT.Padding = New System.Windows.Forms.Padding(2, 0, 0, 0)
        Me.ButtonSetLocalDT.Size = New System.Drawing.Size(124, 42)
        Me.ButtonSetLocalDT.TabIndex = 18
        Me.ButtonSetLocalDT.Tag = "1"
        Me.ButtonSetLocalDT.Text = "SET TIME"
        Me.ButtonSetLocalDT.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.ButtonSetLocalDT.UseVisualStyleBackColor = False
        '
        'LabelLocalDateTime
        '
        Me.LabelLocalDateTime.BackColor = System.Drawing.Color.White
        Me.LabelLocalDateTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelLocalDateTime.Font = New System.Drawing.Font("Arial Narrow", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelLocalDateTime.ForeColor = System.Drawing.Color.Black
        Me.LabelLocalDateTime.Location = New System.Drawing.Point(280, 9)
        Me.LabelLocalDateTime.Name = "LabelLocalDateTime"
        Me.LabelLocalDateTime.Size = New System.Drawing.Size(380, 38)
        Me.LabelLocalDateTime.TabIndex = 19
        Me.LabelLocalDateTime.Text = "yyyy - MM - dd    hh : mm : ss  tt"
        Me.LabelLocalDateTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'vw_1_menu
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(1012, 756)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_1_menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.pmain.ResumeLayout(False)
        Me.panelheader.ResumeLayout(False)
        Me.panelheader.PerformLayout()
        CType(Me.updater, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pfooter.ResumeLayout(False)
        Me.statusStrip.ResumeLayout(False)
        Me.statusStrip.PerformLayout()
        CType(Me.picdownloading, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pController.ResumeLayout(False)
        Me.panelMenu.ResumeLayout(False)
        Me.PanelLocalDT.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
    Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
    Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
    Friend WithEvents lblheaderSub As System.Windows.Forms.Label
    Friend WithEvents lblheader As System.Windows.Forms.Label
    Friend WithEvents pfooter As System.Windows.Forms.Panel
    Friend WithEvents pController As System.Windows.Forms.Panel
    Friend WithEvents lbldatetime As System.Windows.Forms.Label
    Friend WithEvents getDateTime As System.Windows.Forms.Timer
    Friend WithEvents lblstatus As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents picdownloading As System.Windows.Forms.PictureBox
    Friend WithEvents panelMenu As System.Windows.Forms.Panel
    Friend WithEvents btnlabelPrinting As System.Windows.Forms.Button
    Friend WithEvents btnlabelHistory As System.Windows.Forms.Button
    Friend WithEvents btnitemMain As System.Windows.Forms.Button
    Friend WithEvents btnsetting As System.Windows.Forms.Button
    Private WithEvents statusStrip As System.Windows.Forms.StatusStrip
    Private WithEvents lblRemainingCaption As System.Windows.Forms.ToolStripStatusLabel
    Private WithEvents lblRemaining As System.Windows.Forms.ToolStripStatusLabel
    Private WithEvents lblActivity As System.Windows.Forms.ToolStripStatusLabel
    Private WithEvents lblElapsedCaption As System.Windows.Forms.ToolStripStatusLabel
    Private WithEvents lblElapsed As System.Windows.Forms.ToolStripStatusLabel
    Public WithEvents applicationIdle As Winforms.Components.ApplicationIdle
    Friend WithEvents panelheader As Panel
    Friend WithEvents updater As PictureBox
    Friend WithEvents PanelLocalDT As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents DTPickerLocalDateTime As DateTimePicker
    Friend WithEvents ButtonSetLocalDT As Button
    Friend WithEvents LabelLocalDateTime As Label
End Class
