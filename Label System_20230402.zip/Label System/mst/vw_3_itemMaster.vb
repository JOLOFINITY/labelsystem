﻿Imports System.Runtime.InteropServices
Public Class vw_3_itemMaster
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub vw_3_itemMaster_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
		vw_1_menu.lblheader.Text = vw_1_menu.lblheader.Tag

	End Sub

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub

	Private Sub me_Resize(sender As Object, e As EventArgs) Handles Me.Resize
		If WindowState = FormWindowState.Maximized Then
			Maximize(Me)
		Else
		End If
	End Sub
	Private Sub lblclose_MouseEnter(sender As Object, e As EventArgs)
		Dim llbl As LinkLabel = sender

		llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size + 2, FontStyle.Bold)
	End Sub

	Private Sub lblclose_MouseLeave(sender As Object, e As EventArgs)
		Dim llbl As LinkLabel = sender

		llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size - 2, FontStyle.Regular)
	End Sub

	Private Sub lblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
		Dispose()
	End Sub
	Private Sub llblhide_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs)
		WindowState = FormWindowState.Minimized
	End Sub
#End Region
    Private Sub _connectDB()
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()

                Connection.Close()
            End Using

            boolConnected = True
        Catch ex As Exception
            Call createErrorLogs(ex, "CONNECTION TEST.", My.Settings.connection)
            boolConnected = False
        End Try
    End Sub
    Private Sub _saveDATA(ByRef query As String)
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using Comm = New MySqlCommand(query, Connection)
                    Comm.ExecuteNonQuery()
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
    End Sub
    Private Function _createTable(ByRef query As String) As DataTable
        Dim temp As New DataTable
        Try
            Using Connection = New MySqlConnection(My.Settings.connection)
                Connection.Open()
                Using dA = New MySqlDataAdapter(query, Connection)
                    Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
                End Using
                Connection.Close()
            End Using
        Catch ex As Exception
            Call createErrorLogs(ex, query, My.Settings.connection)
        End Try
        Return temp
    End Function
	Private Sub get_itemMats()
		With griditemList
            mst_productList = _createTable( _
                "SELECT " & vbNewLine & _
                "`Item Name`,`Condition`, " & vbNewLine & _
                "CONCAT(`Shelflife`,'   ',`Shelflife By`) `Shelflife`, " & vbNewLine & _
                "`Unit`,`Storage`, " & vbNewLine & _
                "`Shelflife` `Shelflife No`,`Shelflife By`,`Default`,`Default By`,`Add Days`,`Add By` " & vbNewLine & _
                "FROM `t_mst_items` " & vbNewLine & _
                "WHERE `Item Name` <> '-';")

			.DataSource = mst_productList
			.ClearSelection()

            Dim filtered = mst_productList.DefaultView.ToTable("result", True, "Item Name")
			filtered.DefaultView.Sort = "Item Name ASC"
			filtered = filtered.DefaultView.ToTable()
			cboitemMat.Items.Clear()
			For i = 0 To filtered.Rows.Count - 1
				cboitemMat.Items.Add(filtered.Rows(i)("Item Name").ToString.Trim)
			Next

			filtered = mst_productList.DefaultView.ToTable("result", True, "Condition")
			filtered.DefaultView.Sort = "Condition ASC"
			filtered = filtered.DefaultView.ToTable()
			cbocondition.Items.Clear()
			For i = 0 To filtered.Rows.Count - 1
				cbocondition.Items.Add(filtered.Rows(i)("Condition").ToString.Trim)
			Next

			filtered = mst_productList.DefaultView.ToTable("result", True, "Shelflife No")
			filtered.DefaultView.Sort = "Shelflife No ASC"
			filtered = filtered.DefaultView.ToTable()
			cboshelflife.Items.Clear()
			For i = 0 To filtered.Rows.Count - 1
				cboshelflife.Items.Add(filtered.Rows(i)("Shelflife No").ToString.Trim)
			Next

			'filtered = mst_productList.DefaultView.ToTable("result", True, "Shelflife By")
			'filtered.DefaultView.Sort = "Shelflife By ASC"
			'filtered = filtered.DefaultView.ToTable()
			'cboshelflifeBy.Items.Clear()
			'For i = 0 To filtered.Rows.Count - 1
			'	cboshelflifeBy.Items.Add(filtered.Rows(i)("Shelflife By").ToString.Trim)
			'Next

			filtered = mst_productList.DefaultView.ToTable("result", True, "Unit")
			filtered.DefaultView.Sort = "Unit ASC"
			filtered = filtered.DefaultView.ToTable()
			cbounit.Items.Clear()
			For i = 0 To filtered.Rows.Count - 1
				cbounit.Items.Add(filtered.Rows(i)("Unit").ToString.Trim)
			Next

			filtered = mst_productList.DefaultView.ToTable("result", True, "Storage")
			filtered.DefaultView.Sort = "Storage ASC"
			filtered = filtered.DefaultView.ToTable()
			cbostorage.Items.Clear()
			For i = 0 To filtered.Rows.Count - 1
				cbostorage.Items.Add(filtered.Rows(i)("Storage").ToString.Trim)
			Next

			'.Columns(0).Width = 60
			'.Columns(1).Width = .Width / 2.8 : .Columns(1).Frozen = True

			'.Columns(2).Width = 100
			'.Columns(3).Width = 70
			'.Columns(4).Width = 90
			'.Columns(5).Width = 70
			'.Columns(6).Width = 100

			'.Columns(7).Width = 70
			'.Columns(8).Width = 90

			.Columns(0).Width = 60
			.Columns(1).Width = 360 : .Columns(1).Frozen = True
			.Columns(2).Width = 90
			.Columns(3).Width = 130
			.Columns(4).Width = 80
			.Columns(5).Width = 100

			.Columns(6).Width = 0
			.Columns(7).Width = 0

			.Columns(8).Width = 70
            .Columns(9).Width = 90
            .Columns(10).Width = 60
            .Columns(11).Width = 100
		End With
	End Sub
	Private Sub additem()
		If cboshelflifeDef.Text <> String.Empty And cboshelflifeByDef.Text <> String.Empty Then
            _saveDATA("INSERT INTO `t_mst_items`(`Item Name`,`Condition`,`Shelflife`,`Shelflife By`,`Unit`,`Storage`,`Default`,`Default By`,`Add Days`,`Add By`) VALUES('" & cboitemMat.Text & "','" & cbocondition.Text & "','" & cboshelflife.Text & "','" & cboshelflifeBy.Text & "','" & cbounit.Text & "','" & cbostorage.Text & "','" & cboshelflifeDef.Text & "','" & cboshelflifeByDef.Text & "','" & numDays.Text & "','" & numDaysBy.Text & "');")

		Else
            _saveDATA("INSERT INTO `t_mst_items`(`Item Name`,`Condition`,`Shelflife`,`Shelflife By`,`Unit`,`Storage`,`Add Days`,`Add By`) VALUES('" & cboitemMat.Text & "','" & cbocondition.Text & "','" & cboshelflife.Text & "','" & cboshelflifeBy.Text & "','" & cbounit.Text & "','" & cbostorage.Text & "','" & numDays.Text & "','" & numDaysBy.Text & "');")

		End If

		MessageBox.Show("Product successfully added, List is now updated!", "Item Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)
	End Sub
    Private Sub removeitem(ByRef strName As String, ByRef strCondition As String)
        _saveDATA("DELETE FROM `t_mst_items` WHERE `Item Name` = '" & strName & "' AND `Condition` = '" & strCondition & "';")

        MessageBox.Show("Product successfully remove from DATABASE, List is now updated!", "Item/Product Deleted.", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
	Dim suggestions As New AutoCompleteStringCollection
	Private Sub cboitemMat_TextChanged(sender As Object, e As EventArgs) Handles cboitemMat.TextChanged
		If cbautoSearch.Checked Then
			_exec_gridSearch(griditemList, cboitemMat.Text)
		Else

		End If
	End Sub

	Private mst_productList As New DataTable
	Private Sub vw_1_productMaster_Shown(sender As Object, e As EventArgs) Handles Me.Shown
		Call get_itemMats()
	End Sub

	Private Sub cbautoSearch_CheckedChanged(sender As Object, e As EventArgs) Handles cbautoSearch.CheckedChanged
		cboitemMat.SelectAll()
		cboitemMat.Focus()

		If cbautoSearch.Checked Then
			cboitemMat.AutoCompleteMode = AutoCompleteMode.None
			suggestions = cboitemMat.AutoCompleteCustomSource
			cboitemMat.AutoCompleteCustomSource.Clear()
		Else
			_exec_gridSearch(griditemList, "")

			If suggestions.Count > 0 Then cboitemMat.AutoCompleteCustomSource = suggestions
		End If
	End Sub

	Private Sub llblrefresh_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblrefresh.LinkClicked
		Call get_itemMats()
	End Sub

	Private Sub llbladdSave_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbladdSave.LinkClicked
		If cboitemMat.Text.Length <= 2 Then
			cboitemMat.BackColor = Color.LightPink
            cboitemMat.SelectAll() : cboitemMat.Focus()
        ElseIf cbocondition.Text = String.Empty Then
            cbocondition.BackColor = Color.LightPink
            cbocondition.SelectAll() : cbocondition.Focus()
        ElseIf cboshelflife.Text = String.Empty Then
            cboshelflife.BackColor = Color.LightPink
            cboshelflife.SelectAll() : cboshelflife.Focus()
        ElseIf cboshelflifeBy.Text = String.Empty Then
            cboshelflifeBy.SelectAll() : cboshelflifeBy.Focus()
        ElseIf cbounit.Text = String.Empty Then
            cbounit.BackColor = Color.LightPink
            cbounit.SelectAll() : cbounit.Focus()
        ElseIf cbostorage.Text = String.Empty Then
            cbostorage.BackColor = Color.LightPink
            cbostorage.SelectAll() : cbostorage.Focus()
        Else
            If cboshelflifeDef.Text = "" Then
                cboshelflifeDef.Text = "0.0"
                cboshelflifeByDef.Text = "-"
            End If

            If numDays.Text = "" Then
                numDays.Text = "0.0"
                numDaysBy.Text = "DAY(S)"
            End If

            If check_itemExistA(cboitemMat.Text, cbocondition.Text) Then

                If MessageBox.Show("item already exist, please check the list to see record." & vbNewLine & vbNewLine & "DO YOU WANT TO UPDATE EXISTING RECORD?", "Already Exist.", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then

                    check_itenExistUpdate(cboitemMat.Text, cbocondition.Text, cboshelflife.Text, cboshelflifeBy.Text, cbounit.Text, cbostorage.Text, cboshelflifeDef.Text, cboshelflifeByDef.Text, numDays.Text, numDaysBy.Text)

                    MessageBox.Show("Item/Material information successfully updated.", "Updated.", MessageBoxButtons.OK, MessageBoxIcon.Information)

                    Call get_itemMats()
                End If
                cboitemMat.Focus()
            Else
                Call additem()

                cboitemMat.Text = String.Empty : cboitemMat.Focus()

                Call get_itemMats()

                Call clear()
            End If
		End If
	End Sub

	Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
		If e.RowIndex >= 0 And e.ColumnIndex = 0 Then
			If MessageBox.Show( _
				"Warning : " & vbNewLine & vbNewLine & "You're about to Delete the following Item/Product(s)!" & vbNewLine & vbNewLine & _
				"Item/Product : " & griditemList.Rows(e.RowIndex).Cells(1).Value & " [" & griditemList.Rows(e.RowIndex).Cells(2).Value & "] " & vbNewLine & vbNewLine & _
				"Select [YES] to DELETE , [NO] to Cancel.", "User Input.", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                Call removeitem(griditemList.Rows(e.RowIndex).Cells(1).Value, griditemList.Rows(e.RowIndex).Cells(2).Value)

				Call get_itemMats()
				Call clear()
			End If
		ElseIf e.RowIndex >= 0 And e.ColumnIndex >= 1 Then
			Try
				cboitemMat.Text = griditemList.Rows(e.RowIndex).Cells(1).Value.ToString
				cbocondition.Text = griditemList.Rows(e.RowIndex).Cells(2).Value.ToString
				cbounit.Text = griditemList.Rows(e.RowIndex).Cells(4).Value.ToString
				cbostorage.Text = griditemList.Rows(e.RowIndex).Cells(5).Value.ToString
				cboshelflife.Text = griditemList.Rows(e.RowIndex).Cells(6).Value.ToString
				cboshelflifeBy.Text = griditemList.Rows(e.RowIndex).Cells(7).Value.ToString

				cboshelflifeDef.Text = griditemList.Rows(e.RowIndex).Cells(8).Value.ToString
				cboshelflifeByDef.Text = griditemList.Rows(e.RowIndex).Cells(9).Value.ToString

                numDays.Text = griditemList.Rows(e.RowIndex).Cells(10).Value.ToString
                numDaysBy.Text = griditemList.Rows(e.RowIndex).Cells(11).Value.ToString

				cboitemMat.Focus()
				cboitemMat.SelectionStart = cboitemMat.Text.Length
			Catch ex As Exception
				Call clear()
			End Try
		End If
	End Sub
	Private Sub clear()
		cboitemMat.Text = String.Empty
		cbocondition.Text = String.Empty
		cbounit.Text = String.Empty
		cbostorage.Text = String.Empty
		cboshelflife.Text = String.Empty
		cboshelflifeBy.Text = Nothing
		cboshelflifeDef.Text = String.Empty
		cboshelflifeByDef.Text = String.Empty

		cboitemMat.Focus()
	End Sub
	

	Private Sub vw_3_itemMaster_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		vw_1_menu.lblheader.Text = "I T E M   /   M A T E R I A L   M A S T E R"
	End Sub

	Private Sub cboitemMat_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbounit.KeyPress, cbostorage.KeyPress, cboshelflifeBy.KeyPress, cboitemMat.KeyPress, cbocondition.KeyPress
		e.KeyChar = e.KeyChar.ToString.ToUpper
	End Sub
	Private Sub llblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclose.LinkClicked
        Dispose()

         vw_1_menu.panelMenu.Visible = True
	End Sub

    Private Sub cboshelflifeBy_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboshelflifeBy.SelectedIndexChanged
        If cboshelflifeBy.Text = "EOD" Then
            cboshelflife.Text = "1"
        Else
        End If
    End Sub

    Private Sub cboshelflifeByDef_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboshelflifeByDef.SelectedIndexChanged
        If cboshelflifeByDef.Text = "EOD" Then
            cboshelflifeDef.Text = "1"
        Else
        End If
    End Sub
End Class