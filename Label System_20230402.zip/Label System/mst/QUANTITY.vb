﻿Public Class QUANTITY
	Private boolStart As Boolean = False
	Private _quantityValue As String
	Friend Property quantityValue() As String
		Get
			Return _quantityValue
		End Get
		Set(ByVal Value As String)
			_quantityValue = Value
		End Set
	End Property

	Private Sub CALENDAR_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		lblquantity.Text = _quantityValue


		boolStart = True
	End Sub



	Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
		lblquantity.Text = String.Empty
	End Sub

	Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn9.Click, btn8.Click, btn7.Click, btn6.Click, btn5.Click, btn4.Click, btn3.Click, btn2.Click, btn1.Click, btn0.Click
		Dim btn As Button = sender

		lblquantity.Text &= btn.Text
	End Sub

	Private Sub btnokayClose_Click(sender As Object, e As EventArgs) Handles btnokayClose.Click
		quantityValue = lblquantity.Text
		Close()
	End Sub

	Private Sub btno1_Click(sender As Object, e As EventArgs) Handles btno1.Click
		If lblquantity.Text.Contains(btno1.Text) = False Then
			lblquantity.Text &= btno1.Text
		End If
	End Sub

	Private Sub btno2_Click(sender As Object, e As EventArgs) Handles btno2.Click
		If lblquantity.Text.Contains(btno2.Text) = False Then
			lblquantity.Text &= btno2.Text
		End If
	End Sub
End Class