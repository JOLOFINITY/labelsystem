﻿Imports System.Runtime.InteropServices
Public Class vw_2_recovery
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub vw_3_registration_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dispose()

        vw_1_menu.panelMenu.Visible = True
    End Sub

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, panelHeader.MouseDown, Label2.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub


#End Region
	Private Sub vw_2_management_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        roundCorners(Me, Color.DimGray)

        Top = 0
	End Sub

    Private Sub llblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclose.LinkClicked
        Dispose()

        vw_1_menu.showLogin(New vw_2_loginPIN)
    End Sub
    Private Sub llblregister_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblshowPassword.LinkClicked
        If cboa1.Text = user.Rows(0)("Answer Question 1").ToString And cboa2.Text = user.Rows(0)("Answer Question 2").ToString And cboa3.Text = user.Rows(0)("Answer Question 3").ToString And txtusername.Text <> String.Empty And grpsec.Enabled Then
            lblpassword.Text = "Your Password is : " & user.Rows(0)("Password").ToString & vbNewLine & "Please take note and remember it."

            thider.Start()
        Else
            MessageBox.Show("Incorrect answer, Please check and try again!", "Invalid Input.", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            cboa1.Focus()
        End If
    End Sub
    Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged
		If grpsec.Enabled Then
			grpsec.Enabled = False

			cboq1.Text = String.Empty : cboa1.Text = String.Empty
			cboq2.Text = String.Empty : cboa2.Text = String.Empty
			cboq3.Text = String.Empty : cboa3.Text = String.Empty
		End If
	End Sub

	Private user As New DataTable("result")
	Private Sub txtusername_KeyDown(sender As Object, e As KeyEventArgs) Handles txtusername.KeyDown
		If e.KeyCode = Keys.Enter Then
			user = getUser(txtusername.Text)
			If user.Rows.Count >= 1 Then
				If user.Rows(0)("Security Question 1").ToString = String.Empty And user.Rows(0)("Security Question 2").ToString = String.Empty And user.Rows(0)("Security Question 3").ToString = String.Empty Then
					MessageBox.Show("Security Question is not set, please coordinate your account to your Superior.", "No Question was set!", MessageBoxButtons.OK, MessageBoxIcon.Information)
					GoTo noSet
				Else
					grpsec.Enabled = True

					cboq1.Text = user.Rows(0)("Security Question 1").ToString
					cboq2.Text = user.Rows(0)("Security Question 2").ToString
					cboq3.Text = user.Rows(0)("Security Question 3").ToString

					cboa1.SelectAll() : cboa1.Focus()
				End If
			Else
noSet:
				grpsec.Enabled = False

				cboq1.Text = String.Empty : cboa1.Text = String.Empty
				cboq2.Text = String.Empty : cboa2.Text = String.Empty
				cboq3.Text = String.Empty : cboa3.Text = String.Empty

				txtusername.SelectAll() : txtusername.Focus()
			End If
		 
		End If
	End Sub

	Private Sub tfocus_Tick(sender As Object, e As EventArgs) Handles tfocus.Tick
		tfocus.Stop()

		txtusername.Focus()
	End Sub

	Private intHider As Integer = 6
	Private Sub thider_Tick(sender As Object, e As EventArgs) Handles thider.Tick
		thider.Stop()


		Label1.Text = "Will HIDE after : " & intHider

		If intHider = 0 Then
			lblpassword.Text = String.Empty

			Label1.Text = String.Empty

			intHider = 6
		Else
			intHider -= 1

			thider.Start()
		End If
	End Sub

    Private Sub vw_2_recovery_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class