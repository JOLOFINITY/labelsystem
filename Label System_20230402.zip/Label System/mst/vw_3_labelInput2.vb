﻿Imports System.Runtime.InteropServices
Public Class vw_3_labelInput2

#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

    Private Sub Me_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dispose()

        vw_1_menu.lblheader.Text = vw_1_menu.lblheader.Tag

        vw_1_menu.PanelLocalDT.Visible = False
        vw_1_menu.updater.Visible = True
        vw_1_menu.lblheader.Visible = True
        vw_1_menu.lblheaderSub.Visible = True

        vw_1_menu.panelMenu.Visible = True
    End Sub

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown
		'If e.Button = MouseButtons.Left Then
		'	ReleaseCapture()
		'	SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		'End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub
#End Region
	Private mst_items As New DataTable("result")
	Private Sub vw_3_labelInput_Shown(sender As Object, e As EventArgs) Handles Me.Shown
		initREPORT()

		Call get_itemListA(cboitems, cbocondition, mst_items)
		Call get_itemListC(griditemList)

		With My.Settings
			cboemployee.Text = login_username
			cbomanager.Text = .nameOfManager
		End With

        vw_1_menu.lblheader.Text = "L A B E L   P R I N T I N G   I N P U T "
        vw_1_menu.updater.Visible = False
        vw_1_menu.lblheader.Visible = False
        vw_1_menu.lblheaderSub.Visible = False
        vw_1_menu.PanelLocalDT.Visible = True

        lblTimeIn.Text = vw_1_menu.DTPickerLocalDateTime.Value.ToString("hh:mm tt")
        lblTimeIn.Tag = vw_1_menu.DTPickerLocalDateTime.Value.ToString("HH:mm:ss")
        lblcurDate.Text = vw_1_menu.DTPickerLocalDateTime.Value.ToString("MM/dd/yyyy")
        lblcurDate.Tag = vw_1_menu.DTPickerLocalDateTime.Value.ToString("yyyy-MM-dd")

        dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.ToString("MM/dd/yyyy")
        dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.ToString("yyyy-MM-dd")

        Call loadEmployees(cboemployee)
        Call loadManagers(cbomanager)
    End Sub
    Private Sub cboitems_TextChanged(sender As Object, e As EventArgs) Handles cboitems.TextChanged
        cbocondition.Text = Nothing
        lblquantity.Text = String.Empty
        lblunit.Text = String.Empty
        lblshelflife.Text = String.Empty
        lblshelflifeBy.Text = String.Empty
        lblstorage.Text = String.Empty
        lblusedBy.Text = String.Empty

        _exec_gridSearch(griditemList, cboitems.Text)

        If cboitems.Text.Length = 0 Then
            btnclear.Text = "C L O S E"
        Else
            btnclear.Text = "C L E A R"
        End If
    End Sub


    Private Sub cbocondition_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbocondition.SelectedIndexChanged
        If cbocondition.Text <> String.Empty Then
            If cboitems.Text <> String.Empty Then
                Dim filter = mst_items.Select("`Item Name` = '" & cboitems.Text & "' AND `Condition` = '" & cbocondition.Text & "'")

                If filter.Length = 1 Then
                    lblunit.Text = filter.ToArray(0)("Unit").ToString
                    lblshelflife.Text = filter.ToArray(0)("Shelflife").ToString

                    Dim dec = filter.ToArray(0)("Shelflife")
                    Dim toInt = Decimal.Parse(lblshelflife.Text) - dec
                    If toInt <= 0 Then
                        lblshelflife.Text = Decimal.Parse(lblshelflife.Text)
                    End If

                    lblshelflifeBy.Text = filter.ToArray(0)("Shelflife By").ToString
                    lblstorage.Text = filter.ToArray(0)("Storage").ToString

                    If filter.ToArray(0)("Default").ToString > 0 And filter.ToArray(0)("Default By").ToString <> "" Then
                        Call getDefaultProduction(filter.ToArray(0)("Default"), filter.ToArray(0)("Default By"))

                        lblproductionDefault.Text = " Default : " & CInt(filter.ToArray(0)("Default")) & " " & filter.ToArray(0)("Default By")
                    Else
                        lblproductionDefault.Text = String.Empty

                        cbprodDate.Checked = False

                        dateProduction_default = vw_1_menu.DTPickerLocalDateTime.Value
                        dateProduction_defaultNo = 0.0
                        dateProduction_defaultBy = String.Empty
                    End If

                    If filter.ToArray(0)("Add Days") > 0 And filter.ToArray(0)("Add By").ToString.Length >= 2 Then
                        additional_defaultNo = filter.ToArray(0)("Add Days")
                        additional_defaultBy = filter.ToArray(0)("Add By")
                    Else
                        additional_defaultNo = 0.0
                        additional_defaultBy = String.Empty
                    End If

                    btnquantity.Focus()
                Else
                    MessageBox.Show("Record not found, Please ask SYSTEM-ADMIN to add.", "Item not found.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If
        End If
    End Sub

    Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
        If e.RowIndex >= 0 And e.ColumnIndex >= 0 Then
            With griditemList
                Dim strItem As String = .Rows(e.RowIndex).Cells(1).Value.ToString.Trim
                Dim strCon As String = .Rows(e.RowIndex).Cells(2).Value.ToString.Trim

                cboitems.Text = strItem
                cbocondition.Text = strCon
            End With
        End If
    End Sub

    Private Sub cboitems_Enter(sender As Object, e As EventArgs) Handles _
        cboitems.Enter, _
        cbocondition.Enter, _
 _
        btndate.Enter, _
 _
        cboemployee.Enter, _
        cboremarks.Enter, _
        cbomanager.Enter, _
        btnquantity.Enter, _
        btnTIMEIN.Enter

        Dim strTag As String = sender.Tag

        If strTag = "A" Then
            lblA.BackColor = Color.Lime

        ElseIf strTag = "B" Then
            lblB.BackColor = Color.Lime

        ElseIf strTag = "C" Then
            lblC.BackColor = Color.Lime

        ElseIf strTag = "D" Then
            lblD.BackColor = Color.Lime

        ElseIf strTag = "E" Then
            lblE.BackColor = Color.Lime

        ElseIf strTag = "H" Then
            lblH.BackColor = Color.Lime

        ElseIf strTag = "I" Then
            lblI.BackColor = Color.Lime

        ElseIf strTag = "J" Then
            lblJ.BackColor = Color.Lime

        End If
    End Sub
    Private Sub cboitems_Leave(sender As Object, e As EventArgs) Handles _
        cboitems.Leave, _
        cbocondition.Leave, _
 _
        btndate.Leave, _
 _
        cboemployee.Leave, _
        cboremarks.Leave, _
        cbomanager.Leave, _
        btnquantity.Leave, _
        btnTIMEIN.Leave

        Dim strTag As String = sender.Tag

        If strTag = "A" Then
            lblA.BackColor = Color.Black

        ElseIf strTag = "B" Then
            lblB.BackColor = Color.Black

        ElseIf strTag = "C" Then
            lblC.BackColor = Color.Black

        ElseIf strTag = "D" Then
            lblD.BackColor = Color.Black

        ElseIf strTag = "E" Then
            lblE.BackColor = Color.Black

        ElseIf strTag = "F" Then
            lblF.BackColor = Color.Black

        ElseIf strTag = "G" Then
            lblG.BackColor = Color.Black

        ElseIf strTag = "H" Then
            lblH.BackColor = Color.Black

        ElseIf strTag = "I" Then
            lblI.BackColor = Color.Black

        ElseIf strTag = "J" Then
            lblJ.BackColor = Color.Black

        End If
    End Sub

    Private Sub displayDay(DT As DateTime)
        Try
            If lblshelflifeBy.Text = "EOD" Then
                DT = vw_1_menu.DTPickerLocalDateTime.Value
            End If

            lbldays.Text = String.Empty
            lbldays.Tag = DT.ToString("dddd").ToUpper
            For i = 1 To DT.ToString("dddd").ToUpper.Length
                lbldays.Text &= Mid(DT.ToString("dddd").ToUpper, i, 1).ToString.ToUpper & vbNewLine
            Next
            lbldays.Text = lbldays.Text.Trim
        Catch ex As Exception

        End Try
    End Sub

    Private dateProduction_default As DateTime
    Private dateProduction_defaultNo As Decimal = 0.0
    Private dateProduction_defaultBy As String
    Private Sub getDefaultProduction(ByRef def As Decimal, ByRef defBy As String)

        If defBy = "MINUTES" Then
            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.AddMinutes(-def).ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.AddMinutes(-def).ToString("yyyy-MM-dd")

        ElseIf defBy = "HOUR(S)" Then
            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.AddHours(-def).ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.AddHours(-def).ToString("yyyy-MM-dd")

        ElseIf defBy = "DAY(S)" Then
            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.AddDays(-def).ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.AddDays(-def).ToString("yyyy-MM-dd")

        ElseIf defBy = "WEEK(S)" Then
            Dim toDays = Decimal.Parse(def) * 7.0
            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.AddDays(-toDays).ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.AddDays(-toDays).ToString("yyyy-MM-dd")

        ElseIf defBy = "MONTH(S)" Then
            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.AddMonths(-def).ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.AddMonths(-def).ToString("yyyy-MM-dd")

        ElseIf defBy = "YEAR(S)" Then
            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.AddYears(-def).ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.AddYears(-def).ToString("yyyy-MM-dd")
        End If

        dateProduction_default = CDate(dateProduction.Tag).ToString("yyyy-MM-dd")

        dateProduction_defaultNo = def
        dateProduction_defaultBy = defBy

        If My.Settings.check_ProductionDate = 1 Then
            cbprodDate.Checked = True
        Else
            cbprodDate.Checked = False
        End If
    End Sub
    Private additional_defaultNo As Decimal = 0.0
    Private additional_defaultBy As String

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnsavePrint.Click, btnsave.Click
        saveRecord(sender.Tag)
    End Sub

    Private Sub saveRecord(ByRef intPrint As Integer)
        If cboitems.SelectedIndex = -1 Or cboitems.Text = String.Empty Then
            MessageBox.Show("Please Select Item and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            cboitems.SelectAll() : cboitems.Focus()
        ElseIf cbocondition.SelectedIndex = -1 Then
            MessageBox.Show("Please select Condition and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            cbocondition.SelectAll() : cbocondition.Focus()
        ElseIf (lblquantity.Text = String.Empty) Then
            MessageBox.Show("Quantity Required! and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnquantity.Focus()
        Else
            With My.Settings
                .nameOfEmployee = cboemployee.Text
                .nameOfManager = cbomanager.Text
                .remarks = cboremarks.Text
                .Save()
            End With

            Dim isPrinted As String = "0"

            Dim printedDate As String = "NULL"
            Dim printedby As String = "NULL"

            If intPrint Then
                Dim queryTOPrint As String = _
                    "SELECT 'PRINTING' `UID`,'" & lblpreview_days.Tag & "' `DAY`," & vbNewLine & _
                    "'" & lblpreview_itemName.Text & "' `ITEM`," & vbNewLine & _
                    "'" & lblpreview_productionDate.Text & "' `DATE`," & vbNewLine & _
                    "'" & lblpreview_quantityUnit.Text & "' `QUANTITY`," & vbNewLine & _
                    "'" & lblpreview_shelftLife.Text & "' `SHELFLIFE`," & vbNewLine & _
                    "'" & lblpreview_timeIN.Text & "' `TIME-IN`," & vbNewLine & _
                    "'" & lblpreview_employeeName.Text & "' `EMPLOYEE`," & vbNewLine & _
                    "'" & lblpreview_AM.Text & "' `AM`," & vbNewLine & _
                    "'" & lblpreview_PM.Text & "' `PM`," & vbNewLine & _
                    "'" & lblpreview_usedBy.Text & "' `USED BY`," & vbNewLine & _
                    "'" & lblpreview_manager.Text & "' `MANAGER`," & vbNewLine & _
                    "'" & lblpreview_remarks.Text & "' `REMARKS` "

                Dim result = quickPrint(queryTOPrint)

                With cReport
                    .DataSourceConnections.Clear()
                    .SetDataSource(result)
                    .PrintToPrinter(1, False, 0, 0)
                End With

                isPrinted = "1"
                printedDate = "NOW()"
                printedby = "'" & login_username & "'"
            End If

            Dim query As String =
                "INSERT INTO `t_for_print`" & vbNewLine &
                "(`DAY`," & vbNewLine &
                "`ITEM`," & vbNewLine &
                "`DATE`," & vbNewLine &
                "`QUANTITY`," & vbNewLine &
                "`SHELFLIFE`," & vbNewLine &
                "`TIME-IN`," & vbNewLine &
                "`EMPLOYEE`," & vbNewLine &
                "`AM`," & vbNewLine &
                "`PM`," & vbNewLine &
                "`USED BY`," & vbNewLine &
                "`MANAGER`," & vbNewLine &
                "`REMARKS`," & vbNewLine &
                "`Entry By`,`IsPrinted`,`Printed By`,`Printed Date`,`Validity`)" & vbNewLine &
                "VALUES" & vbNewLine &
                "('" & lblpreview_days.Tag & "'," & vbNewLine &
                "'" & lblpreview_itemName.Text & "'," & vbNewLine &
                "'" & lblpreview_productionDate.Text & "'," & vbNewLine &
                "'" & lblpreview_quantityUnit.Text & "'," & vbNewLine &
                "'" & lblpreview_shelftLife.Text & "'," & vbNewLine &
                "'" & lblpreview_timeIN.Text & "'," & vbNewLine &
                "'" & lblpreview_employeeName.Text & "'," & vbNewLine &
                "'" & lblpreview_AM.Text & "'," & vbNewLine &
                "'" & lblpreview_PM.Text & "'," & vbNewLine &
                "'" & lblpreview_usedBy.Text & "'," & vbNewLine &
                "'" & lblpreview_manager.Text & "'," & vbNewLine &
                "'" & lblpreview_remarks.Text & "'," & vbNewLine &
                "'" & login_username & "','" & isPrinted & "'," & printedby & "," & printedDate & ",'" & lblusedBy.Tag & "');" & vbNewLine

            AddForPrint(query)

            MessageBox.Show("Record successfully save, Printing can be done later.", "Record Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)

            cboitems.SelectAll()
            cboitems.Focus()
        End If
    End Sub

    Private Sub checkExpiration()
        If cboitems.Text = String.Empty Or cbocondition.Text = String.Empty Then Return

        If cbprodDate.Checked Then
            Dim toDateProduction = CDate(CDate(dateProduction.Tag).ToString("yyyy-MM-dd") & " " & lblTimeIn.Tag)

            Dim expiration_byTIMEIN As New DateTime
            If lblshelflifeBy.Text = "MINUTES" Then
                expiration_byTIMEIN = toDateProduction.AddMinutes(lblshelflife.Text)
            ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                expiration_byTIMEIN = toDateProduction.AddHours(lblshelflife.Text)
            ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                expiration_byTIMEIN = toDateProduction.AddDays(lblshelflife.Text)
            ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                expiration_byTIMEIN = toDateProduction.AddDays(toDays)
            ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                expiration_byTIMEIN = toDateProduction.AddMonths(lblshelflife.Text)
            ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                expiration_byTIMEIN = toDateProduction.AddYears(lblshelflife.Text)
            ElseIf lblshelflifeBy.Text = "EOD" Then
                expiration_byTIMEIN = toDateProduction.AddHours(24)
            End If

            Dim expiration_productionDate As New DateTime
            If cbprodDate.Checked And additional_defaultNo > 0 And additional_defaultBy.ToString.Length > 2 Then
                If additional_defaultBy = "DAY(S)" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddDays(additional_defaultNo)

                ElseIf additional_defaultBy = "WEEK(S)" Then
                    Dim toDays = Decimal.Parse(additional_defaultNo) * 7.0
                    expiration_productionDate = CDate(dateProduction.Tag).AddDays(toDays)

                ElseIf additional_defaultBy = "MONTH(S)" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddMonths(additional_defaultNo)

                ElseIf additional_defaultBy = "YEAR(S)" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddYears(additional_defaultNo)

                End If
            Else
                If dateProduction_defaultBy = "MINUTES" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddMinutes(dateProduction_defaultNo)

                ElseIf dateProduction_defaultBy = "HOUR(S)" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddHours(dateProduction_defaultNo)

                ElseIf dateProduction_defaultBy = "DAY(S)" Or dateProduction_defaultBy = "EOD" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddDays(dateProduction_defaultNo)

                ElseIf dateProduction_defaultBy = "WEEK(S)" Then
                    Dim toDays = Decimal.Parse(dateProduction_defaultNo) * 7.0
                    expiration_productionDate = CDate(dateProduction.Tag).AddDays(toDays)

                ElseIf dateProduction_defaultBy = "MONTH(S)" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddMonths(dateProduction_defaultNo)

                ElseIf dateProduction_defaultBy = "YEAR(S)" Then
                    expiration_productionDate = CDate(dateProduction.Tag).AddYears(dateProduction_defaultNo)

                Else
                    If lblshelflifeBy.Text = "MINUTES" Then
                        expiration_productionDate = CDate(dateProduction.Tag).AddMinutes(lblshelflife.Text)

                    ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                        expiration_productionDate = CDate(dateProduction.Tag).AddHours(lblshelflife.Text)

                    ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                        expiration_productionDate = CDate(dateProduction.Tag).AddDays(lblshelflife.Text)

                    ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                        Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                        expiration_productionDate = CDate(dateProduction.Tag).AddDays(toDays)

                    ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                        expiration_productionDate = CDate(dateProduction.Tag).AddMonths(lblshelflife.Text)

                    ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                        expiration_productionDate = CDate(dateProduction.Tag).AddYears(lblshelflife.Text)

                    ElseIf lblshelflifeBy.Text = "EOD" Then
                        expiration_productionDate = CDate(dateProduction.Tag).AddHours(24)

                    End If
                End If
            End If

            Dim newExpiration As DateTime
            If expiration_byTIMEIN < expiration_productionDate Then
                newExpiration = expiration_byTIMEIN
            ElseIf expiration_byTIMEIN > expiration_productionDate Then
                newExpiration = expiration_productionDate
            ElseIf expiration_byTIMEIN = expiration_productionDate Then
                newExpiration = expiration_productionDate
            Else
                newExpiration = expiration_byTIMEIN
            End If

            If lblshelflifeBy.Text = "EOD" Then
                lblusedBy.Text = "EOD"
            Else

                lblusedBy.Text = newExpiration.ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
            End If

            lblusedBy.Tag = newExpiration.ToString("yyyy-MM-dd HH:mm:ss")

            displayDay(newExpiration)

            If vw_1_menu.DTPickerLocalDateTime.Value > newExpiration Then
expNaA:
                lblusedBy.ForeColor = Color.Red
            Else
                lblusedBy.ForeColor = Color.Lime
            End If
        Else
            REM CHECK IF NOT EXPIRED IN DATE
            Dim toTimeIn = CDate(CDate(lblcurDate.Tag).ToString("yyyy-MM-dd") & " " & lblTimeIn.Tag)

            Dim expiration_byTIMEIN As New DateTime
            If lblshelflifeBy.Text = "MINUTES" Then
                expiration_byTIMEIN = toTimeIn.AddMinutes(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                expiration_byTIMEIN = toTimeIn.AddHours(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                expiration_byTIMEIN = toTimeIn.AddDays(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                expiration_byTIMEIN = toTimeIn.AddDays(toDays)

            ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                expiration_byTIMEIN = toTimeIn.AddMonths(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                expiration_byTIMEIN = toTimeIn.AddYears(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "EOD" Then
                expiration_byTIMEIN = toTimeIn.AddHours(24)
            End If

            If lblshelflifeBy.Text = "EOD" Then
                lblusedBy.Text = "EOD"

            Else
                lblusedBy.Text = expiration_byTIMEIN.ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper

            End If

            lblusedBy.Tag = expiration_byTIMEIN.ToString("yyyy-MM-dd HH:mm:ss")
            displayDay(expiration_byTIMEIN)

            If vw_1_menu.DTPickerLocalDateTime.Value > expiration_byTIMEIN Then
expNaB:
                lblusedBy.ForeColor = Color.Red

                btnsavePrint.Enabled = False
                btnsave.Enabled = False
            Else
                If toTimeIn > expiration_byTIMEIN Then
                    GoTo expNaB
                Else
                    lblusedBy.ForeColor = Color.Lime
                End If
            End If
        End If
    End Sub

    Private Sub setPreview_Tick(sender As Object, e As EventArgs) Handles setPreview.Tick
        setPreview.Stop()

        If vw_1_menu.DTPickerLocalDateTime.Visible Then
            lblTimeIn.Text = vw_1_menu.DTPickerLocalDateTime.Value.ToString("hh:mm tt")
            lblTimeIn.Tag = vw_1_menu.DTPickerLocalDateTime.Value.ToString("HH:mm:ss")
            lblcurDate.Text = vw_1_menu.DTPickerLocalDateTime.Value.ToString("MM/dd/yyyy")
            lblcurDate.Tag = vw_1_menu.DTPickerLocalDateTime.Value.ToString("yyyy-MM-dd")

            dateProduction.Text = vw_1_menu.DTPickerLocalDateTime.Value.ToString("MM/dd/yyyy")
            dateProduction.Tag = vw_1_menu.DTPickerLocalDateTime.Value.ToString("yyyy-MM-dd")
        End If

        Try
            If lblpreview_itemName.Text <> String.Empty Then
goPrev:
                If cboitems.Text = String.Empty Then
                    lblpreview_days.Text = String.Empty
                    lblpreview_days.Tag = String.Empty
                    lblpreview_itemName.Text = String.Empty
                    lblpreview_productionDate.Text = String.Empty
                    lblpreview_quantityUnit.Text = String.Empty
                    lblpreview_shelftLife.Text = String.Empty
                    lblpreview_timeIN.Text = String.Empty
                    lblpreview_employeeName.Text = String.Empty
                    lblpreview_AM.Text = lblpreview_PM.Tag
                    lblpreview_PM.Text = lblpreview_PM.Tag
                    lblpreview_usedBy.Text = String.Empty
                    lblpreview_manager.Text = String.Empty
                    lblpreview_remarks.Text = String.Empty

                    cboremarks.Text = String.Empty

                    btnsavePrint.Enabled = False
                    btnsave.Enabled = False
                Else
                    GoTo setPrev
                End If
            Else
setPrev:
                If cboitems.Text <> String.Empty Then
                    Call checkExpiration()

                    lblpreview_days.Text = lbldays.Text
                    If Not IsNothing(lbldays.Tag) Then lblpreview_days.Tag = lbldays.Tag
                    lblpreview_itemName.Text = cboitems.Text
                    lblpreview_productionDate.Text = CDate(lblcurDate.Tag).ToString("MM/dd/yyyy (ddd)").ToUpper
                    lblpreview_quantityUnit.Text = lblquantity.Text & " " & lblunit.Text
                    If lblshelflifeBy.Text = "EOD" Then
                        lblpreview_shelftLife.Text = lblshelflifeBy.Text
                    Else
                        lblpreview_shelftLife.Text = lblshelflife.Text & " " & lblshelflifeBy.Text
                    End If

                    lblpreview_timeIN.Text = CDate(CDate(dateProduction.Tag).ToString("yyyy-MM-dd") & " " & lblTimeIn.Tag).ToString("hh:mm tt")
                    lblpreview_employeeName.Text = cboemployee.Text

                    If lblshelflifeBy.Text = "EOD" Then
                        lblpreview_AM.Text = lblpreview_PM.Tag
                        lblpreview_PM.Text = lblpreview_AM.Tag
                    Else
                        If Not IsNothing(lblusedBy.Tag) Then
                            If lblusedBy.Tag.ToString <> String.Empty Then
                                If CDate(lblusedBy.Tag).ToString("tt").ToUpper = "AM" Then
                                    lblpreview_AM.Text = lblpreview_AM.Tag
                                    lblpreview_PM.Text = lblpreview_PM.Tag
                                Else
                                    lblpreview_AM.Text = lblpreview_PM.Tag
                                    lblpreview_PM.Text = lblpreview_AM.Tag
                                End If
                            End If
                        End If

                    End If

                    lblpreview_usedBy.Text = lblusedBy.Text
                    lblpreview_manager.Text = cbomanager.Text
                    If cboremarks.Text = String.Empty Then
                        lblpreview_remarks.Text = "-"
                    Else
                        lblpreview_remarks.Text = cboremarks.Text
                    End If


                    If lblusedBy.ForeColor = Color.Lime And lblquantity.Text <> String.Empty Then

                        btnsavePrint.Enabled = PrinterExists()
                        btnsave.Enabled = True
                    Else
                        btnsavePrint.Enabled = False
                        btnsave.Enabled = False
                    End If
                Else
                    GoTo goPrev
                End If
            End If
        Catch ex As Exception
            btnsavePrint.Enabled = False
            btnsave.Enabled = False
        End Try

        setPreview.Start()
    End Sub
    Private Sub tfocus_Tick(sender As Object, e As EventArgs) Handles tfocus.Tick
        tfocus.Stop()
        cboitems.Focus()
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        If btnclear.Text = "C L E A R" Then
            cboitems.Text = String.Empty
            cboitems.Focus()

            btnclear.Text = "C L O S E"
        Else
            Dispose()
             vw_1_menu.panelMenu.Visible = True
        End If
    End Sub

    Private Sub cboitems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboitems.SelectedIndexChanged

    End Sub

    Private Sub btndate_Click(sender As Object, e As EventArgs) Handles btndate.Click
        Dim frm As New CALENDAR()
        If lblcurDate.Tag.ToString.Length <> 0 Then
            frm.DateValue = CDate(lblcurDate.Tag)
        Else
            frm.DateValue = Now.Date
        End If
        frm.ShowDialog()

        lblcurDate.Text = CDate(frm.DateValue).ToString("MM/dd/yyyy")
        lblcurDate.Tag = CDate(frm.DateValue).ToString("yyyy-MM-dd")
        frm.Dispose()
    End Sub

    Private Sub cbprodDate_CheckedChanged(sender As Object, e As EventArgs) Handles cbprodDate.CheckedChanged
        If cbprodDate.Checked Then
            dateProduction.ForeColor = Color.Black

            Dim frm As New CALENDAR()
            If lblcurDate.Tag.ToString.Length <> 0 Then
                frm.DateValue = CDate(dateProduction.Tag)
            Else
                frm.DateValue = Now.Date
            End If
            frm.ShowDialog()
            dateProduction.Text = CDate(frm.DateValue).ToString("MM/dd/yyyy")
            dateProduction.Tag = CDate(frm.DateValue).ToString("yyyy-MM-dd")
            frm.Dispose()
        Else
            dateProduction.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub btnTIMEIN_Click(sender As Object, e As EventArgs) Handles btnTIMEIN.Click
        Dim frm As New TIME()
        frm.timeValue = CDate(lblTimeIn.Tag).ToString("hh:mm")
        frm.ShowDialog()

        lblTimeIn.Text = CDate(frm.timeValue).ToString("hh:mm tt")
        lblTimeIn.Tag = CDate(frm.timeValue).ToString("HH:mm:ss")

        frm.Dispose()
    End Sub

    Private Sub btnquantity_Click(sender As Object, e As EventArgs) Handles btnquantity.Click
        Dim frm As New QUANTITY()

        frm.quantityValue = lblquantity.Text
        frm.ShowDialog()

        lblquantity.Text = frm.quantityValue

        frm.Dispose()
    End Sub
End Class