﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class vw_2_loginPIN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_2_loginPIN))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnP = New System.Windows.Forms.Button()
        Me.btnO = New System.Windows.Forms.Button()
        Me.btnI = New System.Windows.Forms.Button()
        Me.btnU = New System.Windows.Forms.Button()
        Me.btnY = New System.Windows.Forms.Button()
        Me.btnT = New System.Windows.Forms.Button()
        Me.btnR = New System.Windows.Forms.Button()
        Me.btnE = New System.Windows.Forms.Button()
        Me.btnW = New System.Windows.Forms.Button()
        Me.btnL = New System.Windows.Forms.Button()
        Me.btnK = New System.Windows.Forms.Button()
        Me.btnJ = New System.Windows.Forms.Button()
        Me.btnH = New System.Windows.Forms.Button()
        Me.btnG = New System.Windows.Forms.Button()
        Me.btnF = New System.Windows.Forms.Button()
        Me.btnD = New System.Windows.Forms.Button()
        Me.btnS = New System.Windows.Forms.Button()
        Me.btnSPACE = New System.Windows.Forms.Button()
        Me.btnDELETE = New System.Windows.Forms.Button()
        Me.btnENTER = New System.Windows.Forms.Button()
        Me.btnM = New System.Windows.Forms.Button()
        Me.btnN = New System.Windows.Forms.Button()
        Me.btnB = New System.Windows.Forms.Button()
        Me.btnV = New System.Windows.Forms.Button()
        Me.btnC = New System.Windows.Forms.Button()
        Me.btnX = New System.Windows.Forms.Button()
        Me.btnZ = New System.Windows.Forms.Button()
        Me.btnA = New System.Windows.Forms.Button()
        Me.btnQ = New System.Windows.Forms.Button()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("MS Gothic", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(318, 47)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(190, 24)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ENTER YOUR NAME"
        '
        'PictureBox2
        '
        Me.PictureBox2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(187, 41)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(115, 113)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'txtname
        '
        Me.txtname.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtname.Font = New System.Drawing.Font("MS Gothic", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(322, 74)
        Me.txtname.MaxLength = 32
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(563, 36)
        Me.txtname.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(318, 113)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(459, 38)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "* Enter any of the following that other can easily" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Indentify you like Name/Initi" &
    "al/Nickname"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.BackColor = System.Drawing.Color.Brown
        Me.GroupBox1.Controls.Add(Me.btnP)
        Me.GroupBox1.Controls.Add(Me.btnO)
        Me.GroupBox1.Controls.Add(Me.btnI)
        Me.GroupBox1.Controls.Add(Me.btnU)
        Me.GroupBox1.Controls.Add(Me.btnY)
        Me.GroupBox1.Controls.Add(Me.btnT)
        Me.GroupBox1.Controls.Add(Me.btnR)
        Me.GroupBox1.Controls.Add(Me.btnE)
        Me.GroupBox1.Controls.Add(Me.btnW)
        Me.GroupBox1.Controls.Add(Me.btnL)
        Me.GroupBox1.Controls.Add(Me.btnK)
        Me.GroupBox1.Controls.Add(Me.btnJ)
        Me.GroupBox1.Controls.Add(Me.btnH)
        Me.GroupBox1.Controls.Add(Me.btnG)
        Me.GroupBox1.Controls.Add(Me.btnF)
        Me.GroupBox1.Controls.Add(Me.btnD)
        Me.GroupBox1.Controls.Add(Me.btnS)
        Me.GroupBox1.Controls.Add(Me.btnSPACE)
        Me.GroupBox1.Controls.Add(Me.btnDELETE)
        Me.GroupBox1.Controls.Add(Me.btnENTER)
        Me.GroupBox1.Controls.Add(Me.btnM)
        Me.GroupBox1.Controls.Add(Me.btnN)
        Me.GroupBox1.Controls.Add(Me.btnB)
        Me.GroupBox1.Controls.Add(Me.btnV)
        Me.GroupBox1.Controls.Add(Me.btnC)
        Me.GroupBox1.Controls.Add(Me.btnX)
        Me.GroupBox1.Controls.Add(Me.btnZ)
        Me.GroupBox1.Controls.Add(Me.btnA)
        Me.GroupBox1.Controls.Add(Me.btnQ)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 1.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(-3, 170)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1079, 303)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'btnP
        '
        Me.btnP.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnP.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnP.Location = New System.Drawing.Point(925, 14)
        Me.btnP.Name = "btnP"
        Me.btnP.Size = New System.Drawing.Size(93, 66)
        Me.btnP.TabIndex = 9
        Me.btnP.Text = "P"
        Me.btnP.UseVisualStyleBackColor = True
        '
        'btnO
        '
        Me.btnO.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnO.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnO.Location = New System.Drawing.Point(829, 14)
        Me.btnO.Name = "btnO"
        Me.btnO.Size = New System.Drawing.Size(93, 66)
        Me.btnO.TabIndex = 8
        Me.btnO.Text = "O"
        Me.btnO.UseVisualStyleBackColor = True
        '
        'btnI
        '
        Me.btnI.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnI.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnI.Location = New System.Drawing.Point(733, 14)
        Me.btnI.Name = "btnI"
        Me.btnI.Size = New System.Drawing.Size(93, 66)
        Me.btnI.TabIndex = 7
        Me.btnI.Text = "I"
        Me.btnI.UseVisualStyleBackColor = True
        '
        'btnU
        '
        Me.btnU.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnU.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnU.Location = New System.Drawing.Point(637, 14)
        Me.btnU.Name = "btnU"
        Me.btnU.Size = New System.Drawing.Size(93, 66)
        Me.btnU.TabIndex = 6
        Me.btnU.Text = "U"
        Me.btnU.UseVisualStyleBackColor = True
        '
        'btnY
        '
        Me.btnY.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnY.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnY.Location = New System.Drawing.Point(541, 14)
        Me.btnY.Name = "btnY"
        Me.btnY.Size = New System.Drawing.Size(93, 66)
        Me.btnY.TabIndex = 5
        Me.btnY.Text = "Y"
        Me.btnY.UseVisualStyleBackColor = True
        '
        'btnT
        '
        Me.btnT.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnT.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnT.Location = New System.Drawing.Point(445, 14)
        Me.btnT.Name = "btnT"
        Me.btnT.Size = New System.Drawing.Size(93, 66)
        Me.btnT.TabIndex = 4
        Me.btnT.Text = "T"
        Me.btnT.UseVisualStyleBackColor = True
        '
        'btnR
        '
        Me.btnR.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnR.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnR.Location = New System.Drawing.Point(349, 14)
        Me.btnR.Name = "btnR"
        Me.btnR.Size = New System.Drawing.Size(93, 66)
        Me.btnR.TabIndex = 3
        Me.btnR.Text = "R"
        Me.btnR.UseVisualStyleBackColor = True
        '
        'btnE
        '
        Me.btnE.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnE.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnE.Location = New System.Drawing.Point(253, 14)
        Me.btnE.Name = "btnE"
        Me.btnE.Size = New System.Drawing.Size(93, 66)
        Me.btnE.TabIndex = 2
        Me.btnE.Text = "E"
        Me.btnE.UseVisualStyleBackColor = True
        '
        'btnW
        '
        Me.btnW.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnW.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnW.Location = New System.Drawing.Point(157, 14)
        Me.btnW.Name = "btnW"
        Me.btnW.Size = New System.Drawing.Size(93, 66)
        Me.btnW.TabIndex = 1
        Me.btnW.Text = "W"
        Me.btnW.UseVisualStyleBackColor = True
        '
        'btnL
        '
        Me.btnL.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnL.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnL.Location = New System.Drawing.Point(869, 84)
        Me.btnL.Name = "btnL"
        Me.btnL.Size = New System.Drawing.Size(93, 66)
        Me.btnL.TabIndex = 18
        Me.btnL.Text = "L"
        Me.btnL.UseVisualStyleBackColor = True
        '
        'btnK
        '
        Me.btnK.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnK.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnK.Location = New System.Drawing.Point(773, 84)
        Me.btnK.Name = "btnK"
        Me.btnK.Size = New System.Drawing.Size(93, 66)
        Me.btnK.TabIndex = 17
        Me.btnK.Text = "K"
        Me.btnK.UseVisualStyleBackColor = True
        '
        'btnJ
        '
        Me.btnJ.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnJ.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnJ.Location = New System.Drawing.Point(677, 84)
        Me.btnJ.Name = "btnJ"
        Me.btnJ.Size = New System.Drawing.Size(93, 66)
        Me.btnJ.TabIndex = 16
        Me.btnJ.Text = "J"
        Me.btnJ.UseVisualStyleBackColor = True
        '
        'btnH
        '
        Me.btnH.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnH.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnH.Location = New System.Drawing.Point(581, 84)
        Me.btnH.Name = "btnH"
        Me.btnH.Size = New System.Drawing.Size(93, 66)
        Me.btnH.TabIndex = 15
        Me.btnH.Text = "H"
        Me.btnH.UseVisualStyleBackColor = True
        '
        'btnG
        '
        Me.btnG.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnG.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnG.Location = New System.Drawing.Point(485, 84)
        Me.btnG.Name = "btnG"
        Me.btnG.Size = New System.Drawing.Size(93, 66)
        Me.btnG.TabIndex = 14
        Me.btnG.Text = "G"
        Me.btnG.UseVisualStyleBackColor = True
        '
        'btnF
        '
        Me.btnF.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnF.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnF.Location = New System.Drawing.Point(389, 84)
        Me.btnF.Name = "btnF"
        Me.btnF.Size = New System.Drawing.Size(93, 66)
        Me.btnF.TabIndex = 13
        Me.btnF.Text = "F"
        Me.btnF.UseVisualStyleBackColor = True
        '
        'btnD
        '
        Me.btnD.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnD.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnD.Location = New System.Drawing.Point(293, 84)
        Me.btnD.Name = "btnD"
        Me.btnD.Size = New System.Drawing.Size(93, 66)
        Me.btnD.TabIndex = 12
        Me.btnD.Text = "D"
        Me.btnD.UseVisualStyleBackColor = True
        '
        'btnS
        '
        Me.btnS.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnS.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnS.Location = New System.Drawing.Point(197, 84)
        Me.btnS.Name = "btnS"
        Me.btnS.Size = New System.Drawing.Size(93, 66)
        Me.btnS.TabIndex = 11
        Me.btnS.Text = "S"
        Me.btnS.UseVisualStyleBackColor = True
        '
        'btnSPACE
        '
        Me.btnSPACE.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnSPACE.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSPACE.Location = New System.Drawing.Point(197, 222)
        Me.btnSPACE.Name = "btnSPACE"
        Me.btnSPACE.Size = New System.Drawing.Size(285, 66)
        Me.btnSPACE.TabIndex = 26
        Me.btnSPACE.Text = "SPACE"
        Me.btnSPACE.UseVisualStyleBackColor = True
        '
        'btnDELETE
        '
        Me.btnDELETE.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnDELETE.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDELETE.Image = CType(resources.GetObject("btnDELETE.Image"), System.Drawing.Image)
        Me.btnDELETE.Location = New System.Drawing.Point(812, 153)
        Me.btnDELETE.Name = "btnDELETE"
        Me.btnDELETE.Size = New System.Drawing.Size(93, 66)
        Me.btnDELETE.TabIndex = 26
        Me.btnDELETE.UseVisualStyleBackColor = True
        '
        'btnENTER
        '
        Me.btnENTER.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnENTER.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnENTER.Location = New System.Drawing.Point(485, 222)
        Me.btnENTER.Name = "btnENTER"
        Me.btnENTER.Size = New System.Drawing.Size(381, 66)
        Me.btnENTER.TabIndex = 26
        Me.btnENTER.Text = "ENTER / LOGIN"
        Me.btnENTER.UseVisualStyleBackColor = True
        '
        'btnM
        '
        Me.btnM.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnM.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnM.Location = New System.Drawing.Point(716, 153)
        Me.btnM.Name = "btnM"
        Me.btnM.Size = New System.Drawing.Size(93, 66)
        Me.btnM.TabIndex = 25
        Me.btnM.Text = "M"
        Me.btnM.UseVisualStyleBackColor = True
        '
        'btnN
        '
        Me.btnN.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnN.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnN.Location = New System.Drawing.Point(620, 153)
        Me.btnN.Name = "btnN"
        Me.btnN.Size = New System.Drawing.Size(93, 66)
        Me.btnN.TabIndex = 24
        Me.btnN.Text = "N"
        Me.btnN.UseVisualStyleBackColor = True
        '
        'btnB
        '
        Me.btnB.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnB.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnB.Location = New System.Drawing.Point(524, 153)
        Me.btnB.Name = "btnB"
        Me.btnB.Size = New System.Drawing.Size(93, 66)
        Me.btnB.TabIndex = 23
        Me.btnB.Text = "B"
        Me.btnB.UseVisualStyleBackColor = True
        '
        'btnV
        '
        Me.btnV.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnV.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnV.Location = New System.Drawing.Point(428, 153)
        Me.btnV.Name = "btnV"
        Me.btnV.Size = New System.Drawing.Size(93, 66)
        Me.btnV.TabIndex = 22
        Me.btnV.Text = "V"
        Me.btnV.UseVisualStyleBackColor = True
        '
        'btnC
        '
        Me.btnC.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnC.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnC.Location = New System.Drawing.Point(332, 153)
        Me.btnC.Name = "btnC"
        Me.btnC.Size = New System.Drawing.Size(93, 66)
        Me.btnC.TabIndex = 21
        Me.btnC.Text = "C"
        Me.btnC.UseVisualStyleBackColor = True
        '
        'btnX
        '
        Me.btnX.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnX.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnX.Location = New System.Drawing.Point(236, 153)
        Me.btnX.Name = "btnX"
        Me.btnX.Size = New System.Drawing.Size(93, 66)
        Me.btnX.TabIndex = 20
        Me.btnX.Text = "X"
        Me.btnX.UseVisualStyleBackColor = True
        '
        'btnZ
        '
        Me.btnZ.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnZ.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZ.Location = New System.Drawing.Point(140, 153)
        Me.btnZ.Name = "btnZ"
        Me.btnZ.Size = New System.Drawing.Size(93, 66)
        Me.btnZ.TabIndex = 19
        Me.btnZ.Text = "Z"
        Me.btnZ.UseVisualStyleBackColor = True
        '
        'btnA
        '
        Me.btnA.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnA.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnA.Location = New System.Drawing.Point(101, 84)
        Me.btnA.Name = "btnA"
        Me.btnA.Size = New System.Drawing.Size(93, 66)
        Me.btnA.TabIndex = 10
        Me.btnA.Text = "A"
        Me.btnA.UseVisualStyleBackColor = True
        '
        'btnQ
        '
        Me.btnQ.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnQ.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQ.Location = New System.Drawing.Point(61, 14)
        Me.btnQ.Name = "btnQ"
        Me.btnQ.Size = New System.Drawing.Size(93, 66)
        Me.btnQ.TabIndex = 0
        Me.btnQ.Text = "Q"
        Me.btnQ.UseVisualStyleBackColor = True
        '
        'vw_2_loginPIN
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1073, 485)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_2_loginPIN"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "LOGIN"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents txtname As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnQ As Button
    Friend WithEvents btnP As Button
    Friend WithEvents btnO As Button
    Friend WithEvents btnI As Button
    Friend WithEvents btnU As Button
    Friend WithEvents btnY As Button
    Friend WithEvents btnT As Button
    Friend WithEvents btnR As Button
    Friend WithEvents btnE As Button
    Friend WithEvents btnW As Button
    Friend WithEvents btnL As Button
    Friend WithEvents btnK As Button
    Friend WithEvents btnJ As Button
    Friend WithEvents btnH As Button
    Friend WithEvents btnG As Button
    Friend WithEvents btnF As Button
    Friend WithEvents btnD As Button
    Friend WithEvents btnS As Button
    Friend WithEvents btnENTER As Button
    Friend WithEvents btnM As Button
    Friend WithEvents btnN As Button
    Friend WithEvents btnB As Button
    Friend WithEvents btnV As Button
    Friend WithEvents btnC As Button
    Friend WithEvents btnX As Button
    Friend WithEvents btnZ As Button
    Friend WithEvents btnA As Button
    Friend WithEvents btnSPACE As Button
    Friend WithEvents btnDELETE As Button
End Class
