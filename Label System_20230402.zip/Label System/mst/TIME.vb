﻿Public Class TIME
	Private boolStart As Boolean = False
	Private _timeValue As String
	Friend Property timeValue() As String
		Get
			Return _timeValue
		End Get
		Set(ByVal Value As String)
			_timeValue = Value
		End Set
	End Property
    Private Sub CALENDAR_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbohour.Text = _timeValue.Split(":")(0)
        cbominutes.Text = _timeValue.Split(":")(1)

        boolStart = True
    End Sub
	
	Private Sub btnnext_Click(sender As Object, e As EventArgs) Handles btnnext.Click
		If intFOCUS = 1 Then
			If IsNumeric(cbohour.Text) Then
				If CInt(cbohour.Text) >= 60 Then

				Else
					Dim hour As String = "000" & cbohour.Text
					hour = Mid(hour, hour.Length - 1, 2)
					cbohour.Text = hour

					cbominutes.SelectAll() : cbominutes.Focus()

					intFOCUS = 2
				End If
			Else

			End If
		ElseIf intFOCUS = 2 Then
			If IsNumeric(cbominutes.Text) Then
				If CInt(cbominutes.Text) >= 13 Then

				Else
					Dim mins As String = "000" & cbominutes.Text
					mins = Mid(mins, mins.Length - 1, 2)
					cbominutes.Text = mins

					cbohour.SelectAll() : cbohour.Focus()

					intFOCUS = 1
				End If
			Else

			End If
		End If
	End Sub

	Private intFOCUS As Integer = 1
	Private Sub cboMonth_Enter(sender As Object, e As EventArgs) Handles cbohour.Enter, cbominutes.Enter
		Dim cb As ComboBox = sender

		If cb.Name = cbohour.Name Then
			intFOCUS = 1
		ElseIf cb.Name = cbominutes.Name Then
			intFOCUS = 2
		End If
	End Sub

	Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
		If intFOCUS = 1 Then
			cbohour.Text = String.Empty : cbohour.Focus()
		ElseIf intFOCUS = 2 Then
			cbominutes.Text = String.Empty : cbominutes.Focus()
		End If
	End Sub

	Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn9.Click, btn8.Click, btn7.Click, btn6.Click, btn5.Click, btn4.Click, btn3.Click, btn2.Click, btn1.Click, btn0.Click
		Dim btn As Button = sender

		If intFOCUS = 1 Then
			cbohour.Text &= btn.Text

			If IsNumeric(cbohour.Text) Then
				If CInt(cbohour.Text) >= 13 Then
					cbohour.Text = ""
					cbohour.Text = btn.Text
				Else

				End If
			End If

		ElseIf intFOCUS = 2 Then
			cbominutes.Text &= btn.Text

			If cbominutes.Text.Length >= 3 Then
				cbominutes.Text = ""
				cbominutes.Text = btn.Text
			Else
				If IsNumeric(cbominutes.Text) Then
					If CInt(cbominutes.Text) >= 60 Then
						cbominutes.Text = ""
						cbominutes.Text = btn.Text
					Else

					End If
				End If
			End If
		End If
	End Sub

	Private Sub btnokayClose_Click(sender As Object, e As EventArgs) Handles btnokayClose.Click
        Dim hour As String = "000" & cbohour.Text
		hour = Mid(hour, hour.Length - 1, 2)
		cbohour.Text = hour

		Dim mins As String = "000" & cbominutes.Text
		mins = Mid(mins, mins.Length - 1, 2)
		cbominutes.Text = mins

        If cbohour.Items.Contains(cbohour.Text) And cbominutes.Items.Contains(cbominutes.Text) Then
            If rbAM.Checked Then
                timeValue = Date.Now.ToString("yyyy-MM-dd") & " " & cbohour.Text & ":" & cbominutes.Text & ":00 AM"

            Else
                timeValue = Date.Now.ToString("yyyy-MM-dd") & " " & cbohour.Text & ":" & cbominutes.Text & ":00 PM"

            End If

            Close()
        End If
	End Sub
End Class