﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_itemMaster
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.pmain = New System.Windows.Forms.Panel()
        Me.numDays = New Label_System.modComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.cboshelflifeByDef = New Label_System.modComboBox()
        Me.cboshelflifeDef = New Label_System.modComboBox()
        Me.cbautoSearch = New System.Windows.Forms.CheckBox()
        Me.llblclose = New System.Windows.Forms.LinkLabel()
        Me.llblrefresh = New System.Windows.Forms.LinkLabel()
        Me.llbladdSave = New System.Windows.Forms.LinkLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.griditemList = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.cbostorage = New Label_System.modComboBox()
        Me.cbounit = New Label_System.modComboBox()
        Me.cboshelflifeBy = New Label_System.modComboBox()
        Me.cboshelflife = New Label_System.modComboBox()
        Me.cbocondition = New Label_System.modComboBox()
        Me.cboitemMat = New Label_System.modComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.numDaysBy = New Label_System.modComboBox()
        Me.pmain.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.numDays)
        Me.pmain.Controls.Add(Me.Label9)
        Me.pmain.Controls.Add(Me.cboshelflifeByDef)
        Me.pmain.Controls.Add(Me.cboshelflifeDef)
        Me.pmain.Controls.Add(Me.cbautoSearch)
        Me.pmain.Controls.Add(Me.llblclose)
        Me.pmain.Controls.Add(Me.llblrefresh)
        Me.pmain.Controls.Add(Me.llbladdSave)
        Me.pmain.Controls.Add(Me.Panel1)
        Me.pmain.Controls.Add(Me.cbostorage)
        Me.pmain.Controls.Add(Me.cbounit)
        Me.pmain.Controls.Add(Me.cboshelflifeBy)
        Me.pmain.Controls.Add(Me.cboshelflife)
        Me.pmain.Controls.Add(Me.cbocondition)
        Me.pmain.Controls.Add(Me.cboitemMat)
        Me.pmain.Controls.Add(Me.Label1)
        Me.pmain.Controls.Add(Me.Label8)
        Me.pmain.Controls.Add(Me.Label5)
        Me.pmain.Controls.Add(Me.Label7)
        Me.pmain.Controls.Add(Me.Label4)
        Me.pmain.Controls.Add(Me.Label6)
        Me.pmain.Controls.Add(Me.Label3)
        Me.pmain.Controls.Add(Me.Label2)
        Me.pmain.Controls.Add(Me.numDaysBy)
        Me.pmain.Location = New System.Drawing.Point(2, 2)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(922, 686)
        Me.pmain.TabIndex = 0
        '
        'numDays
        '
        Me.numDays.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.numDays.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.numDays.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.numDays.FormattingEnabled = True
        Me.numDays.Location = New System.Drawing.Point(595, 167)
        Me.numDays.Name = "numDays"
        Me.numDays.Size = New System.Drawing.Size(131, 27)
        Me.numDays.TabIndex = 7
        Me.numDays.Tag = "DECIMAL"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(595, 140)
        Me.Label9.Name = "Label9"
        Me.Label9.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label9.Size = New System.Drawing.Size(316, 24)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "ADDITIONAL DAY(S) :"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboshelflifeByDef
        '
        Me.cboshelflifeByDef.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboshelflifeByDef.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboshelflifeByDef.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboshelflifeByDef.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cboshelflifeByDef.FormattingEnabled = True
        Me.cboshelflifeByDef.Items.AddRange(New Object() {"-", "EOD", "MINUTES", "HOUR(S)", "DAY(S)", "WEEK(S)", "MONTH(S)", "YEAR(S)"})
        Me.cboshelflifeByDef.Location = New System.Drawing.Point(373, 167)
        Me.cboshelflifeByDef.Name = "cboshelflifeByDef"
        Me.cboshelflifeByDef.Size = New System.Drawing.Size(216, 27)
        Me.cboshelflifeByDef.TabIndex = 6
        '
        'cboshelflifeDef
        '
        Me.cboshelflifeDef.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboshelflifeDef.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboshelflifeDef.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cboshelflifeDef.FormattingEnabled = True
        Me.cboshelflifeDef.Location = New System.Drawing.Point(236, 167)
        Me.cboshelflifeDef.Name = "cboshelflifeDef"
        Me.cboshelflifeDef.Size = New System.Drawing.Size(131, 27)
        Me.cboshelflifeDef.TabIndex = 5
        Me.cboshelflifeDef.Tag = "DECIMAL"
        '
        'cbautoSearch
        '
        Me.cbautoSearch.AutoSize = True
        Me.cbautoSearch.Location = New System.Drawing.Point(14, 278)
        Me.cbautoSearch.Name = "cbautoSearch"
        Me.cbautoSearch.Size = New System.Drawing.Size(115, 20)
        Me.cbautoSearch.TabIndex = 13
        Me.cbautoSearch.Text = "Auto Search"
        Me.cbautoSearch.UseVisualStyleBackColor = True
        '
        'llblclose
        '
        Me.llblclose.AutoSize = True
        Me.llblclose.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.llblclose.Location = New System.Drawing.Point(812, 279)
        Me.llblclose.Name = "llblclose"
        Me.llblclose.Size = New System.Drawing.Size(99, 19)
        Me.llblclose.TabIndex = 12
        Me.llblclose.TabStop = True
        Me.llblclose.Text = "Close...."
        '
        'llblrefresh
        '
        Me.llblrefresh.AutoSize = True
        Me.llblrefresh.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblrefresh.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.llblrefresh.Location = New System.Drawing.Point(422, 279)
        Me.llblrefresh.Name = "llblrefresh"
        Me.llblrefresh.Size = New System.Drawing.Size(119, 19)
        Me.llblrefresh.TabIndex = 10
        Me.llblrefresh.TabStop = True
        Me.llblrefresh.Text = "Refresh...."
        '
        'llbladdSave
        '
        Me.llbladdSave.AutoSize = True
        Me.llbladdSave.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llbladdSave.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.llbladdSave.Location = New System.Drawing.Point(562, 279)
        Me.llbladdSave.Name = "llbladdSave"
        Me.llbladdSave.Size = New System.Drawing.Size(229, 19)
        Me.llbladdSave.TabIndex = 11
        Me.llbladdSave.TabStop = True
        Me.llbladdSave.Text = "Add / Save to List...."
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.griditemList)
        Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 9.75!)
        Me.Panel1.Location = New System.Drawing.Point(3, 307)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(916, 376)
        Me.Panel1.TabIndex = 11
        '
        'griditemList
        '
        Me.griditemList.AllowUserToAddRows = False
        Me.griditemList.AllowUserToDeleteRows = False
        Me.griditemList.AllowUserToResizeColumns = False
        Me.griditemList.AllowUserToResizeRows = False
        Me.griditemList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.griditemList.BackgroundColor = System.Drawing.Color.White
        Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial Narrow", 9.75!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.griditemList.ColumnHeadersHeight = 28
        Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial Narrow", 9.75!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.griditemList.DefaultCellStyle = DataGridViewCellStyle2
        Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.griditemList.EnableHeadersVisualStyles = False
        Me.griditemList.Location = New System.Drawing.Point(0, 0)
        Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.griditemList.MultiSelect = False
        Me.griditemList.Name = "griditemList"
        Me.griditemList.ReadOnly = True
        Me.griditemList.RowHeadersVisible = False
        Me.griditemList.RowTemplate.Height = 25
        Me.griditemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.griditemList.ShowCellErrors = False
        Me.griditemList.ShowCellToolTips = False
        Me.griditemList.ShowEditingIcon = False
        Me.griditemList.ShowRowErrors = False
        Me.griditemList.Size = New System.Drawing.Size(916, 376)
        Me.griditemList.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Remove"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'cbostorage
        '
        Me.cbostorage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbostorage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbostorage.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cbostorage.FormattingEnabled = True
        Me.cbostorage.Location = New System.Drawing.Point(14, 230)
        Me.cbostorage.Name = "cbostorage"
        Me.cbostorage.Size = New System.Drawing.Size(897, 27)
        Me.cbostorage.TabIndex = 9
        '
        'cbounit
        '
        Me.cbounit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbounit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbounit.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cbounit.FormattingEnabled = True
        Me.cbounit.Location = New System.Drawing.Point(14, 167)
        Me.cbounit.Name = "cbounit"
        Me.cbounit.Size = New System.Drawing.Size(216, 27)
        Me.cbounit.TabIndex = 4
        '
        'cboshelflifeBy
        '
        Me.cboshelflifeBy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboshelflifeBy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboshelflifeBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboshelflifeBy.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cboshelflifeBy.FormattingEnabled = True
        Me.cboshelflifeBy.Items.AddRange(New Object() {"EOD", "MINUTES", "HOUR(S)", "DAY(S)", "WEEK(S)", "MONTH(S)", "YEAR(S)"})
        Me.cboshelflifeBy.Location = New System.Drawing.Point(595, 104)
        Me.cboshelflifeBy.Name = "cboshelflifeBy"
        Me.cboshelflifeBy.Size = New System.Drawing.Size(316, 27)
        Me.cboshelflifeBy.TabIndex = 3
        '
        'cboshelflife
        '
        Me.cboshelflife.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboshelflife.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboshelflife.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cboshelflife.FormattingEnabled = True
        Me.cboshelflife.Location = New System.Drawing.Point(368, 104)
        Me.cboshelflife.Name = "cboshelflife"
        Me.cboshelflife.Size = New System.Drawing.Size(221, 27)
        Me.cboshelflife.TabIndex = 2
        Me.cboshelflife.Tag = "DECIMAL"
        '
        'cbocondition
        '
        Me.cbocondition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbocondition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbocondition.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cbocondition.FormattingEnabled = True
        Me.cbocondition.Location = New System.Drawing.Point(14, 104)
        Me.cbocondition.Name = "cbocondition"
        Me.cbocondition.Size = New System.Drawing.Size(348, 27)
        Me.cbocondition.TabIndex = 1
        '
        'cboitemMat
        '
        Me.cboitemMat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboitemMat.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboitemMat.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.cboitemMat.FormattingEnabled = True
        Me.cboitemMat.Location = New System.Drawing.Point(14, 41)
        Me.cboitemMat.Name = "cboitemMat"
        Me.cboitemMat.Size = New System.Drawing.Size(897, 27)
        Me.cboitemMat.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(369, 142)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label1.Size = New System.Drawing.Size(220, 24)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "DEFAULT (BY) :"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(232, 142)
        Me.Label8.Name = "Label8"
        Me.Label8.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label8.Size = New System.Drawing.Size(135, 24)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "DEFAULT :"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(591, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label5.Size = New System.Drawing.Size(320, 24)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "SHELFLIFE (BY) :"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(10, 205)
        Me.Label7.Name = "Label7"
        Me.Label7.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label7.Size = New System.Drawing.Size(901, 24)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "STORAGE :"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(364, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label4.Size = New System.Drawing.Size(181, 24)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "SHELFLIFE :"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(10, 142)
        Me.Label6.Name = "Label6"
        Me.Label6.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label6.Size = New System.Drawing.Size(233, 24)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "UNIT :"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(10, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label3.Size = New System.Drawing.Size(352, 24)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "CONDITION :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(10, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
        Me.Label2.Size = New System.Drawing.Size(451, 24)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "ITEM / MATERIAL NAME :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'numDaysBy
        '
        Me.numDaysBy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.numDaysBy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.numDaysBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.numDaysBy.Font = New System.Drawing.Font("Tahoma", 12.0!)
        Me.numDaysBy.FormattingEnabled = True
        Me.numDaysBy.Items.AddRange(New Object() {"DAY(S)", "WEEK(S)", "MONTH(S)", "YEAR(S)"})
        Me.numDaysBy.Location = New System.Drawing.Point(732, 167)
        Me.numDaysBy.Name = "numDaysBy"
        Me.numDaysBy.Size = New System.Drawing.Size(179, 27)
        Me.numDaysBy.TabIndex = 8
        '
        'vw_3_itemMaster
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(926, 690)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_3_itemMaster"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.pmain.ResumeLayout(False)
        Me.pmain.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents griditemList As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents llbladdSave As System.Windows.Forms.LinkLabel
    Friend WithEvents llblrefresh As System.Windows.Forms.LinkLabel
    Friend WithEvents cbautoSearch As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cboitemMat As Label_System.modComboBox
    Friend WithEvents cbostorage As Label_System.modComboBox
    Friend WithEvents cbounit As Label_System.modComboBox
    Friend WithEvents cboshelflifeBy As Label_System.modComboBox
    Friend WithEvents cboshelflife As Label_System.modComboBox
    Friend WithEvents cbocondition As Label_System.modComboBox
    Friend WithEvents llblclose As System.Windows.Forms.LinkLabel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cboshelflifeByDef As Label_System.modComboBox
    Friend WithEvents cboshelflifeDef As Label_System.modComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents numDaysBy As Label_System.modComboBox
    Friend WithEvents numDays As Label_System.modComboBox
End Class
