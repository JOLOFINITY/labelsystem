﻿Imports System.Runtime.InteropServices
Public Class vw_2_user_maintenance
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub vw_3_registration_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
		Dispose()
	End Sub

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, panelHeader.MouseDown, Label2.MouseDown, Label3.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub


#End Region
	Private Sub vw_2_registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
	
	End Sub
	Private Sub vw_3_registration_Shown(sender As Object, e As EventArgs) Handles Me.Shown
		roundCorners(Me, Color.DimGray)

		Call comboList(cboq1)

		Call getUserlist(gridUsers)
		gridUsers.ClearSelection()
	End Sub
	Private Sub txtname_KeyDown(sender As Object, e As KeyEventArgs) Handles txtname.KeyDown, txtsearch.KeyDown
		If e.KeyCode = Keys.Enter And txtusername.Enabled Then
			txtusername.SelectAll() : txtusername.Focus()
		End If
	End Sub

	Private Sub llblregister_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblregister.LinkClicked
		Call activateUsers()

		MessageBox.Show("All new account successfully activated.", "Activation Complete!", MessageBoxButtons.OK, MessageBoxIcon.Information)

		Call clear()
	End Sub
	Sub clear()
		txtname.Clear() : txtname.Focus()

		txtusername.Clear() : txtusername.Enabled = False

		rbqa1.Checked = True

		cboq1.Text = String.Empty : cboa1.Text = String.Empty

		Call getUserlist(gridUsers)
	End Sub

	Private Sub llblclear_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclear.LinkClicked
		Call clear()
	End Sub
	Private Sub llblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclose.LinkClicked
        Dispose()

        vw_1_menu.panelMenu.Visible = True
    End Sub

	Private Sub tfocus_Tick(sender As Object, e As EventArgs) Handles tfocus.Tick
		tfocus.Stop()

		txtname.Focus()
	End Sub

	Private user As New DataTable("result")
	Private Sub gridUsers_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridUsers.CellClick
		If e.ColumnIndex = 0 And e.RowIndex >= 0 Then
			Call getUserlist(gridUsers)

			user = getUser(gridUsers.Rows(e.RowIndex).Cells(3).Value)

            If user.Rows.Count = 1 Then
                rbadmin.Enabled = True
                rbuser.Enabled = True

                If user.Rows(0)("ACCESS").ToString = "ADMIN" Then
                    rbadmin.Checked = True
                Else
                    rbuser.Checked = True
                End If

                txtname.Text = user.Rows(0)("Name").ToString
                txtusername.Text = user.Rows(0)("Username").ToString

                rbqa1.Checked = True

                cboq1.Text = user.Rows(0)("Security Question 1").ToString
                cboa1.Text = user.Rows(0)("Answer Question 1").ToString

                llbldelete.Visible = True
            Else
                rbadmin.Checked = False : rbadmin.Enabled = False
                rbuser.Checked = False : rbuser.Enabled = False

                txtname.Text = String.Empty
                txtusername.Text = String.Empty

                rbqa1.Checked = True

                cboq1.Text = String.Empty
                cboa1.Text = String.Empty

                user.Rows.Clear()

                llblregister.Visible = False
                llbldelete.Visible = False
            End If
		End If
	End Sub

	Private Sub rbqa1_CheckedChanged(sender As Object, e As EventArgs) Handles rbqa1.CheckedChanged
		If user.Rows.Count = 1 Then
			cboq1.Text = user.Rows(0)("Security Question 1").ToString
			cboa1.Text = user.Rows(0)("Answer Question 1").ToString
		End If
	End Sub

	Private Sub rbqa2_CheckedChanged(sender As Object, e As EventArgs) Handles rbqa2.CheckedChanged
		If user.Rows.Count = 1 Then
			cboq1.Text = user.Rows(0)("Security Question 2").ToString
			cboa1.Text = user.Rows(0)("Answer Question 2").ToString
		End If
	End Sub

	Private Sub rbqa3_CheckedChanged(sender As Object, e As EventArgs) Handles rbqa3.CheckedChanged
		If user.Rows.Count = 1 Then
			cboq1.Text = user.Rows(0)("Security Question 3").ToString
			cboa1.Text = user.Rows(0)("Answer Question 3").ToString
		End If
	End Sub

	Private Sub txtsearch_TextChanged(sender As Object, e As EventArgs) Handles txtsearch.TextChanged
		_exec_gridSearch(gridUsers, txtsearch.Text)
	End Sub

	Private Sub llbldelete_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbldelete.LinkClicked
		If txtusername.Text <> String.Empty Then

			If MessageBox.Show("Delete/Remove selected Account?...", "User Input.", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
				deleteUser(txtusername.Text)

				MessageBox.Show("Account successfully Deleted...", "Deleted!", MessageBoxButtons.OK, MessageBoxIcon.Information)

				Call clear()

			End If
		End If
	End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles rbuser.CheckedChanged, rbadmin.CheckedChanged
        If rbadmin.Checked Then
            updateUserAccess(txtusername.Text, "ADMIN")
        ElseIf rbuser.Checked Then
            updateUserAccess(txtusername.Text, "USER")

        End If

        Call getUserlist(gridUsers)
        gridUsers.ClearSelection()
    End Sub

    Private Sub gridUsers_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridUsers.CellContentClick

    End Sub

    Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged

    End Sub
End Class