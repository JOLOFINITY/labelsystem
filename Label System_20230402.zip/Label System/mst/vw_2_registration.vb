﻿Imports System.Runtime.InteropServices
Public Class vw_2_registration
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub vw_3_registration_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dispose()

        vw_1_menu.panelMenu.Visible = True
    End Sub

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, panelHeader.MouseDown, Label2.MouseDown, Label3.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub


#End Region
	Private Sub vw_2_registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load

	End Sub

	Private Sub txtname_TextChanged(sender As Object, e As EventArgs) Handles txtname.TextChanged
		If txtname.Text.Length >= 3 Then
			txtusername.Enabled = True
		Else
			If txtusername.Enabled Then
				txtusername.Clear() : txtusername.Enabled = False
			End If
		End If
	End Sub
	Private Sub txtname_KeyDown(sender As Object, e As KeyEventArgs) Handles txtname.KeyDown
		If e.KeyCode = Keys.Enter And txtusername.Enabled Then
			txtusername.SelectAll() : txtusername.Focus()
		End If
	End Sub

	Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged
		lbluserName.Text = String.Empty

		If txtusername.Text.Length >= 3 Then
			txtpassword1.Enabled = True
		Else
			If txtpassword1.Enabled Then
				txtpassword1.Clear() : txtpassword1.Enabled = False
				txtpassword2.Clear() : txtpassword2.Enabled = False
			End If
		End If
	End Sub
	Private Sub txtusername_Leave(sender As Object, e As EventArgs) Handles txtusername.Leave
		userChecker.Start()
	End Sub
	Private Sub userChecker_Tick(sender As Object, e As EventArgs) Handles userChecker.Tick
		userChecker.Stop()

		Dim user = getUser(txtusername.Text)
		If user.Rows.Count >= 1 Then
			lbluserName.Text = "* * Already taken."
			lbluserName.ForeColor = Color.White
		Else
			lbluserName.Text = String.Empty
		End If
	End Sub
	Private Sub txtpassword1_TextChanged(sender As Object, e As EventArgs) Handles txtpassword1.TextChanged
		If txtpassword1.Text.Length >= 6 Then
			txtpassword2.Enabled = True
		Else
			If txtpassword2.Enabled Then
				llblpasswordMatch.Text = String.Empty : txtpassword2.Clear() : txtpassword2.Enabled = False
			End If
		End If
	End Sub
	Private Sub txtpassword1_KeyDown(sender As Object, e As KeyEventArgs) Handles txtpassword1.KeyDown
		If e.KeyCode = Keys.Enter And txtpassword2.Enabled Then
			txtpassword2.SelectAll() : txtpassword2.Focus()
		End If
	End Sub

	Private Sub txtpassword2_TextChanged(sender As Object, e As EventArgs) Handles txtpassword2.TextChanged
		With llblpasswordMatch
			If txtpassword2.Text = String.Empty Then
				.Text = String.Empty
			Else
				If txtpassword1.Text <> txtpassword2.Text Then
					.Text = "* * Check Password, Not match!"
					.ForeColor = Color.White
				Else
					.Text = "Password Okay!"
					.ForeColor = Color.Lime
				End If
			End If
		End With

	End Sub

	Private Sub llblregister_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblregister.LinkClicked
        If txtname.Text.Length <= 2 Then
            txtname.SelectAll() : txtname.Focus()

        ElseIf txtusername.Text.Length <= 2 Then
            txtusername.SelectAll() : txtusername.Focus()

        ElseIf txtpassword1.Text.Length < 3 Then
            txtpassword1.SelectAll() : txtpassword1.Focus()

        Else 'If txtpassword1.Text = txtpassword2.Text And txtpassword1.Text <> String.Empty Then

            Dim user = getUser(txtusername.Text)
            If user.Rows.Count >= 1 Then
                MessageBox.Show("Username already exist, please enter new Username.", "Username already taken.", MessageBoxButtons.OK, MessageBoxIcon.Information)

                txtusername.SelectAll() : txtusername.Focus()
            Else
                Call add_newUser(txtname.Text, txtusername.Text, txtpassword2.Text, cboq1.Text, cboa1.Text, cboq2.Text, cboa2.Text, cboq3.Text, cboa3.Text)

                Call clear()
            End If
        End If
	End Sub
	Sub clear()
		txtname.Clear() : txtname.Focus()

		txtusername.Clear() : txtusername.Enabled = False

		txtpassword1.Clear() : txtpassword1.Enabled = False
		txtpassword2.Clear() : txtpassword2.Enabled = False
		llblpasswordMatch.Text = String.Empty

		cboq1.Text = String.Empty : cboa1.Text = String.Empty
		cboq2.Text = String.Empty : cboa2.Text = String.Empty
		cboq3.Text = String.Empty : cboa3.Text = String.Empty
	End Sub

	Private Sub llblclear_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclear.LinkClicked
		Call clear()
	End Sub
	Private Sub llblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclose.LinkClicked
		Dispose()
		vw_1_menu.disabled()
	End Sub

	Private Sub vw_3_registration_Shown(sender As Object, e As EventArgs) Handles Me.Shown
		roundCorners(Me, Color.DimGray)

		Call comboList(cboq1)
		Call comboList(cboq2)
        Call comboList(cboq3)

        Top = 0
	End Sub

	Private Sub tfocus_Tick(sender As Object, e As EventArgs) Handles tfocus.Tick
		tfocus.Stop()

		txtname.Focus()
	End Sub

	Private Sub lbluserName_Click(sender As Object, e As EventArgs) Handles lbluserName.Click

	End Sub
End Class