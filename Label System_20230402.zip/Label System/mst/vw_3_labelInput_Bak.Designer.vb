﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_labelInput_Bak
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_3_labelInput_Bak))
		Me.pmain = New System.Windows.Forms.Panel()
		Me.lblvalidity = New System.Windows.Forms.Label()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.griditemList = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.btnsave = New System.Windows.Forms.Button()
		Me.btnsavePrint = New System.Windows.Forms.Button()
		Me.lbldays = New System.Windows.Forms.Label()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.lblI = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.lblF = New System.Windows.Forms.Label()
		Me.cboquantity = New System.Windows.Forms.ComboBox()
		Me.lblD = New System.Windows.Forms.Label()
		Me.lblproduction = New System.Windows.Forms.Label()
		Me.lblL = New System.Windows.Forms.Label()
		Me.lblJ = New System.Windows.Forms.Label()
		Me.lblK = New System.Windows.Forms.Label()
		Me.lblH = New System.Windows.Forms.Label()
		Me.Label15 = New System.Windows.Forms.Label()
		Me.Label17 = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.cboremarks = New System.Windows.Forms.ComboBox()
		Me.cboemployee = New System.Windows.Forms.ComboBox()
		Me.cbomanager = New System.Windows.Forms.ComboBox()
		Me.cbostorage = New System.Windows.Forms.ComboBox()
		Me.lblG = New System.Windows.Forms.Label()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.cbounit = New System.Windows.Forms.ComboBox()
		Me.lblE = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.cboprocess = New System.Windows.Forms.ComboBox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.lblC = New System.Windows.Forms.Label()
		Me.lblB = New System.Windows.Forms.Label()
		Me.lblA = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.lblusedBy = New System.Windows.Forms.Label()
		Me.dtTimeIn = New System.Windows.Forms.DateTimePicker()
		Me.dateProduction = New System.Windows.Forms.DateTimePicker()
		Me.cbocondition = New System.Windows.Forms.ComboBox()
		Me.cboitems = New System.Windows.Forms.ComboBox()
		Me.cboterm = New System.Windows.Forms.ComboBox()
		Me.lblterm = New System.Windows.Forms.Label()
		Me.cbotenure = New System.Windows.Forms.ComboBox()
		Me.picNew = New System.Windows.Forms.PictureBox()
		Me.pmain.SuspendLayout()
		Me.Panel1.SuspendLayout()
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.GroupBox1.SuspendLayout()
		CType(Me.picNew, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'pmain
		'
		Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.White
		Me.pmain.Controls.Add(Me.lblvalidity)
		Me.pmain.Controls.Add(Me.Panel1)
		Me.pmain.Controls.Add(Me.GroupBox1)
		Me.pmain.Location = New System.Drawing.Point(2, 2)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(944, 774)
		Me.pmain.TabIndex = 0
		'
		'lblvalidity
		'
		Me.lblvalidity.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.lblvalidity.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblvalidity.ForeColor = System.Drawing.Color.Lime
		Me.lblvalidity.Location = New System.Drawing.Point(70, 417)
		Me.lblvalidity.Name = "lblvalidity"
		Me.lblvalidity.Size = New System.Drawing.Size(600, 29)
		Me.lblvalidity.TabIndex = 29
		Me.lblvalidity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.Controls.Add(Me.griditemList)
		Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Panel1.Location = New System.Drawing.Point(3, 463)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(938, 308)
		Me.Panel1.TabIndex = 15
		'
		'griditemList
		'
		Me.griditemList.AllowUserToAddRows = False
		Me.griditemList.AllowUserToDeleteRows = False
		Me.griditemList.AllowUserToResizeColumns = False
		Me.griditemList.AllowUserToResizeRows = False
		Me.griditemList.BackgroundColor = System.Drawing.Color.White
		Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
		Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
		Me.griditemList.ColumnHeadersHeight = 36
		Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
		DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.griditemList.DefaultCellStyle = DataGridViewCellStyle2
		Me.griditemList.Dock = System.Windows.Forms.DockStyle.Fill
		Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.griditemList.EnableHeadersVisualStyles = False
		Me.griditemList.Location = New System.Drawing.Point(0, 0)
		Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
		Me.griditemList.MultiSelect = False
		Me.griditemList.Name = "griditemList"
		Me.griditemList.ReadOnly = True
		Me.griditemList.RowHeadersVisible = False
		Me.griditemList.RowTemplate.Height = 28
		Me.griditemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.griditemList.ShowCellErrors = False
		Me.griditemList.ShowCellToolTips = False
		Me.griditemList.ShowEditingIcon = False
		Me.griditemList.ShowRowErrors = False
		Me.griditemList.Size = New System.Drawing.Size(938, 308)
		Me.griditemList.TabIndex = 0
		'
		'Column1
		'
		Me.Column1.HeaderText = "Select"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		'
		'GroupBox1
		'
		Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.GroupBox1.Controls.Add(Me.btnsave)
		Me.GroupBox1.Controls.Add(Me.btnsavePrint)
		Me.GroupBox1.Controls.Add(Me.lbldays)
		Me.GroupBox1.Controls.Add(Me.Label9)
		Me.GroupBox1.Controls.Add(Me.Label11)
		Me.GroupBox1.Controls.Add(Me.lblI)
		Me.GroupBox1.Controls.Add(Me.Label4)
		Me.GroupBox1.Controls.Add(Me.lblF)
		Me.GroupBox1.Controls.Add(Me.cboquantity)
		Me.GroupBox1.Controls.Add(Me.lblD)
		Me.GroupBox1.Controls.Add(Me.lblproduction)
		Me.GroupBox1.Controls.Add(Me.lblL)
		Me.GroupBox1.Controls.Add(Me.lblJ)
		Me.GroupBox1.Controls.Add(Me.lblK)
		Me.GroupBox1.Controls.Add(Me.lblH)
		Me.GroupBox1.Controls.Add(Me.Label15)
		Me.GroupBox1.Controls.Add(Me.Label17)
		Me.GroupBox1.Controls.Add(Me.Label3)
		Me.GroupBox1.Controls.Add(Me.Label14)
		Me.GroupBox1.Controls.Add(Me.cboremarks)
		Me.GroupBox1.Controls.Add(Me.cboemployee)
		Me.GroupBox1.Controls.Add(Me.cbomanager)
		Me.GroupBox1.Controls.Add(Me.cbostorage)
		Me.GroupBox1.Controls.Add(Me.lblG)
		Me.GroupBox1.Controls.Add(Me.Label12)
		Me.GroupBox1.Controls.Add(Me.cbounit)
		Me.GroupBox1.Controls.Add(Me.lblE)
		Me.GroupBox1.Controls.Add(Me.Label2)
		Me.GroupBox1.Controls.Add(Me.Label10)
		Me.GroupBox1.Controls.Add(Me.cboprocess)
		Me.GroupBox1.Controls.Add(Me.Label8)
		Me.GroupBox1.Controls.Add(Me.lblC)
		Me.GroupBox1.Controls.Add(Me.lblB)
		Me.GroupBox1.Controls.Add(Me.lblA)
		Me.GroupBox1.Controls.Add(Me.Label5)
		Me.GroupBox1.Controls.Add(Me.Label6)
		Me.GroupBox1.Controls.Add(Me.Label7)
		Me.GroupBox1.Controls.Add(Me.lblusedBy)
		Me.GroupBox1.Controls.Add(Me.dtTimeIn)
		Me.GroupBox1.Controls.Add(Me.dateProduction)
		Me.GroupBox1.Controls.Add(Me.cbocondition)
		Me.GroupBox1.Controls.Add(Me.cboitems)
		Me.GroupBox1.Controls.Add(Me.cboterm)
		Me.GroupBox1.Controls.Add(Me.lblterm)
		Me.GroupBox1.Controls.Add(Me.cbotenure)
		Me.GroupBox1.Controls.Add(Me.picNew)
		Me.GroupBox1.Font = New System.Drawing.Font("MS Gothic", 1.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.GroupBox1.Location = New System.Drawing.Point(5, 3)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(934, 457)
		Me.GroupBox1.TabIndex = 0
		Me.GroupBox1.TabStop = False
		'
		'btnsave
		'
		Me.btnsave.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.btnsave.Enabled = False
		Me.btnsave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnsave.ForeColor = System.Drawing.Color.Gray
		Me.btnsave.Location = New System.Drawing.Point(671, 412)
		Me.btnsave.Name = "btnsave"
		Me.btnsave.Size = New System.Drawing.Size(124, 34)
		Me.btnsave.TabIndex = 37
		Me.btnsave.Tag = "0"
		Me.btnsave.Text = "Save [F2]"
		Me.btnsave.UseVisualStyleBackColor = True
		'
		'btnsavePrint
		'
		Me.btnsavePrint.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.btnsavePrint.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnsavePrint.ForeColor = System.Drawing.Color.Blue
		Me.btnsavePrint.Location = New System.Drawing.Point(801, 412)
		Me.btnsavePrint.Name = "btnsavePrint"
		Me.btnsavePrint.Size = New System.Drawing.Size(121, 34)
		Me.btnsavePrint.TabIndex = 37
		Me.btnsavePrint.Tag = "1"
		Me.btnsavePrint.Text = "Clear [F5]"
		Me.btnsavePrint.UseVisualStyleBackColor = True
		'
		'lbldays
		'
		Me.lbldays.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lbldays.BackColor = System.Drawing.Color.DimGray
		Me.lbldays.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lbldays.ForeColor = System.Drawing.Color.White
		Me.lbldays.Location = New System.Drawing.Point(16, 14)
		Me.lbldays.Name = "lbldays"
		Me.lbldays.Size = New System.Drawing.Size(61, 389)
		Me.lbldays.TabIndex = 36
		Me.lbldays.Tag = ""
		Me.lbldays.Text = "W" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "N" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "S" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Y"
		Me.lbldays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label9
		'
		Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label9.BackColor = System.Drawing.Color.FloralWhite
		Me.Label9.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label9.ForeColor = System.Drawing.Color.White
		Me.Label9.Location = New System.Drawing.Point(90, 254)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(11, 34)
		Me.Label9.TabIndex = 35
		Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label11
		'
		Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label11.BackColor = System.Drawing.Color.DimGray
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label11.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label11.ForeColor = System.Drawing.Color.White
		Me.Label11.Location = New System.Drawing.Point(89, 253)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(227, 36)
		Me.Label11.TabIndex = 34
		Me.Label11.Tag = "C"
		Me.Label11.Text = "USE BY ( UNTIL ) :"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblI
		'
		Me.lblI.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblI.BackColor = System.Drawing.Color.Firebrick
		Me.lblI.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblI.ForeColor = System.Drawing.Color.White
		Me.lblI.Location = New System.Drawing.Point(90, 221)
		Me.lblI.Name = "lblI"
		Me.lblI.Size = New System.Drawing.Size(11, 27)
		Me.lblI.TabIndex = 33
		Me.lblI.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label4
		'
		Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label4.BackColor = System.Drawing.Color.DimGray
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label4.ForeColor = System.Drawing.Color.White
		Me.Label4.Location = New System.Drawing.Point(89, 220)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(227, 29)
		Me.Label4.TabIndex = 32
		Me.Label4.Tag = "C"
		Me.Label4.Text = "TIME IN :"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblF
		'
		Me.lblF.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblF.BackColor = System.Drawing.Color.Firebrick
		Me.lblF.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblF.ForeColor = System.Drawing.Color.White
		Me.lblF.Location = New System.Drawing.Point(441, 146)
		Me.lblF.Name = "lblF"
		Me.lblF.Size = New System.Drawing.Size(11, 28)
		Me.lblF.TabIndex = 31
		Me.lblF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'cboquantity
		'
		Me.cboquantity.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboquantity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboquantity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboquantity.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboquantity.FormattingEnabled = True
		Me.cboquantity.Location = New System.Drawing.Point(317, 145)
		Me.cboquantity.Name = "cboquantity"
		Me.cboquantity.Size = New System.Drawing.Size(121, 30)
		Me.cboquantity.TabIndex = 5
		Me.cboquantity.Tag = "E"
		'
		'lblD
		'
		Me.lblD.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblD.BackColor = System.Drawing.Color.Firebrick
		Me.lblD.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblD.ForeColor = System.Drawing.Color.White
		Me.lblD.Location = New System.Drawing.Point(90, 113)
		Me.lblD.Name = "lblD"
		Me.lblD.Size = New System.Drawing.Size(11, 27)
		Me.lblD.TabIndex = 30
		Me.lblD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblproduction
		'
		Me.lblproduction.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblproduction.BackColor = System.Drawing.Color.Transparent
		Me.lblproduction.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblproduction.ForeColor = System.Drawing.Color.Lime
		Me.lblproduction.Location = New System.Drawing.Point(561, 80)
		Me.lblproduction.Name = "lblproduction"
		Me.lblproduction.Size = New System.Drawing.Size(362, 29)
		Me.lblproduction.TabIndex = 29
		Me.lblproduction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblL
		'
		Me.lblL.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblL.BackColor = System.Drawing.Color.Firebrick
		Me.lblL.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblL.ForeColor = System.Drawing.Color.White
		Me.lblL.Location = New System.Drawing.Point(90, 374)
		Me.lblL.Name = "lblL"
		Me.lblL.Size = New System.Drawing.Size(11, 28)
		Me.lblL.TabIndex = 26
		Me.lblL.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblJ
		'
		Me.lblJ.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblJ.BackColor = System.Drawing.Color.Firebrick
		Me.lblJ.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblJ.ForeColor = System.Drawing.Color.White
		Me.lblJ.Location = New System.Drawing.Point(90, 304)
		Me.lblJ.Name = "lblJ"
		Me.lblJ.Size = New System.Drawing.Size(11, 28)
		Me.lblJ.TabIndex = 26
		Me.lblJ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblK
		'
		Me.lblK.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblK.BackColor = System.Drawing.Color.Firebrick
		Me.lblK.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblK.ForeColor = System.Drawing.Color.White
		Me.lblK.Location = New System.Drawing.Point(90, 339)
		Me.lblK.Name = "lblK"
		Me.lblK.Size = New System.Drawing.Size(11, 28)
		Me.lblK.TabIndex = 26
		Me.lblK.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblH
		'
		Me.lblH.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblH.BackColor = System.Drawing.Color.Firebrick
		Me.lblH.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblH.ForeColor = System.Drawing.Color.White
		Me.lblH.Location = New System.Drawing.Point(90, 181)
		Me.lblH.Name = "lblH"
		Me.lblH.Size = New System.Drawing.Size(11, 28)
		Me.lblH.TabIndex = 26
		Me.lblH.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label15
		'
		Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label15.BackColor = System.Drawing.Color.DimGray
		Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label15.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label15.ForeColor = System.Drawing.Color.White
		Me.Label15.Location = New System.Drawing.Point(89, 373)
		Me.Label15.Name = "Label15"
		Me.Label15.Size = New System.Drawing.Size(227, 30)
		Me.Label15.TabIndex = 25
		Me.Label15.Tag = "G"
		Me.Label15.Text = "REMARKS :"
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label17
		'
		Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label17.BackColor = System.Drawing.Color.DimGray
		Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label17.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label17.ForeColor = System.Drawing.Color.White
		Me.Label17.Location = New System.Drawing.Point(89, 303)
		Me.Label17.Name = "Label17"
		Me.Label17.Size = New System.Drawing.Size(227, 30)
		Me.Label17.TabIndex = 25
		Me.Label17.Tag = "G"
		Me.Label17.Text = "EMPLOYEE :"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label3
		'
		Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label3.BackColor = System.Drawing.Color.DimGray
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label3.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label3.ForeColor = System.Drawing.Color.White
		Me.Label3.Location = New System.Drawing.Point(89, 338)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(227, 30)
		Me.Label3.TabIndex = 25
		Me.Label3.Tag = "G"
		Me.Label3.Text = "MANAGER :"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label14
		'
		Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label14.BackColor = System.Drawing.Color.DimGray
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label14.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label14.ForeColor = System.Drawing.Color.White
		Me.Label14.Location = New System.Drawing.Point(89, 180)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(227, 30)
		Me.Label14.TabIndex = 25
		Me.Label14.Tag = "G"
		Me.Label14.Text = "STORAGE :"
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'cboremarks
		'
		Me.cboremarks.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboremarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboremarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboremarks.DropDownHeight = 400
		Me.cboremarks.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboremarks.FormattingEnabled = True
		Me.cboremarks.IntegralHeight = False
		Me.cboremarks.Location = New System.Drawing.Point(317, 373)
		Me.cboremarks.Name = "cboremarks"
		Me.cboremarks.Size = New System.Drawing.Size(606, 30)
		Me.cboremarks.TabIndex = 12
		Me.cboremarks.Tag = "L"
		'
		'cboemployee
		'
		Me.cboemployee.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboemployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboemployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboemployee.DropDownHeight = 400
		Me.cboemployee.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboemployee.FormattingEnabled = True
		Me.cboemployee.IntegralHeight = False
		Me.cboemployee.Location = New System.Drawing.Point(317, 303)
		Me.cboemployee.Name = "cboemployee"
		Me.cboemployee.Size = New System.Drawing.Size(606, 30)
		Me.cboemployee.TabIndex = 10
		Me.cboemployee.Tag = "J"
		'
		'cbomanager
		'
		Me.cbomanager.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbomanager.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbomanager.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbomanager.DropDownHeight = 400
		Me.cbomanager.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbomanager.FormattingEnabled = True
		Me.cbomanager.IntegralHeight = False
		Me.cbomanager.Location = New System.Drawing.Point(317, 338)
		Me.cbomanager.Name = "cbomanager"
		Me.cbomanager.Size = New System.Drawing.Size(606, 30)
		Me.cbomanager.TabIndex = 11
		Me.cbomanager.Tag = "K"
		'
		'cbostorage
		'
		Me.cbostorage.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbostorage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbostorage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbostorage.DropDownHeight = 400
		Me.cbostorage.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbostorage.FormattingEnabled = True
		Me.cbostorage.IntegralHeight = False
		Me.cbostorage.Location = New System.Drawing.Point(317, 180)
		Me.cbostorage.Name = "cbostorage"
		Me.cbostorage.Size = New System.Drawing.Size(606, 30)
		Me.cbostorage.TabIndex = 8
		Me.cbostorage.Tag = "H"
		'
		'lblG
		'
		Me.lblG.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblG.BackColor = System.Drawing.Color.Firebrick
		Me.lblG.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblG.ForeColor = System.Drawing.Color.White
		Me.lblG.Location = New System.Drawing.Point(721, 146)
		Me.lblG.Name = "lblG"
		Me.lblG.Size = New System.Drawing.Size(11, 28)
		Me.lblG.TabIndex = 23
		Me.lblG.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label12
		'
		Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label12.BackColor = System.Drawing.Color.DimGray
		Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label12.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label12.ForeColor = System.Drawing.Color.White
		Me.Label12.Location = New System.Drawing.Point(720, 145)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(80, 30)
		Me.Label12.TabIndex = 22
		Me.Label12.Tag = "F"
		Me.Label12.Text = "UNIT :"
		Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'cbounit
		'
		Me.cbounit.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbounit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbounit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbounit.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbounit.FormattingEnabled = True
		Me.cbounit.Location = New System.Drawing.Point(801, 146)
		Me.cbounit.Name = "cbounit"
		Me.cbounit.Size = New System.Drawing.Size(122, 30)
		Me.cbounit.TabIndex = 7
		Me.cbounit.Tag = "G"
		'
		'lblE
		'
		Me.lblE.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblE.BackColor = System.Drawing.Color.Firebrick
		Me.lblE.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblE.ForeColor = System.Drawing.Color.White
		Me.lblE.Location = New System.Drawing.Point(90, 146)
		Me.lblE.Name = "lblE"
		Me.lblE.Size = New System.Drawing.Size(11, 28)
		Me.lblE.TabIndex = 20
		Me.lblE.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label2
		'
		Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label2.BackColor = System.Drawing.Color.DimGray
		Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label2.ForeColor = System.Drawing.Color.White
		Me.Label2.Location = New System.Drawing.Point(440, 145)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(131, 30)
		Me.Label2.TabIndex = 19
		Me.Label2.Tag = "E"
		Me.Label2.Text = "PROCESS :"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label10
		'
		Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label10.BackColor = System.Drawing.Color.DimGray
		Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label10.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label10.ForeColor = System.Drawing.Color.White
		Me.Label10.Location = New System.Drawing.Point(89, 145)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(227, 30)
		Me.Label10.TabIndex = 19
		Me.Label10.Tag = "E"
		Me.Label10.Text = "QUANTITY :"
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'cboprocess
		'
		Me.cboprocess.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboprocess.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboprocess.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboprocess.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboprocess.FormattingEnabled = True
		Me.cboprocess.Location = New System.Drawing.Point(572, 145)
		Me.cboprocess.Name = "cboprocess"
		Me.cboprocess.Size = New System.Drawing.Size(147, 30)
		Me.cboprocess.TabIndex = 6
		Me.cboprocess.Tag = "F"
		'
		'Label8
		'
		Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label8.BackColor = System.Drawing.Color.DimGray
		Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label8.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label8.ForeColor = System.Drawing.Color.White
		Me.Label8.Location = New System.Drawing.Point(89, 112)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(227, 29)
		Me.Label8.TabIndex = 17
		Me.Label8.Tag = "D"
		Me.Label8.Text = "SHELF LIFE :"
		Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblC
		'
		Me.lblC.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblC.BackColor = System.Drawing.Color.Firebrick
		Me.lblC.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblC.ForeColor = System.Drawing.Color.White
		Me.lblC.Location = New System.Drawing.Point(90, 81)
		Me.lblC.Name = "lblC"
		Me.lblC.Size = New System.Drawing.Size(11, 27)
		Me.lblC.TabIndex = 14
		Me.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblB
		'
		Me.lblB.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblB.BackColor = System.Drawing.Color.Firebrick
		Me.lblB.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblB.ForeColor = System.Drawing.Color.White
		Me.lblB.Location = New System.Drawing.Point(90, 48)
		Me.lblB.Name = "lblB"
		Me.lblB.Size = New System.Drawing.Size(11, 28)
		Me.lblB.TabIndex = 15
		Me.lblB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblA
		'
		Me.lblA.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblA.BackColor = System.Drawing.Color.Firebrick
		Me.lblA.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblA.ForeColor = System.Drawing.Color.White
		Me.lblA.Location = New System.Drawing.Point(90, 15)
		Me.lblA.Name = "lblA"
		Me.lblA.Size = New System.Drawing.Size(11, 28)
		Me.lblA.TabIndex = 16
		Me.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label5
		'
		Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label5.BackColor = System.Drawing.Color.DimGray
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label5.ForeColor = System.Drawing.Color.White
		Me.Label5.Location = New System.Drawing.Point(89, 80)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(227, 29)
		Me.Label5.TabIndex = 10
		Me.Label5.Tag = "C"
		Me.Label5.Text = "PRODUCTION DATE :"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label6
		'
		Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label6.BackColor = System.Drawing.Color.DimGray
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label6.ForeColor = System.Drawing.Color.White
		Me.Label6.Location = New System.Drawing.Point(89, 47)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(227, 30)
		Me.Label6.TabIndex = 11
		Me.Label6.Tag = "B"
		Me.Label6.Text = "CONDITION :"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label7
		'
		Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label7.BackColor = System.Drawing.Color.DimGray
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label7.ForeColor = System.Drawing.Color.White
		Me.Label7.Location = New System.Drawing.Point(89, 14)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(227, 30)
		Me.Label7.TabIndex = 12
		Me.Label7.Tag = "A"
		Me.Label7.Text = "ITEM :"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblusedBy
		'
		Me.lblusedBy.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblusedBy.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
		Me.lblusedBy.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblusedBy.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblusedBy.ForeColor = System.Drawing.Color.White
		Me.lblusedBy.Location = New System.Drawing.Point(317, 253)
		Me.lblusedBy.Name = "lblusedBy"
		Me.lblusedBy.Size = New System.Drawing.Size(606, 36)
		Me.lblusedBy.TabIndex = 17
		Me.lblusedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'dtTimeIn
		'
		Me.dtTimeIn.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.dtTimeIn.Checked = False
		Me.dtTimeIn.CustomFormat = "MM/dd/yyyy hh:mm:ss tt"
		Me.dtTimeIn.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.dtTimeIn.Format = System.Windows.Forms.DateTimePickerFormat.Custom
		Me.dtTimeIn.Location = New System.Drawing.Point(317, 220)
		Me.dtTimeIn.Name = "dtTimeIn"
		Me.dtTimeIn.Size = New System.Drawing.Size(297, 29)
		Me.dtTimeIn.TabIndex = 9
		Me.dtTimeIn.Tag = "I"
		'
		'dateProduction
		'
		Me.dateProduction.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.dateProduction.Checked = False
		Me.dateProduction.CustomFormat = "MM/dd/yyyy"
		Me.dateProduction.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.dateProduction.Format = System.Windows.Forms.DateTimePickerFormat.Custom
		Me.dateProduction.Location = New System.Drawing.Point(317, 80)
		Me.dateProduction.Name = "dateProduction"
		Me.dateProduction.ShowCheckBox = True
		Me.dateProduction.Size = New System.Drawing.Size(238, 29)
		Me.dateProduction.TabIndex = 2
		Me.dateProduction.Tag = "C"
		'
		'cbocondition
		'
		Me.cbocondition.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbocondition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbocondition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbocondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cbocondition.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbocondition.FormattingEnabled = True
		Me.cbocondition.Location = New System.Drawing.Point(317, 47)
		Me.cbocondition.Name = "cbocondition"
		Me.cbocondition.Size = New System.Drawing.Size(606, 30)
		Me.cbocondition.TabIndex = 1
		Me.cbocondition.Tag = "B"
		'
		'cboitems
		'
		Me.cboitems.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboitems.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboitems.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboitems.DropDownHeight = 400
		Me.cboitems.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboitems.FormattingEnabled = True
		Me.cboitems.IntegralHeight = False
		Me.cboitems.Location = New System.Drawing.Point(317, 14)
		Me.cboitems.Name = "cboitems"
		Me.cboitems.Size = New System.Drawing.Size(606, 30)
		Me.cboitems.TabIndex = 0
		Me.cboitems.Tag = "A"
		'
		'cboterm
		'
		Me.cboterm.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboterm.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboterm.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboterm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboterm.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboterm.FormattingEnabled = True
		Me.cboterm.Location = New System.Drawing.Point(586, 112)
		Me.cboterm.Name = "cboterm"
		Me.cboterm.Size = New System.Drawing.Size(336, 30)
		Me.cboterm.TabIndex = 4
		Me.cboterm.Tag = "D"
		'
		'lblterm
		'
		Me.lblterm.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblterm.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
		Me.lblterm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblterm.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblterm.ForeColor = System.Drawing.Color.White
		Me.lblterm.Location = New System.Drawing.Point(587, 112)
		Me.lblterm.Name = "lblterm"
		Me.lblterm.Size = New System.Drawing.Size(336, 29)
		Me.lblterm.TabIndex = 17
		Me.lblterm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'cbotenure
		'
		Me.cbotenure.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbotenure.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbotenure.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbotenure.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbotenure.FormattingEnabled = True
		Me.cbotenure.Location = New System.Drawing.Point(317, 112)
		Me.cbotenure.Name = "cbotenure"
		Me.cbotenure.Size = New System.Drawing.Size(267, 30)
		Me.cbotenure.TabIndex = 3
		Me.cbotenure.Tag = "D"
		'
		'picNew
		'
		Me.picNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
		Me.picNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.picNew.Image = CType(resources.GetObject("picNew.Image"), System.Drawing.Image)
		Me.picNew.Location = New System.Drawing.Point(6, 406)
		Me.picNew.Name = "picNew"
		Me.picNew.Size = New System.Drawing.Size(49, 43)
		Me.picNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picNew.TabIndex = 38
		Me.picNew.TabStop = False
		Me.picNew.Visible = False
		'
		'vw_3_labelInput
		'
		Me.AcceptButton = Me.btnsave
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.RoyalBlue
		Me.ClientSize = New System.Drawing.Size(948, 778)
		Me.Controls.Add(Me.pmain)
		Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_3_labelInput"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ITEM / PRODUCT MASTER"
		Me.pmain.ResumeLayout(False)
		Me.Panel1.ResumeLayout(False)
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
		Me.GroupBox1.ResumeLayout(False)
		CType(Me.picNew, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents cboitems As System.Windows.Forms.ComboBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents cbocondition As System.Windows.Forms.ComboBox
	Friend WithEvents dateProduction As System.Windows.Forms.DateTimePicker
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents lblC As System.Windows.Forms.Label
	Friend WithEvents lblB As System.Windows.Forms.Label
	Friend WithEvents lblA As System.Windows.Forms.Label
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents lblusedBy As System.Windows.Forms.Label
	Friend WithEvents lblterm As System.Windows.Forms.Label
	Friend WithEvents lblE As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents cboprocess As System.Windows.Forms.ComboBox
	Friend WithEvents lblG As System.Windows.Forms.Label
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents cbounit As System.Windows.Forms.ComboBox
	Friend WithEvents lblH As System.Windows.Forms.Label
	Friend WithEvents Label14 As System.Windows.Forms.Label
	Friend WithEvents cbostorage As System.Windows.Forms.ComboBox
	Friend WithEvents cboterm As System.Windows.Forms.ComboBox
	Friend WithEvents cbotenure As System.Windows.Forms.ComboBox
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents griditemList As System.Windows.Forms.DataGridView
	Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
	Friend WithEvents lblproduction As System.Windows.Forms.Label
	Friend WithEvents lblD As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents cboquantity As System.Windows.Forms.ComboBox
	Friend WithEvents lblF As System.Windows.Forms.Label
	Friend WithEvents lblI As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents dtTimeIn As System.Windows.Forms.DateTimePicker
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents lblL As System.Windows.Forms.Label
	Friend WithEvents lblJ As System.Windows.Forms.Label
	Friend WithEvents lblK As System.Windows.Forms.Label
	Friend WithEvents Label15 As System.Windows.Forms.Label
	Friend WithEvents Label17 As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents cboremarks As System.Windows.Forms.ComboBox
	Friend WithEvents cboemployee As System.Windows.Forms.ComboBox
	Friend WithEvents cbomanager As System.Windows.Forms.ComboBox
	Friend WithEvents lbldays As System.Windows.Forms.Label
	Friend WithEvents btnsave As Button
	Friend WithEvents btnsavePrint As System.Windows.Forms.Button
	Friend WithEvents picNew As System.Windows.Forms.PictureBox
	Friend WithEvents lblvalidity As System.Windows.Forms.Label
End Class
