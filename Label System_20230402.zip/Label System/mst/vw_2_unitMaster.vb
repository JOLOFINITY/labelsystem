﻿Imports System.Runtime.InteropServices
Public Class vw_2_unitMaster
#Region "MOVING"
    Public Const WM_NCLBUTTONDOWN As Integer = 161
    Public Const HT_CAPTION As Integer = 2

    <DllImportAttribute("User32.dll")> _
    Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
    End Function
    <DllImportAttribute("User32.dll")> _
    Public Shared Function ReleaseCapture() As Boolean
    End Function

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown, lblheader.MouseDown, lblheaderSub.MouseDown, lblbuildNo.MouseDown
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
        End If
    End Sub

    Private Const SM_CXSCREEN As Integer = 0
    Private Const SM_CYSCREEN As Integer = 1
    Private Shared HWND_TOP As IntPtr = IntPtr.Zero
    Private Const SWP_SHOWWINDOW As Integer = 64

    Private winState As FormWindowState
    Private brdStyle As FormBorderStyle
    Private isTopMost As Boolean
    Private isBounds As Rectangle

    <DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
    Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

    End Function
    <DllImport("user32.dll")>
    Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

    End Sub
    Public Shared ReadOnly Property ScreenX As Integer
        Get
            Return GetSystemMetrics(SM_CXSCREEN)
        End Get
    End Property

    Public Shared ReadOnly Property ScreenY As Integer
        Get
            Return GetSystemMetrics(SM_CYSCREEN)
        End Get
    End Property

    Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
        SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
    End Sub

    Private IsMaximized As Boolean = False
    Public Sub Maximize(ByVal targetForm As Form)
        If Not IsMaximized Then
            IsMaximized = True
            Save(targetForm)
            targetForm.WindowState = FormWindowState.Maximized
            targetForm.FormBorderStyle = FormBorderStyle.None
            targetForm.TopMost = True
            SetWinFullScreen(targetForm.Handle)
        End If
    End Sub
    Public Sub Save(ByVal targetForm As Form)
        winState = targetForm.WindowState
        brdStyle = targetForm.FormBorderStyle
        isTopMost = targetForm.TopMost
        isBounds = targetForm.Bounds
    End Sub
    Public Sub Restore(ByVal targetForm As Form)
        targetForm.WindowState = winState
        targetForm.FormBorderStyle = brdStyle
        targetForm.TopMost = isTopMost
        targetForm.Bounds = isBounds
        IsMaximized = False
    End Sub

    Private Sub me_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        If WindowState = FormWindowState.Maximized Then
            Maximize(Me)
        Else
            'Restore(Me)
            If llblmaximized.Text = "☒" Then
                llblmaximized.Text = "☐"
            End If
        End If
    End Sub
    Private Sub lblclose_MouseEnter(sender As Object, e As EventArgs) Handles lblclose.MouseEnter, llblmaximized.MouseEnter
        Dim llbl As LinkLabel = sender

        llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size + 2, FontStyle.Bold)
    End Sub

    Private Sub lblclose_MouseLeave(sender As Object, e As EventArgs) Handles lblclose.MouseLeave, llblmaximized.MouseLeave
        Dim llbl As LinkLabel = sender

        llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size - 2, FontStyle.Regular)
    End Sub

    Private Sub llblmaximized_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblmaximized.LinkClicked
        If llblmaximized.Text = "☐" Then
            llblmaximized.Text = "☒"
            WindowState = FormWindowState.Maximized
            Maximize(Me)
        Else
            llblmaximized.Text = "☐"
            WindowState = FormWindowState.Normal
            'Restore(Me)
        End If

        griditemList.Columns(1).Width = griditemList.Width - 120
    End Sub
    Private Sub lblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblclose.LinkClicked
        Dispose()
    End Sub
    Private Sub llblhide_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblhide.LinkClicked
        WindowState = FormWindowState.Minimized
    End Sub
#End Region
    Private resultUnitMst As New DataTable("result")

    Dim suggestions As New AutoCompleteStringCollection
    Private Sub txtproductName_TextChanged(sender As Object, e As EventArgs) Handles txtprocessUnit.TextChanged
        If txtprocessUnit.BackColor = Color.LightPink Then txtprocessUnit.BackColor = Color.White
        label_textCounter.Text = txtprocessUnit.TextLength & " / " & txtprocessUnit.MaxLength

    End Sub

    Private mst_productList As New DataTable
    Private Sub inList()
        resultUnitMst = tableUnitMaster()
        With griditemList
            .DataSource = resultUnitMst
            .ClearSelection()

            .Columns(1).Width = .Width - 120
            .Columns(2).Width = 0
        End With

        txtprocessUnit.Clear() : txtprocessUnit.Focus()
    End Sub
    Private Sub vw_1_productMaster_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        Call inList()
    End Sub
    Private Sub grid_itemList_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellDoubleClick
        txtprocessUnit.Text = griditemList.Rows(e.RowIndex).Cells(1).Value
        txtprocessUnit.Focus()
        txtprocessUnit.SelectionStart = txtprocessUnit.TextLength
    End Sub

    Private Sub llblrefresh_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblrefresh.LinkClicked
        Call inList()
    End Sub

    Private Sub llbladdSave_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbladdSave.LinkClicked
        If txtprocessUnit.TextLength <= 2 Then
            txtprocessUnit.BackColor = Color.LightPink
            txtprocessUnit.SelectAll()
        Else
            If check_processUnitExist(txtprocessUnit.Text) Then
                MessageBox.Show("Process/Unit already exist, please check the list to see record.", "Already Exist.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtprocessUnit.Focus()
            Else
                Call addProcessUnit(txtprocessUnit.Text)

                txtprocessUnit.Clear()

                Call inList()
            End If
        End If

        txtprocessUnit.Focus()
    End Sub

    Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
        If e.RowIndex >= 0 And e.ColumnIndex = 0 Then
            If griditemList.Rows(e.RowIndex).Cells(1).Value = "N/A" Then
            ElseIf MessageBox.Show( _
                "Warning : " & vbNewLine & vbNewLine & "You're about to Delete the following Process/Unit." & vbNewLine & vbNewLine & _
                "Process/Unit Name : " & griditemList.Rows(e.RowIndex).Cells(1).Value & " [" & griditemList.Rows(e.RowIndex).Cells(2).Value & "] " & vbNewLine & vbNewLine & _
                "Select [YES] to DELETE , [NO] to Cancel.", "User Input.", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                Call removeProcessUnit(griditemList.Rows(e.RowIndex).Cells(2).Value)

                txtprocessUnit.Clear()

                Call inList()
            End If
        End If
    End Sub
End Class