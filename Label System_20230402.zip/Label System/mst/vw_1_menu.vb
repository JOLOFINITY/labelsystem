﻿Imports System.Runtime.InteropServices
Public Class vw_1_menu
#Region "MOVING"
    Public Const WM_NCLBUTTONDOWN As Integer = 161
    Public Const HT_CAPTION As Integer = 2

    <DllImportAttribute("User32.dll")>
    Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
    End Function
    <DllImportAttribute("User32.dll")>
    Public Shared Function ReleaseCapture() As Boolean
    End Function

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown, lblheader.MouseDown, lblheaderSub.MouseDown
        If e.Button = MouseButtons.Left Then
            ReleaseCapture()
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
        End If
    End Sub

    Private Const SM_CXSCREEN As Integer = 0
    Private Const SM_CYSCREEN As Integer = 1
    Private Shared HWND_TOP As IntPtr = IntPtr.Zero
    Private Const SWP_SHOWWINDOW As Integer = 64

    Private winState As FormWindowState
    Private brdStyle As FormBorderStyle
    Private isTopMost As Boolean
    Private isBounds As Rectangle

    <DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
    Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

    End Function
    <DllImport("user32.dll")>
    Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

    End Sub
    Public Shared ReadOnly Property ScreenX As Integer
        Get
            Return GetSystemMetrics(SM_CXSCREEN)
        End Get
    End Property

    Public Shared ReadOnly Property ScreenY As Integer
        Get
            Return GetSystemMetrics(SM_CYSCREEN)
        End Get
    End Property

    Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
        SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
    End Sub

    Private IsMaximized As Boolean = False
    Public Sub Maximize(ByVal targetForm As Form)
        If Not IsMaximized Then
            IsMaximized = True
            Save(targetForm)
            targetForm.WindowState = FormWindowState.Maximized
            targetForm.FormBorderStyle = FormBorderStyle.None
            targetForm.TopMost = True
            SetWinFullScreen(targetForm.Handle)
        End If
    End Sub
    Public Sub Save(ByVal targetForm As Form)
        winState = targetForm.WindowState
        brdStyle = targetForm.FormBorderStyle
        isTopMost = targetForm.TopMost
        isBounds = targetForm.Bounds
    End Sub
    Public Sub Restore(ByVal targetForm As Form)
        targetForm.WindowState = winState
        targetForm.FormBorderStyle = brdStyle
        targetForm.TopMost = isTopMost
        targetForm.Bounds = isBounds
        IsMaximized = False
    End Sub

    Private Sub me_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        If WindowState = FormWindowState.Maximized Then
            'Maximize(Me)
        Else
            'Restore(Me)
            If llblmaximized.Text = "☒" Then
                llblmaximized.Text = "☐"
            End If
        End If

        If child.IsHandleCreated Then
            child.Size = pController.Size
        End If
    End Sub
    Private Sub lblclose_MouseEnter(sender As Object, e As EventArgs) Handles lblclose.MouseEnter, llblmaximized.MouseEnter
        Dim llbl As LinkLabel = sender

        llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size + 2, FontStyle.Bold)
    End Sub

    Private Sub lblclose_MouseLeave(sender As Object, e As EventArgs) Handles lblclose.MouseLeave, llblmaximized.MouseLeave
        Dim llbl As LinkLabel = sender

        llbl.Font = New Font(llbl.Font.Name, llbl.Font.Size - 2, FontStyle.Regular)
    End Sub

    Private Sub llblmaximized_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblmaximized.LinkClicked
        If llblmaximized.Text = "☐" Then
            llblmaximized.Text = "☒"
            WindowState = FormWindowState.Maximized
        Else
            llblmaximized.Text = "☐"
            WindowState = FormWindowState.Normal
        End If
    End Sub
    Private Sub lblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lblclose.LinkClicked
        If child.IsHandleCreated Then
            lblheader.Text = lblheader.Tag

            If child.Name = vw_2_loginPIN.Name Then
                Dispose()
            Else
                child.Close()
                child.Dispose()

                panelMenu.Visible = True
            End If
        Else
            showForm(New vw_2_loginPIN, True)
        End If
    End Sub
    Private Sub llblhide_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblhide.LinkClicked
        WindowState = FormWindowState.Minimized
    End Sub
#End Region
    Private child As New Form
    Private Sub showForm(ByRef frm As Form, Optional ByRef zoom As Boolean = True)
recon:
        If boolConnected Then
            If child.IsHandleCreated Then
                child.Dispose()

                lblheader.Text = lblheader.Tag
            End If

            With pController
                If panelMenu.Visible Then panelMenu.Visible = False

                child = frm
                child.TopLevel = False
                If zoom Then child.Size = .Size
                .Controls.Add(child)
                child.Show()

                child.Top = .Height / 2 - child.Height / 2
                child.Left = .Width / 2 - child.Width / 2
            End With
        Else
            If MessageBox.Show(
                "Server connection error, Please check your network or Server." & vbNewLine &
                "* Make sure you are connected in same LAN/Network." & vbNewLine & vbNewLine &
                "••TEST AND RECONNECT TO SERVER?...", "Access Denied.", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation) = Windows.Forms.DialogResult.Retry Then

                Call _connectDB()

                GoTo recon
            End If
        End If
    End Sub
    Private Sub cmsettings_Click(sender As Object, e As EventArgs) Handles btnsetting.Click
        showForm(New vw_9_settings)
    End Sub

    Private Sub cmlabelEntry_Click(sender As Object, e As EventArgs) Handles btnlabelPrinting.Click
        DTPickerLocalDateTime.Value = DateTime.Now

        showForm(New vw_3_labelInput2)
    End Sub
    Private Sub cmlabelHistory_Click(sender As Object, e As EventArgs) Handles btnlabelHistory.Click
        showForm(New vw_3_labelHistory)
    End Sub

    Private Sub cmitemMst_Click(sender As Object, e As EventArgs) Handles btnitemMain.Click
        showForm(New vw_3_itemMaster)
    End Sub

    Private wbrowser As New WebBrowser
    Private Sub vw_0_menu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call initREPORT()

        llblmaximized.Text = "☒"
        WindowState = FormWindowState.Maximized
        'Maximize(Me)

        lblheader.Text = lblheader.Tag : lblheaderSub.Text = lblheaderSub.Tag

        Call _connectDB()

        applicationIdle.IdleTime = My.Settings.CloseTime
        applicationIdle.WarnTime = My.Settings.WarningTime

        If boolConnected Then
            lblstatus.Text = "SERVER CONNECTION : " & publicIPAdd()
            lblstatus.ForeColor = Color.Green
        Else
            lblstatus.Text = "SERVER STATUS : DISCONNECTED"
            lblstatus.ForeColor = Color.Red
        End If

        showForm(New vw_2_loginPIN, True)
    End Sub
    Private Sub getDateTime_Tick(sender As Object, e As EventArgs) Handles getDateTime.Tick
        getDateTime.Stop()

        lbldatetime.Text = "TODAY : " & DateAndTime.Now.ToString("MM/dd/yyyy hh:mm:ss tt ( dddd )").ToUpper

        If LabelLocalDateTime.Visible Then
            DTPickerLocalDateTime.Value = DTPickerLocalDateTime.Value.AddSeconds(1)

            LabelLocalDateTime.Text = DTPickerLocalDateTime.Value.ToString("  yyyy - MM - dd    hh : mm : ss  tt")
        End If

        getDateTime.Start()
    End Sub

#Region "menus"
    Sub disabled()
        login_username = String.Empty

        panelMenu.Visible = False

        showForm(New vw_2_loginPIN, True)
    End Sub
    Sub menu_admin()
        btnsetting.Enabled = True
        btnlabelPrinting.Enabled = True
        btnlabelHistory.Enabled = True
        btnitemMain.Enabled = True

        panelMenu.Visible = True
    End Sub
#End Region
    Private Sub btnitemMain_MouseEnter(sender As Object, e As EventArgs) Handles btnsetting.MouseEnter, btnlabelPrinting.MouseEnter, btnlabelHistory.MouseEnter, btnitemMain.MouseEnter
        Dim btn As Button = sender

        btn.ForeColor = Color.Pink
    End Sub

    Private Sub btnitemMain_MouseLeave(sender As Object, e As EventArgs) Handles btnsetting.MouseLeave, btnlabelPrinting.MouseLeave, btnlabelHistory.MouseLeave, btnitemMain.MouseLeave
        Dim btn As Button = sender

        btn.ForeColor = Color.Yellow
    End Sub

    Private warnColour As Color = Color.Red
    Private normalColour As Color = Color.FromKnownColor(KnownColor.ControlText)
    Private Sub UpdateTimeDisplays(ByVal remainingForeColor As Color)
        Try
            lblRemaining.ForeColor = remainingForeColor
            lblRemaining.Text = applicationIdle.TimeRemaining.ToString()
            lblElapsed.Text = applicationIdle.TimeElapsed.ToString()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub applicationIdle_Activity(sender As Object, e As Winforms.Components.ApplicationIdleData.ActivityEventArgs) Handles applicationIdle.Activity
        lblActivity.Text = e.Message.ToString()
        UpdateTimeDisplays(normalColour)
    End Sub
    Private Sub applicationIdle_Started(sender As Object, e As EventArgs) Handles applicationIdle.Started
        UpdateTimeDisplays(normalColour)
    End Sub
    Private Sub applicationIdle_TickAsync(sender As Object, e As Winforms.Components.ApplicationIdleData.TickEventArgs) Handles applicationIdle.TickAsync
        'BeginInvoke(new MethodInvoker(AddressOf                delegate() { applicationIdle_Tick(sender, e); })
        '              );
        applicationIdle_Tick(sender, e)
    End Sub
    Private Sub applicationIdle_Tick(sender As Object, e As Winforms.Components.ApplicationIdleData.TickEventArgs) Handles applicationIdle.Tick
        If e.IsWarnPeriod Then
            UpdateTimeDisplays(warnColour)
        Else
            UpdateTimeDisplays(normalColour)
        End If
    End Sub

    Private Sub applicationIdle_Stopped(sender As Object, e As EventArgs) Handles applicationIdle.Stopped
        'Call log_User("LOGOUT", login_username)
        'Call disabled()
    End Sub

    Private Sub applicationIdle_WarnAsync(sender As Object, e As EventArgs) Handles applicationIdle.WarnAsync
        Console.Beep()
    End Sub
    Private Sub applicationIdle_Idle(sender As Object, e As EventArgs) Handles applicationIdle.Idle
        Call log_User("LOGOUT", login_username)
        Call disabled()
    End Sub

    Private Sub ButtonSetLocalDT_Click(sender As Object, e As EventArgs) Handles ButtonSetLocalDT.Click
        If ButtonSetLocalDT.Text = "SET TIME" Then
            ButtonSetLocalDT.Text = "SAVE"

            LabelLocalDateTime.Visible = False
            DTPickerLocalDateTime.Visible = True
            DTPickerLocalDateTime.Focus()
        Else
            ButtonSetLocalDT.Text = "SET TIME"

            DTPickerLocalDateTime.Visible = False
            LabelLocalDateTime.Visible = True
        End If
    End Sub
End Class