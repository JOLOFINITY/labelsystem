﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_labelInput2
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_3_labelInput2))
        Me.pmain = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.griditemList = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.paperOut = New System.Windows.Forms.Panel()
        Me.lblpreview_days = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblpreview_PM = New System.Windows.Forms.Label()
        Me.lblpreview_remarks = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblpreview_AM = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.lblpreview_manager = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.lblpreview_usedBy = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.lblpreview_employeeName = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.lblpreview_timeIN = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.lblpreview_shelftLife = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.lblpreview_quantityUnit = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lblpreview_productionDate = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.lblpreview_itemName = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblquantity = New System.Windows.Forms.Label()
        Me.btnquantity = New System.Windows.Forms.Button()
        Me.btnTIMEIN = New System.Windows.Forms.Button()
        Me.cbprodDate = New System.Windows.Forms.CheckBox()
        Me.btndate = New System.Windows.Forms.Button()
        Me.btnsavePrint = New System.Windows.Forms.Button()
        Me.btnsave = New System.Windows.Forms.Button()
        Me.lblshelflife = New System.Windows.Forms.Label()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblshelflifeBy = New System.Windows.Forms.Label()
        Me.lbldays = New System.Windows.Forms.Label()
        Me.lblproductionDefault = New System.Windows.Forms.Label()
        Me.cboremarks = New Label_System.modComboBox()
        Me.cboemployee = New Label_System.modComboBox()
        Me.cbomanager = New Label_System.modComboBox()
        Me.lblusedBy = New System.Windows.Forms.Label()
        Me.cbocondition = New Label_System.modComboBox()
        Me.cboitems = New Label_System.modComboBox()
        Me.lblA = New System.Windows.Forms.Label()
        Me.lblB = New System.Windows.Forms.Label()
        Me.lblstorage = New System.Windows.Forms.Label()
        Me.lblJ = New System.Windows.Forms.Label()
        Me.lblI = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblG = New System.Windows.Forms.Label()
        Me.lblF = New System.Windows.Forms.Label()
        Me.lblH = New System.Windows.Forms.Label()
        Me.lblcurDate = New System.Windows.Forms.Label()
        Me.lblunit = New System.Windows.Forms.Label()
        Me.lblE = New System.Windows.Forms.Label()
        Me.lblD = New System.Windows.Forms.Label()
        Me.dateProduction = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblC = New System.Windows.Forms.Label()
        Me.setPreview = New System.Windows.Forms.Timer(Me.components)
        Me.tfocus = New System.Windows.Forms.Timer(Me.components)
        Me.lblTimeIn = New System.Windows.Forms.Label()
        Me.pmain.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.paperOut.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.Panel1)
        Me.pmain.Controls.Add(Me.paperOut)
        Me.pmain.Controls.Add(Me.GroupBox1)
        Me.pmain.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.pmain.Location = New System.Drawing.Point(2, 2)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(1280, 790)
        Me.pmain.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Panel1.Controls.Add(Me.griditemList)
        Me.Panel1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.Location = New System.Drawing.Point(681, 195)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(596, 225)
        Me.Panel1.TabIndex = 15
        '
        'griditemList
        '
        Me.griditemList.AllowUserToAddRows = False
        Me.griditemList.AllowUserToDeleteRows = False
        Me.griditemList.AllowUserToResizeColumns = False
        Me.griditemList.AllowUserToResizeRows = False
        Me.griditemList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.griditemList.BackgroundColor = System.Drawing.Color.White
        Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
        Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.griditemList.ColumnHeadersHeight = 36
        Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.griditemList.DefaultCellStyle = DataGridViewCellStyle2
        Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.griditemList.EnableHeadersVisualStyles = False
        Me.griditemList.Location = New System.Drawing.Point(0, 0)
        Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
        Me.griditemList.MultiSelect = False
        Me.griditemList.Name = "griditemList"
        Me.griditemList.ReadOnly = True
        Me.griditemList.RowHeadersVisible = False
        Me.griditemList.RowTemplate.Height = 28
        Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.griditemList.ShowCellErrors = False
        Me.griditemList.ShowCellToolTips = False
        Me.griditemList.ShowEditingIcon = False
        Me.griditemList.ShowRowErrors = False
        Me.griditemList.Size = New System.Drawing.Size(596, 225)
        Me.griditemList.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Select"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Visible = False
        '
        'paperOut
        '
        Me.paperOut.BackColor = System.Drawing.Color.White
        Me.paperOut.Controls.Add(Me.lblpreview_days)
        Me.paperOut.Controls.Add(Me.Label19)
        Me.paperOut.Controls.Add(Me.lblpreview_PM)
        Me.paperOut.Controls.Add(Me.lblpreview_remarks)
        Me.paperOut.Controls.Add(Me.Label16)
        Me.paperOut.Controls.Add(Me.lblpreview_AM)
        Me.paperOut.Controls.Add(Me.Label32)
        Me.paperOut.Controls.Add(Me.lblpreview_manager)
        Me.paperOut.Controls.Add(Me.Label30)
        Me.paperOut.Controls.Add(Me.lblpreview_usedBy)
        Me.paperOut.Controls.Add(Me.Label28)
        Me.paperOut.Controls.Add(Me.lblpreview_employeeName)
        Me.paperOut.Controls.Add(Me.Label26)
        Me.paperOut.Controls.Add(Me.lblpreview_timeIN)
        Me.paperOut.Controls.Add(Me.Label24)
        Me.paperOut.Controls.Add(Me.lblpreview_shelftLife)
        Me.paperOut.Controls.Add(Me.Label22)
        Me.paperOut.Controls.Add(Me.lblpreview_quantityUnit)
        Me.paperOut.Controls.Add(Me.Label20)
        Me.paperOut.Controls.Add(Me.lblpreview_productionDate)
        Me.paperOut.Controls.Add(Me.Label18)
        Me.paperOut.Controls.Add(Me.lblpreview_itemName)
        Me.paperOut.Controls.Add(Me.Label12)
        Me.paperOut.Controls.Add(Me.Label33)
        Me.paperOut.Controls.Add(Me.Label34)
        Me.paperOut.Controls.Add(Me.Label35)
        Me.paperOut.Controls.Add(Me.Label36)
        Me.paperOut.Controls.Add(Me.Label37)
        Me.paperOut.Controls.Add(Me.Label38)
        Me.paperOut.Controls.Add(Me.Label39)
        Me.paperOut.Controls.Add(Me.Label40)
        Me.paperOut.Controls.Add(Me.Label41)
        Me.paperOut.Location = New System.Drawing.Point(680, 3)
        Me.paperOut.Name = "paperOut"
        Me.paperOut.Size = New System.Drawing.Size(604, 188)
        Me.paperOut.TabIndex = 10
        '
        'lblpreview_days
        '
        Me.lblpreview_days.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_days.Location = New System.Drawing.Point(1, 4)
        Me.lblpreview_days.Name = "lblpreview_days"
        Me.lblpreview_days.Size = New System.Drawing.Size(38, 180)
        Me.lblpreview_days.TabIndex = 0
        Me.lblpreview_days.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(343, 108)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 24)
        Me.Label19.TabIndex = 44
        Me.Label19.Tag = "£"
        Me.Label19.Text = "PM"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblpreview_PM
        '
        Me.lblpreview_PM.Font = New System.Drawing.Font("Wingdings 2", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblpreview_PM.Location = New System.Drawing.Point(319, 108)
        Me.lblpreview_PM.Name = "lblpreview_PM"
        Me.lblpreview_PM.Size = New System.Drawing.Size(24, 24)
        Me.lblpreview_PM.TabIndex = 44
        Me.lblpreview_PM.Tag = "£"
        Me.lblpreview_PM.Text = "£"
        Me.lblpreview_PM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblpreview_remarks
        '
        Me.lblpreview_remarks.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_remarks.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_remarks.Location = New System.Drawing.Point(130, 160)
        Me.lblpreview_remarks.Name = "lblpreview_remarks"
        Me.lblpreview_remarks.Size = New System.Drawing.Size(467, 23)
        Me.lblpreview_remarks.TabIndex = 16
        Me.lblpreview_remarks.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(288, 108)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(31, 24)
        Me.Label16.TabIndex = 27
        Me.Label16.Tag = "R"
        Me.Label16.Text = "AM"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblpreview_AM
        '
        Me.lblpreview_AM.Font = New System.Drawing.Font("Wingdings 2", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblpreview_AM.Location = New System.Drawing.Point(264, 108)
        Me.lblpreview_AM.Name = "lblpreview_AM"
        Me.lblpreview_AM.Size = New System.Drawing.Size(24, 24)
        Me.lblpreview_AM.TabIndex = 27
        Me.lblpreview_AM.Tag = "R"
        Me.lblpreview_AM.Text = "R"
        Me.lblpreview_AM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label32
        '
        Me.Label32.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label32.Location = New System.Drawing.Point(40, 160)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(90, 23)
        Me.Label32.TabIndex = 17
        Me.Label32.Text = "REMARKS :"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_manager
        '
        Me.lblpreview_manager.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_manager.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_manager.Location = New System.Drawing.Point(130, 134)
        Me.lblpreview_manager.Name = "lblpreview_manager"
        Me.lblpreview_manager.Size = New System.Drawing.Size(467, 23)
        Me.lblpreview_manager.TabIndex = 14
        Me.lblpreview_manager.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label30
        '
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label30.Location = New System.Drawing.Point(40, 134)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(90, 23)
        Me.Label30.TabIndex = 15
        Me.Label30.Text = "MANAGER :"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_usedBy
        '
        Me.lblpreview_usedBy.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_usedBy.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_usedBy.Location = New System.Drawing.Point(462, 108)
        Me.lblpreview_usedBy.Name = "lblpreview_usedBy"
        Me.lblpreview_usedBy.Size = New System.Drawing.Size(135, 23)
        Me.lblpreview_usedBy.TabIndex = 12
        Me.lblpreview_usedBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(378, 108)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(84, 23)
        Me.Label28.TabIndex = 13
        Me.Label28.Text = "USED BY :"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_employeeName
        '
        Me.lblpreview_employeeName.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_employeeName.Location = New System.Drawing.Point(130, 108)
        Me.lblpreview_employeeName.Name = "lblpreview_employeeName"
        Me.lblpreview_employeeName.Size = New System.Drawing.Size(133, 23)
        Me.lblpreview_employeeName.TabIndex = 10
        Me.lblpreview_employeeName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label26
        '
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label26.Location = New System.Drawing.Point(40, 108)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(90, 23)
        Me.Label26.TabIndex = 11
        Me.Label26.Text = "EMPLOYEE :"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_timeIN
        '
        Me.lblpreview_timeIN.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_timeIN.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_timeIN.Location = New System.Drawing.Point(130, 82)
        Me.lblpreview_timeIN.Name = "lblpreview_timeIN"
        Me.lblpreview_timeIN.Size = New System.Drawing.Size(467, 23)
        Me.lblpreview_timeIN.TabIndex = 8
        Me.lblpreview_timeIN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label24.Location = New System.Drawing.Point(40, 82)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(90, 23)
        Me.Label24.TabIndex = 9
        Me.Label24.Text = "TIME-IN :"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_shelftLife
        '
        Me.lblpreview_shelftLife.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_shelftLife.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_shelftLife.Location = New System.Drawing.Point(130, 56)
        Me.lblpreview_shelftLife.Name = "lblpreview_shelftLife"
        Me.lblpreview_shelftLife.Size = New System.Drawing.Size(467, 23)
        Me.lblpreview_shelftLife.TabIndex = 6
        Me.lblpreview_shelftLife.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label22
        '
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label22.Location = New System.Drawing.Point(40, 56)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(90, 23)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "SHELFLIFE :"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_quantityUnit
        '
        Me.lblpreview_quantityUnit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_quantityUnit.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_quantityUnit.Location = New System.Drawing.Point(399, 30)
        Me.lblpreview_quantityUnit.Name = "lblpreview_quantityUnit"
        Me.lblpreview_quantityUnit.Size = New System.Drawing.Size(198, 23)
        Me.lblpreview_quantityUnit.TabIndex = 4
        Me.lblpreview_quantityUnit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(303, 30)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(96, 23)
        Me.Label20.TabIndex = 5
        Me.Label20.Text = "QTY :"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblpreview_productionDate
        '
        Me.lblpreview_productionDate.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_productionDate.Location = New System.Drawing.Point(130, 30)
        Me.lblpreview_productionDate.Name = "lblpreview_productionDate"
        Me.lblpreview_productionDate.Size = New System.Drawing.Size(172, 23)
        Me.lblpreview_productionDate.TabIndex = 2
        Me.lblpreview_productionDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label18.Location = New System.Drawing.Point(40, 30)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(90, 23)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "DATE :"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblpreview_itemName
        '
        Me.lblpreview_itemName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblpreview_itemName.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpreview_itemName.Location = New System.Drawing.Point(130, 4)
        Me.lblpreview_itemName.Name = "lblpreview_itemName"
        Me.lblpreview_itemName.Size = New System.Drawing.Size(467, 23)
        Me.lblpreview_itemName.TabIndex = 1
        Me.lblpreview_itemName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold)
        Me.Label12.Location = New System.Drawing.Point(40, 4)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 23)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "ITEM :"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label33
        '
        Me.Label33.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label33.BackColor = System.Drawing.Color.Black
        Me.Label33.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(130, 161)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(467, 23)
        Me.Label33.TabIndex = 26
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label34
        '
        Me.Label34.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label34.BackColor = System.Drawing.Color.Black
        Me.Label34.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(130, 135)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(467, 23)
        Me.Label34.TabIndex = 25
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label35.BackColor = System.Drawing.Color.Black
        Me.Label35.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(462, 109)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(135, 23)
        Me.Label35.TabIndex = 24
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Black
        Me.Label36.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(130, 109)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(133, 23)
        Me.Label36.TabIndex = 23
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label37
        '
        Me.Label37.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label37.BackColor = System.Drawing.Color.Black
        Me.Label37.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(130, 83)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(467, 23)
        Me.Label37.TabIndex = 22
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label38
        '
        Me.Label38.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label38.BackColor = System.Drawing.Color.Black
        Me.Label38.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(130, 57)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(467, 23)
        Me.Label38.TabIndex = 21
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label39
        '
        Me.Label39.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label39.BackColor = System.Drawing.Color.Black
        Me.Label39.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(399, 31)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(198, 23)
        Me.Label39.TabIndex = 20
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.Black
        Me.Label40.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.Location = New System.Drawing.Point(130, 31)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(172, 23)
        Me.Label40.TabIndex = 19
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label41.BackColor = System.Drawing.Color.Black
        Me.Label41.Font = New System.Drawing.Font("Arial Narrow", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.Location = New System.Drawing.Point(130, 5)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(467, 23)
        Me.Label41.TabIndex = 18
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox1
        '
        Me.GroupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.lblTimeIn)
        Me.GroupBox1.Controls.Add(Me.lblquantity)
        Me.GroupBox1.Controls.Add(Me.cbprodDate)
        Me.GroupBox1.Controls.Add(Me.btndate)
        Me.GroupBox1.Controls.Add(Me.btnsavePrint)
        Me.GroupBox1.Controls.Add(Me.btnsave)
        Me.GroupBox1.Controls.Add(Me.lblshelflife)
        Me.GroupBox1.Controls.Add(Me.btnclear)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.lblshelflifeBy)
        Me.GroupBox1.Controls.Add(Me.lbldays)
        Me.GroupBox1.Controls.Add(Me.lblproductionDefault)
        Me.GroupBox1.Controls.Add(Me.cboremarks)
        Me.GroupBox1.Controls.Add(Me.cboemployee)
        Me.GroupBox1.Controls.Add(Me.cbomanager)
        Me.GroupBox1.Controls.Add(Me.lblusedBy)
        Me.GroupBox1.Controls.Add(Me.cbocondition)
        Me.GroupBox1.Controls.Add(Me.cboitems)
        Me.GroupBox1.Controls.Add(Me.lblA)
        Me.GroupBox1.Controls.Add(Me.lblB)
        Me.GroupBox1.Controls.Add(Me.lblstorage)
        Me.GroupBox1.Controls.Add(Me.lblJ)
        Me.GroupBox1.Controls.Add(Me.lblI)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.lblG)
        Me.GroupBox1.Controls.Add(Me.lblF)
        Me.GroupBox1.Controls.Add(Me.lblH)
        Me.GroupBox1.Controls.Add(Me.lblcurDate)
        Me.GroupBox1.Controls.Add(Me.lblunit)
        Me.GroupBox1.Controls.Add(Me.dateProduction)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.lblC)
        Me.GroupBox1.Controls.Add(Me.btnTIMEIN)
        Me.GroupBox1.Controls.Add(Me.lblD)
        Me.GroupBox1.Controls.Add(Me.btnquantity)
        Me.GroupBox1.Controls.Add(Me.lblE)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 1.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(5, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(674, 417)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'lblquantity
        '
        Me.lblquantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblquantity.BackColor = System.Drawing.Color.White
        Me.lblquantity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblquantity.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblquantity.ForeColor = System.Drawing.Color.Black
        Me.lblquantity.Location = New System.Drawing.Point(220, 46)
        Me.lblquantity.Name = "lblquantity"
        Me.lblquantity.Size = New System.Drawing.Size(119, 32)
        Me.lblquantity.TabIndex = 16
        Me.lblquantity.Tag = "E"
        Me.lblquantity.Text = "0"
        Me.lblquantity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btnquantity
        '
        Me.btnquantity.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnquantity.AutoSize = True
        Me.btnquantity.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnquantity.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnquantity.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnquantity.Font = New System.Drawing.Font("Tahoma", 11.25!)
        Me.btnquantity.ForeColor = System.Drawing.Color.White
        Me.btnquantity.Image = CType(resources.GetObject("btnquantity.Image"), System.Drawing.Image)
        Me.btnquantity.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnquantity.Location = New System.Drawing.Point(90, 47)
        Me.btnquantity.Name = "btnquantity"
        Me.btnquantity.Size = New System.Drawing.Size(129, 30)
        Me.btnquantity.TabIndex = 1
        Me.btnquantity.Tag = "E"
        Me.btnquantity.Text = "QUANTITY :   "
        Me.btnquantity.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnquantity.UseVisualStyleBackColor = False
        '
        'btnTIMEIN
        '
        Me.btnTIMEIN.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btnTIMEIN.AutoSize = True
        Me.btnTIMEIN.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btnTIMEIN.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnTIMEIN.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTIMEIN.Font = New System.Drawing.Font("Tahoma", 11.25!)
        Me.btnTIMEIN.ForeColor = System.Drawing.Color.White
        Me.btnTIMEIN.Image = CType(resources.GetObject("btnTIMEIN.Image"), System.Drawing.Image)
        Me.btnTIMEIN.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnTIMEIN.Location = New System.Drawing.Point(89, 86)
        Me.btnTIMEIN.Name = "btnTIMEIN"
        Me.btnTIMEIN.Size = New System.Drawing.Size(130, 31)
        Me.btnTIMEIN.TabIndex = 2
        Me.btnTIMEIN.Tag = "D"
        Me.btnTIMEIN.Text = "TIME IN :   "
        Me.btnTIMEIN.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnTIMEIN.UseVisualStyleBackColor = False
        '
        'cbprodDate
        '
        Me.cbprodDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cbprodDate.AutoSize = True
        Me.cbprodDate.BackColor = System.Drawing.Color.White
        Me.cbprodDate.Location = New System.Drawing.Point(325, 133)
        Me.cbprodDate.Name = "cbprodDate"
        Me.cbprodDate.Size = New System.Drawing.Size(15, 14)
        Me.cbprodDate.TabIndex = 4
        Me.cbprodDate.UseVisualStyleBackColor = False
        '
        'btndate
        '
        Me.btndate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.btndate.AutoSize = True
        Me.btndate.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.btndate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btndate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btndate.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndate.ForeColor = System.Drawing.Color.White
        Me.btndate.Image = CType(resources.GetObject("btndate.Image"), System.Drawing.Image)
        Me.btndate.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btndate.Location = New System.Drawing.Point(341, 86)
        Me.btndate.Name = "btndate"
        Me.btndate.Size = New System.Drawing.Size(108, 30)
        Me.btndate.TabIndex = 3
        Me.btndate.Tag = "D"
        Me.btndate.Text = "DATE :    "
        Me.btndate.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btndate.UseVisualStyleBackColor = False
        '
        'btnsavePrint
        '
        Me.btnsavePrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnsavePrint.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnsavePrint.Enabled = False
        Me.btnsavePrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnsavePrint.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsavePrint.ForeColor = System.Drawing.Color.Black
        Me.btnsavePrint.Location = New System.Drawing.Point(210, 373)
        Me.btnsavePrint.Name = "btnsavePrint"
        Me.btnsavePrint.Size = New System.Drawing.Size(224, 38)
        Me.btnsavePrint.TabIndex = 9
        Me.btnsavePrint.Tag = "1"
        Me.btnsavePrint.Text = "S A V E  &&  P R I N T"
        Me.btnsavePrint.UseVisualStyleBackColor = False
        '
        'btnsave
        '
        Me.btnsave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnsave.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnsave.Enabled = False
        Me.btnsave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnsave.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnsave.ForeColor = System.Drawing.Color.Black
        Me.btnsave.Location = New System.Drawing.Point(440, 373)
        Me.btnsave.Name = "btnsave"
        Me.btnsave.Size = New System.Drawing.Size(110, 38)
        Me.btnsave.TabIndex = 10
        Me.btnsave.Tag = "0"
        Me.btnsave.Text = "S A V E"
        Me.btnsave.UseVisualStyleBackColor = False
        '
        'lblshelflife
        '
        Me.lblshelflife.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblshelflife.BackColor = System.Drawing.Color.Transparent
        Me.lblshelflife.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblshelflife.ForeColor = System.Drawing.Color.White
        Me.lblshelflife.Location = New System.Drawing.Point(478, 46)
        Me.lblshelflife.Name = "lblshelflife"
        Me.lblshelflife.Size = New System.Drawing.Size(82, 32)
        Me.lblshelflife.TabIndex = 41
        Me.lblshelflife.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnclear
        '
        Me.btnclear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnclear.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnclear.FlatAppearance.BorderSize = 2
        Me.btnclear.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnclear.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.ForeColor = System.Drawing.Color.Black
        Me.btnclear.Location = New System.Drawing.Point(556, 373)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(110, 38)
        Me.btnclear.TabIndex = 11
        Me.btnclear.Tag = "1"
        Me.btnclear.Text = "C L O S E"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label15.BackColor = System.Drawing.Color.DimGray
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label15.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(89, 341)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(227, 26)
        Me.Label15.TabIndex = 25
        Me.Label15.Tag = "G"
        Me.Label15.Text = "REMARKS :"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label3.BackColor = System.Drawing.Color.DimGray
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(89, 309)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(227, 26)
        Me.Label3.TabIndex = 25
        Me.Label3.Tag = "G"
        Me.Label3.Text = "MANAGER :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label5.BackColor = System.Drawing.Color.DimGray
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(89, 124)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(227, 31)
        Me.Label5.TabIndex = 10
        Me.Label5.Tag = "C"
        Me.Label5.Text = "PRODUCTION DATE :"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label6.BackColor = System.Drawing.Color.DimGray
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(89, 165)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(227, 30)
        Me.Label6.TabIndex = 11
        Me.Label6.Tag = "B"
        Me.Label6.Text = "CONDITION :"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label7.BackColor = System.Drawing.Color.DimGray
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(89, 9)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(130, 32)
        Me.Label7.TabIndex = 12
        Me.Label7.Tag = "A"
        Me.Label7.Text = "ITEM :"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblshelflifeBy
        '
        Me.lblshelflifeBy.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblshelflifeBy.BackColor = System.Drawing.Color.Transparent
        Me.lblshelflifeBy.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblshelflifeBy.ForeColor = System.Drawing.Color.White
        Me.lblshelflifeBy.Location = New System.Drawing.Point(562, 46)
        Me.lblshelflifeBy.Name = "lblshelflifeBy"
        Me.lblshelflifeBy.Size = New System.Drawing.Size(103, 32)
        Me.lblshelflifeBy.TabIndex = 39
        Me.lblshelflifeBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lbldays
        '
        Me.lbldays.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lbldays.BackColor = System.Drawing.Color.DimGray
        Me.lbldays.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldays.ForeColor = System.Drawing.Color.White
        Me.lbldays.Location = New System.Drawing.Point(10, 7)
        Me.lbldays.Name = "lbldays"
        Me.lbldays.Size = New System.Drawing.Size(63, 403)
        Me.lbldays.TabIndex = 36
        Me.lbldays.Tag = ""
        Me.lbldays.Text = "W" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "N" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "S" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "D" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "A" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Y"
        Me.lbldays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblproductionDefault
        '
        Me.lblproductionDefault.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblproductionDefault.BackColor = System.Drawing.Color.Transparent
        Me.lblproductionDefault.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblproductionDefault.ForeColor = System.Drawing.Color.Lime
        Me.lblproductionDefault.Location = New System.Drawing.Point(484, 124)
        Me.lblproductionDefault.Name = "lblproductionDefault"
        Me.lblproductionDefault.Size = New System.Drawing.Size(181, 31)
        Me.lblproductionDefault.TabIndex = 29
        Me.lblproductionDefault.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cboremarks
        '
        Me.cboremarks.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboremarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboremarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboremarks.DropDownHeight = 280
        Me.cboremarks.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboremarks.FormattingEnabled = True
        Me.cboremarks.IntegralHeight = False
        Me.cboremarks.Location = New System.Drawing.Point(317, 341)
        Me.cboremarks.Name = "cboremarks"
        Me.cboremarks.Size = New System.Drawing.Size(348, 26)
        Me.cboremarks.TabIndex = 8
        Me.cboremarks.Tag = "J"
        '
        'cboemployee
        '
        Me.cboemployee.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboemployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboemployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboemployee.DropDownHeight = 280
        Me.cboemployee.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboemployee.FormattingEnabled = True
        Me.cboemployee.IntegralHeight = False
        Me.cboemployee.Location = New System.Drawing.Point(317, 277)
        Me.cboemployee.Name = "cboemployee"
        Me.cboemployee.Size = New System.Drawing.Size(348, 26)
        Me.cboemployee.TabIndex = 6
        Me.cboemployee.Tag = "H"
        '
        'cbomanager
        '
        Me.cbomanager.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cbomanager.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbomanager.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbomanager.DropDownHeight = 280
        Me.cbomanager.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbomanager.FormattingEnabled = True
        Me.cbomanager.IntegralHeight = False
        Me.cbomanager.Location = New System.Drawing.Point(317, 309)
        Me.cbomanager.Name = "cbomanager"
        Me.cbomanager.Size = New System.Drawing.Size(348, 26)
        Me.cbomanager.TabIndex = 7
        Me.cbomanager.Tag = "I"
        '
        'lblusedBy
        '
        Me.lblusedBy.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblusedBy.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.lblusedBy.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblusedBy.ForeColor = System.Drawing.Color.White
        Me.lblusedBy.Location = New System.Drawing.Point(317, 205)
        Me.lblusedBy.Name = "lblusedBy"
        Me.lblusedBy.Size = New System.Drawing.Size(348, 26)
        Me.lblusedBy.TabIndex = 8
        Me.lblusedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cbocondition
        '
        Me.cbocondition.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cbocondition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cbocondition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbocondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbocondition.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.cbocondition.FormattingEnabled = True
        Me.cbocondition.Location = New System.Drawing.Point(317, 165)
        Me.cbocondition.Name = "cbocondition"
        Me.cbocondition.Size = New System.Drawing.Size(348, 30)
        Me.cbocondition.TabIndex = 5
        Me.cbocondition.Tag = "B"
        '
        'cboitems
        '
        Me.cboitems.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cboitems.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cboitems.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboitems.DropDownHeight = 400
        Me.cboitems.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboitems.FormattingEnabled = True
        Me.cboitems.IntegralHeight = False
        Me.cboitems.Location = New System.Drawing.Point(220, 9)
        Me.cboitems.Name = "cboitems"
        Me.cboitems.Size = New System.Drawing.Size(445, 32)
        Me.cboitems.TabIndex = 0
        Me.cboitems.Tag = "A"
        '
        'lblA
        '
        Me.lblA.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblA.BackColor = System.Drawing.Color.Black
        Me.lblA.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblA.ForeColor = System.Drawing.Color.White
        Me.lblA.Location = New System.Drawing.Point(87, 7)
        Me.lblA.Name = "lblA"
        Me.lblA.Size = New System.Drawing.Size(580, 36)
        Me.lblA.TabIndex = 16
        Me.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblB
        '
        Me.lblB.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblB.BackColor = System.Drawing.Color.Black
        Me.lblB.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblB.ForeColor = System.Drawing.Color.White
        Me.lblB.Location = New System.Drawing.Point(87, 163)
        Me.lblB.Name = "lblB"
        Me.lblB.Size = New System.Drawing.Size(580, 34)
        Me.lblB.TabIndex = 15
        Me.lblB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblstorage
        '
        Me.lblstorage.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblstorage.BackColor = System.Drawing.Color.Transparent
        Me.lblstorage.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblstorage.ForeColor = System.Drawing.Color.White
        Me.lblstorage.Location = New System.Drawing.Point(317, 243)
        Me.lblstorage.Name = "lblstorage"
        Me.lblstorage.Size = New System.Drawing.Size(346, 26)
        Me.lblstorage.TabIndex = 9
        Me.lblstorage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblJ
        '
        Me.lblJ.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblJ.BackColor = System.Drawing.Color.Black
        Me.lblJ.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblJ.ForeColor = System.Drawing.Color.White
        Me.lblJ.Location = New System.Drawing.Point(87, 339)
        Me.lblJ.Name = "lblJ"
        Me.lblJ.Size = New System.Drawing.Size(580, 30)
        Me.lblJ.TabIndex = 26
        Me.lblJ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblI
        '
        Me.lblI.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblI.BackColor = System.Drawing.Color.Black
        Me.lblI.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblI.ForeColor = System.Drawing.Color.White
        Me.lblI.Location = New System.Drawing.Point(87, 307)
        Me.lblI.Name = "lblI"
        Me.lblI.Size = New System.Drawing.Size(580, 30)
        Me.lblI.TabIndex = 26
        Me.lblI.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(9, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 405)
        Me.Label1.TabIndex = 40
        Me.Label1.Tag = ""
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label17.BackColor = System.Drawing.Color.DimGray
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label17.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(89, 277)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(227, 26)
        Me.Label17.TabIndex = 25
        Me.Label17.Tag = "G"
        Me.Label17.Text = "EMPLOYEE :"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label11.BackColor = System.Drawing.Color.DimGray
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label11.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(89, 205)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(227, 26)
        Me.Label11.TabIndex = 34
        Me.Label11.Tag = "C"
        Me.Label11.Text = "USE BY ( UNTIL ) :"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.BackColor = System.Drawing.Color.DimGray
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label14.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(89, 243)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(227, 26)
        Me.Label14.TabIndex = 25
        Me.Label14.Tag = "G"
        Me.Label14.Text = "STORAGE :"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblG
        '
        Me.lblG.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblG.BackColor = System.Drawing.Color.Black
        Me.lblG.Font = New System.Drawing.Font("Arial", 12.0!)
        Me.lblG.ForeColor = System.Drawing.Color.White
        Me.lblG.Location = New System.Drawing.Point(87, 203)
        Me.lblG.Name = "lblG"
        Me.lblG.Size = New System.Drawing.Size(580, 30)
        Me.lblG.TabIndex = 33
        Me.lblG.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblF
        '
        Me.lblF.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblF.BackColor = System.Drawing.Color.White
        Me.lblF.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblF.ForeColor = System.Drawing.Color.White
        Me.lblF.Location = New System.Drawing.Point(87, 241)
        Me.lblF.Name = "lblF"
        Me.lblF.Size = New System.Drawing.Size(578, 30)
        Me.lblF.TabIndex = 26
        Me.lblF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblH
        '
        Me.lblH.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblH.BackColor = System.Drawing.Color.Black
        Me.lblH.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblH.ForeColor = System.Drawing.Color.White
        Me.lblH.Location = New System.Drawing.Point(87, 275)
        Me.lblH.Name = "lblH"
        Me.lblH.Size = New System.Drawing.Size(580, 30)
        Me.lblH.TabIndex = 26
        Me.lblH.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblcurDate
        '
        Me.lblcurDate.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblcurDate.BackColor = System.Drawing.Color.White
        Me.lblcurDate.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcurDate.ForeColor = System.Drawing.Color.Black
        Me.lblcurDate.Location = New System.Drawing.Point(451, 86)
        Me.lblcurDate.Name = "lblcurDate"
        Me.lblcurDate.Size = New System.Drawing.Size(214, 30)
        Me.lblcurDate.TabIndex = 39
        Me.lblcurDate.Tag = "D"
        Me.lblcurDate.Text = "--/--/----"
        Me.lblcurDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblunit
        '
        Me.lblunit.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblunit.BackColor = System.Drawing.Color.Transparent
        Me.lblunit.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblunit.ForeColor = System.Drawing.Color.White
        Me.lblunit.Location = New System.Drawing.Point(341, 46)
        Me.lblunit.Name = "lblunit"
        Me.lblunit.Size = New System.Drawing.Size(135, 32)
        Me.lblunit.TabIndex = 39
        Me.lblunit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblE
        '
        Me.lblE.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblE.BackColor = System.Drawing.Color.Black
        Me.lblE.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblE.ForeColor = System.Drawing.Color.White
        Me.lblE.Location = New System.Drawing.Point(87, 44)
        Me.lblE.Name = "lblE"
        Me.lblE.Size = New System.Drawing.Size(580, 36)
        Me.lblE.TabIndex = 20
        Me.lblE.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblD
        '
        Me.lblD.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblD.BackColor = System.Drawing.Color.Black
        Me.lblD.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblD.ForeColor = System.Drawing.Color.White
        Me.lblD.Location = New System.Drawing.Point(87, 83)
        Me.lblD.Name = "lblD"
        Me.lblD.Size = New System.Drawing.Size(580, 36)
        Me.lblD.TabIndex = 30
        Me.lblD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'dateProduction
        '
        Me.dateProduction.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.dateProduction.BackColor = System.Drawing.Color.White
        Me.dateProduction.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dateProduction.ForeColor = System.Drawing.Color.Black
        Me.dateProduction.Location = New System.Drawing.Point(340, 124)
        Me.dateProduction.Name = "dateProduction"
        Me.dateProduction.Size = New System.Drawing.Size(143, 31)
        Me.dateProduction.TabIndex = 39
        Me.dateProduction.Text = "--/--/----"
        Me.dateProduction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.BackColor = System.Drawing.Color.White
        Me.Label8.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(318, 124)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(22, 31)
        Me.Label8.TabIndex = 50
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblC
        '
        Me.lblC.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblC.BackColor = System.Drawing.Color.Black
        Me.lblC.Font = New System.Drawing.Font("Arial", 14.25!)
        Me.lblC.ForeColor = System.Drawing.Color.White
        Me.lblC.Location = New System.Drawing.Point(87, 122)
        Me.lblC.Name = "lblC"
        Me.lblC.Size = New System.Drawing.Size(580, 35)
        Me.lblC.TabIndex = 14
        Me.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'setPreview
        '
        Me.setPreview.Enabled = True
        Me.setPreview.Interval = 1000
        '
        'tfocus
        '
        Me.tfocus.Enabled = True
        Me.tfocus.Interval = 500
        '
        'lblTimeIn
        '
        Me.lblTimeIn.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.lblTimeIn.BackColor = System.Drawing.Color.White
        Me.lblTimeIn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTimeIn.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeIn.ForeColor = System.Drawing.Color.Black
        Me.lblTimeIn.Location = New System.Drawing.Point(220, 86)
        Me.lblTimeIn.Name = "lblTimeIn"
        Me.lblTimeIn.Size = New System.Drawing.Size(119, 31)
        Me.lblTimeIn.TabIndex = 53
        Me.lblTimeIn.Tag = "D"
        Me.lblTimeIn.Text = "07:00 AM"
        Me.lblTimeIn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'vw_3_labelInput2
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(1284, 794)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_3_labelInput2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.pmain.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.paperOut.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents cboitems As modComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbocondition As modComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblC As System.Windows.Forms.Label
    Friend WithEvents lblB As System.Windows.Forms.Label
    Friend WithEvents lblA As System.Windows.Forms.Label
    Friend WithEvents lblusedBy As System.Windows.Forms.Label
    Friend WithEvents lblE As System.Windows.Forms.Label
    Friend WithEvents lblF As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents griditemList As System.Windows.Forms.DataGridView
    Friend WithEvents lblproductionDefault As System.Windows.Forms.Label
    Friend WithEvents lblD As System.Windows.Forms.Label
    Friend WithEvents lblG As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblJ As System.Windows.Forms.Label
    Friend WithEvents lblH As System.Windows.Forms.Label
    Friend WithEvents lblI As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cboremarks As modComboBox
    Friend WithEvents cboemployee As modComboBox
    Friend WithEvents cbomanager As modComboBox
    Friend WithEvents lbldays As System.Windows.Forms.Label
    Friend WithEvents btnsavePrint As Button
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents lblshelflifeBy As System.Windows.Forms.Label
    Friend WithEvents lblstorage As System.Windows.Forms.Label
    Friend WithEvents lblunit As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblshelflife As System.Windows.Forms.Label
    Friend WithEvents paperOut As System.Windows.Forms.Panel
    Friend WithEvents lblpreview_days As System.Windows.Forms.Label
    Friend WithEvents lblpreview_itemName As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_productionDate As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_quantityUnit As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_shelftLife As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_employeeName As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_timeIN As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_usedBy As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_remarks As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_manager As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_PM As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents lblpreview_AM As System.Windows.Forms.Label
    Friend WithEvents setPreview As System.Windows.Forms.Timer
    Friend WithEvents tfocus As System.Windows.Forms.Timer
    Friend WithEvents btnsave As System.Windows.Forms.Button
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Public WithEvents btndate As System.Windows.Forms.Button
    Friend WithEvents lblcurDate As System.Windows.Forms.Label
    Friend WithEvents cbprodDate As System.Windows.Forms.CheckBox
    Friend WithEvents dateProduction As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Public WithEvents btnTIMEIN As System.Windows.Forms.Button
    Public WithEvents btnquantity As System.Windows.Forms.Button
    Friend WithEvents lblquantity As System.Windows.Forms.Label
    Friend WithEvents lblTimeIn As System.Windows.Forms.Label
End Class
