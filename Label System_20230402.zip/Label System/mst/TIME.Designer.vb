﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TIME
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TIME))
		Me.Label13 = New System.Windows.Forms.Label()
		Me.PictureBox1 = New System.Windows.Forms.PictureBox()
		Me.lblCaption = New System.Windows.Forms.Label()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.cbominutes = New System.Windows.Forms.ComboBox()
		Me.cbohour = New System.Windows.Forms.ComboBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.btnnext = New System.Windows.Forms.Button()
		Me.btndelete = New System.Windows.Forms.Button()
		Me.btn9 = New System.Windows.Forms.Button()
		Me.btn0 = New System.Windows.Forms.Button()
		Me.btn8 = New System.Windows.Forms.Button()
		Me.btn7 = New System.Windows.Forms.Button()
		Me.btn6 = New System.Windows.Forms.Button()
		Me.btn3 = New System.Windows.Forms.Button()
		Me.btn5 = New System.Windows.Forms.Button()
		Me.btn2 = New System.Windows.Forms.Button()
		Me.btn4 = New System.Windows.Forms.Button()
		Me.btn1 = New System.Windows.Forms.Button()
		Me.btnokayClose = New System.Windows.Forms.Button()
		Me.rbAM = New System.Windows.Forms.RadioButton()
		Me.rbPM = New System.Windows.Forms.RadioButton()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Label13
		'
		Me.Label13.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label13.BackColor = System.Drawing.SystemColors.ActiveCaption
		Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.Label13.Location = New System.Drawing.Point(0, 56)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(422, 6)
		Me.Label13.TabIndex = 66
		'
		'PictureBox1
		'
		Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
		Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
		Me.PictureBox1.Name = "PictureBox1"
		Me.PictureBox1.Size = New System.Drawing.Size(58, 56)
		Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PictureBox1.TabIndex = 68
		Me.PictureBox1.TabStop = False
		'
		'lblCaption
		'
		Me.lblCaption.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblCaption.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.lblCaption.Font = New System.Drawing.Font("Trebuchet MS", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblCaption.ForeColor = System.Drawing.Color.Aqua
		Me.lblCaption.Location = New System.Drawing.Point(65, 5)
		Me.lblCaption.Name = "lblCaption"
		Me.lblCaption.Size = New System.Drawing.Size(344, 51)
		Me.lblCaption.TabIndex = 67
		Me.lblCaption.Text = "TIME"
		Me.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Label14
		'
		Me.Label14.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label14.BackColor = System.Drawing.SystemColors.ActiveCaptionText
		Me.Label14.Font = New System.Drawing.Font("Haettenschweiler", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label14.ForeColor = System.Drawing.SystemColors.ActiveCaption
		Me.Label14.Location = New System.Drawing.Point(32, 0)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(390, 56)
		Me.Label14.TabIndex = 65
		'
		'cbominutes
		'
		Me.cbominutes.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.cbominutes.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cbominutes.Items.AddRange(New Object() {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"})
		Me.cbominutes.Location = New System.Drawing.Point(234, 73)
		Me.cbominutes.Name = "cbominutes"
		Me.cbominutes.Size = New System.Drawing.Size(85, 50)
		Me.cbominutes.TabIndex = 1
		Me.cbominutes.Text = "00"
		'
		'cbohour
		'
		Me.cbohour.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.cbohour.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cbohour.Items.AddRange(New Object() {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"})
		Me.cbohour.Location = New System.Drawing.Point(142, 73)
		Me.cbohour.Name = "cbohour"
		Me.cbohour.Size = New System.Drawing.Size(86, 50)
		Me.cbohour.TabIndex = 0
		Me.cbohour.Text = "07"
		'
		'Label1
		'
		Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(17, 76)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(121, 42)
		Me.Label1.TabIndex = 76
		Me.Label1.Text = "TIME :"
		'
		'btnnext
		'
		Me.btnnext.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btnnext.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btnnext.FlatAppearance.BorderSize = 2
		Me.btnnext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btnnext.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnnext.ForeColor = System.Drawing.Color.Black
		Me.btnnext.Location = New System.Drawing.Point(290, 344)
		Me.btnnext.Name = "btnnext"
		Me.btnnext.Size = New System.Drawing.Size(110, 62)
		Me.btnnext.TabIndex = 13
		Me.btnnext.Tag = "DEL"
		Me.btnnext.Text = "NEXT"
		Me.btnnext.UseVisualStyleBackColor = False
		'
		'btndelete
		'
		Me.btndelete.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btndelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btndelete.FlatAppearance.BorderSize = 2
		Me.btndelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btndelete.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btndelete.ForeColor = System.Drawing.Color.Black
		Me.btndelete.Location = New System.Drawing.Point(60, 344)
		Me.btndelete.Name = "btndelete"
		Me.btndelete.Size = New System.Drawing.Size(109, 62)
		Me.btndelete.TabIndex = 14
		Me.btndelete.Tag = "DEL"
		Me.btndelete.Text = "DEL"
		Me.btndelete.UseVisualStyleBackColor = False
		'
		'btn9
		'
		Me.btn9.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn9.FlatAppearance.BorderSize = 2
		Me.btn9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn9.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn9.ForeColor = System.Drawing.Color.Black
		Me.btn9.Location = New System.Drawing.Point(290, 277)
		Me.btn9.Name = "btn9"
		Me.btn9.Size = New System.Drawing.Size(110, 62)
		Me.btn9.TabIndex = 11
		Me.btn9.Tag = "9"
		Me.btn9.Text = "9"
		Me.btn9.UseVisualStyleBackColor = False
		'
		'btn0
		'
		Me.btn0.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn0.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn0.FlatAppearance.BorderSize = 2
		Me.btn0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn0.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn0.ForeColor = System.Drawing.Color.Black
		Me.btn0.Location = New System.Drawing.Point(175, 344)
		Me.btn0.Name = "btn0"
		Me.btn0.Size = New System.Drawing.Size(109, 62)
		Me.btn0.TabIndex = 12
		Me.btn0.Tag = "0"
		Me.btn0.Text = "0"
		Me.btn0.UseVisualStyleBackColor = False
		'
		'btn8
		'
		Me.btn8.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn8.FlatAppearance.BorderSize = 2
		Me.btn8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn8.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn8.ForeColor = System.Drawing.Color.Black
		Me.btn8.Location = New System.Drawing.Point(175, 277)
		Me.btn8.Name = "btn8"
		Me.btn8.Size = New System.Drawing.Size(109, 62)
		Me.btn8.TabIndex = 10
		Me.btn8.Tag = "8"
		Me.btn8.Text = "8"
		Me.btn8.UseVisualStyleBackColor = False
		'
		'btn7
		'
		Me.btn7.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn7.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn7.FlatAppearance.BorderSize = 2
		Me.btn7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn7.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn7.ForeColor = System.Drawing.Color.Black
		Me.btn7.Location = New System.Drawing.Point(60, 276)
		Me.btn7.Name = "btn7"
		Me.btn7.Size = New System.Drawing.Size(109, 62)
		Me.btn7.TabIndex = 9
		Me.btn7.Tag = "7"
		Me.btn7.Text = "7"
		Me.btn7.UseVisualStyleBackColor = False
		'
		'btn6
		'
		Me.btn6.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn6.FlatAppearance.BorderSize = 2
		Me.btn6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn6.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn6.ForeColor = System.Drawing.Color.Black
		Me.btn6.Location = New System.Drawing.Point(289, 209)
		Me.btn6.Name = "btn6"
		Me.btn6.Size = New System.Drawing.Size(110, 62)
		Me.btn6.TabIndex = 8
		Me.btn6.Tag = "6"
		Me.btn6.Text = "6"
		Me.btn6.UseVisualStyleBackColor = False
		'
		'btn3
		'
		Me.btn3.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn3.FlatAppearance.BorderSize = 2
		Me.btn3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn3.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn3.ForeColor = System.Drawing.Color.Black
		Me.btn3.Location = New System.Drawing.Point(290, 140)
		Me.btn3.Name = "btn3"
		Me.btn3.Size = New System.Drawing.Size(110, 62)
		Me.btn3.TabIndex = 5
		Me.btn3.Tag = "3"
		Me.btn3.Text = "3"
		Me.btn3.UseVisualStyleBackColor = False
		'
		'btn5
		'
		Me.btn5.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn5.FlatAppearance.BorderSize = 2
		Me.btn5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn5.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn5.ForeColor = System.Drawing.Color.Black
		Me.btn5.Location = New System.Drawing.Point(174, 209)
		Me.btn5.Name = "btn5"
		Me.btn5.Size = New System.Drawing.Size(109, 62)
		Me.btn5.TabIndex = 7
		Me.btn5.Tag = "5"
		Me.btn5.Text = "5"
		Me.btn5.UseVisualStyleBackColor = False
		'
		'btn2
		'
		Me.btn2.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn2.FlatAppearance.BorderSize = 2
		Me.btn2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn2.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn2.ForeColor = System.Drawing.Color.Black
		Me.btn2.Location = New System.Drawing.Point(175, 140)
		Me.btn2.Name = "btn2"
		Me.btn2.Size = New System.Drawing.Size(109, 62)
		Me.btn2.TabIndex = 4
		Me.btn2.Tag = "2"
		Me.btn2.Text = "2"
		Me.btn2.UseVisualStyleBackColor = False
		'
		'btn4
		'
		Me.btn4.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn4.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn4.FlatAppearance.BorderSize = 2
		Me.btn4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn4.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn4.ForeColor = System.Drawing.Color.Black
		Me.btn4.Location = New System.Drawing.Point(59, 208)
		Me.btn4.Name = "btn4"
		Me.btn4.Size = New System.Drawing.Size(109, 62)
		Me.btn4.TabIndex = 6
		Me.btn4.Tag = "4"
		Me.btn4.Text = "4"
		Me.btn4.UseVisualStyleBackColor = False
		'
		'btn1
		'
		Me.btn1.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btn1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn1.FlatAppearance.BorderSize = 2
		Me.btn1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btn1.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btn1.ForeColor = System.Drawing.Color.Black
		Me.btn1.Location = New System.Drawing.Point(60, 140)
		Me.btn1.Name = "btn1"
		Me.btn1.Size = New System.Drawing.Size(109, 62)
		Me.btn1.TabIndex = 3
		Me.btn1.Tag = "1"
		Me.btn1.Text = "1"
		Me.btn1.UseVisualStyleBackColor = False
		'
		'btnokayClose
		'
		Me.btnokayClose.Anchor = System.Windows.Forms.AnchorStyles.Bottom
		Me.btnokayClose.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btnokayClose.FlatAppearance.BorderSize = 2
		Me.btnokayClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
		Me.btnokayClose.Font = New System.Drawing.Font("Consolas", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnokayClose.ForeColor = System.Drawing.Color.Black
		Me.btnokayClose.Location = New System.Drawing.Point(60, 412)
		Me.btnokayClose.Name = "btnokayClose"
		Me.btnokayClose.Size = New System.Drawing.Size(340, 62)
		Me.btnokayClose.TabIndex = 12
		Me.btnokayClose.Tag = "0"
		Me.btnokayClose.Text = "SET / CLOSE"
		Me.btnokayClose.UseVisualStyleBackColor = False
		'
		'rbAM
		'
		Me.rbAM.AutoSize = True
		Me.rbAM.Checked = True
		Me.rbAM.Font = New System.Drawing.Font("Tahoma", 14.25!)
		Me.rbAM.Location = New System.Drawing.Point(330, 71)
		Me.rbAM.Name = "rbAM"
		Me.rbAM.Size = New System.Drawing.Size(54, 27)
		Me.rbAM.TabIndex = 78
		Me.rbAM.Text = "AM"
		Me.rbAM.UseVisualStyleBackColor = True
		'
		'rbPM
		'
		Me.rbPM.Font = New System.Drawing.Font("Tahoma", 14.25!)
		Me.rbPM.Location = New System.Drawing.Point(330, 98)
		Me.rbPM.Name = "rbPM"
		Me.rbPM.Size = New System.Drawing.Size(54, 27)
		Me.rbPM.TabIndex = 78
		Me.rbPM.Text = "PM"
		Me.rbPM.UseVisualStyleBackColor = True
		'
		'TIME
		'
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(250, Byte), Integer))
		Me.ClientSize = New System.Drawing.Size(422, 481)
		Me.Controls.Add(Me.rbPM)
		Me.Controls.Add(Me.rbAM)
		Me.Controls.Add(Me.btnnext)
		Me.Controls.Add(Me.btndelete)
		Me.Controls.Add(Me.btn9)
		Me.Controls.Add(Me.btnokayClose)
		Me.Controls.Add(Me.btn0)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.btn8)
		Me.Controls.Add(Me.cbominutes)
		Me.Controls.Add(Me.btn7)
		Me.Controls.Add(Me.cbohour)
		Me.Controls.Add(Me.btn6)
		Me.Controls.Add(Me.btn3)
		Me.Controls.Add(Me.Label13)
		Me.Controls.Add(Me.btn5)
		Me.Controls.Add(Me.PictureBox1)
		Me.Controls.Add(Me.btn2)
		Me.Controls.Add(Me.lblCaption)
		Me.Controls.Add(Me.btn4)
		Me.Controls.Add(Me.Label14)
		Me.Controls.Add(Me.btn1)
		Me.Font = New System.Drawing.Font("Tahoma", 8.25!)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.Name = "TIME"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "CALENDAR"
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Label13 As System.Windows.Forms.Label
	Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
	Friend WithEvents lblCaption As System.Windows.Forms.Label
	Friend WithEvents Label14 As System.Windows.Forms.Label
	Friend WithEvents cbominutes As System.Windows.Forms.ComboBox
	Friend WithEvents cbohour As System.Windows.Forms.ComboBox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents btndelete As System.Windows.Forms.Button
	Friend WithEvents btn9 As System.Windows.Forms.Button
	Friend WithEvents btn0 As System.Windows.Forms.Button
	Friend WithEvents btn8 As System.Windows.Forms.Button
	Friend WithEvents btn7 As System.Windows.Forms.Button
	Friend WithEvents btn6 As System.Windows.Forms.Button
	Friend WithEvents btn3 As System.Windows.Forms.Button
	Friend WithEvents btn5 As System.Windows.Forms.Button
	Friend WithEvents btn2 As System.Windows.Forms.Button
	Friend WithEvents btn4 As System.Windows.Forms.Button
	Friend WithEvents btn1 As System.Windows.Forms.Button
	Friend WithEvents btnnext As System.Windows.Forms.Button
	Friend WithEvents btnokayClose As System.Windows.Forms.Button
	Friend WithEvents rbAM As System.Windows.Forms.RadioButton
	Friend WithEvents rbPM As System.Windows.Forms.RadioButton
End Class
