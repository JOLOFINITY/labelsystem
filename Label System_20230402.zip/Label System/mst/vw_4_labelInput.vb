﻿Imports System.Runtime.InteropServices
Public Class vw_4_labelInput

#Region "MOVING"
    Public Const WM_NCLBUTTONDOWN As Integer = 161
    Public Const HT_CAPTION As Integer = 2

    <DllImportAttribute("User32.dll")> _
    Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
    End Function
    <DllImportAttribute("User32.dll")> _
    Public Shared Function ReleaseCapture() As Boolean
    End Function

    Private Sub vw_3_labelInput_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        vw_1_menu.lblheader.Text = vw_1_menu.lblheader.Tag
    End Sub

    Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown
        'If e.Button = MouseButtons.Left Then
        '	ReleaseCapture()
        '	SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
        'End If
    End Sub

    Private Const SM_CXSCREEN As Integer = 0
    Private Const SM_CYSCREEN As Integer = 1
    Private Shared HWND_TOP As IntPtr = IntPtr.Zero
    Private Const SWP_SHOWWINDOW As Integer = 64

    Private winState As FormWindowState
    Private brdStyle As FormBorderStyle
    Private isTopMost As Boolean
    Private isBounds As Rectangle

    <DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
    Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

    End Function
    <DllImport("user32.dll")>
    Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

    End Sub
    Public Shared ReadOnly Property ScreenX As Integer
        Get
            Return GetSystemMetrics(SM_CXSCREEN)
        End Get
    End Property

    Public Shared ReadOnly Property ScreenY As Integer
        Get
            Return GetSystemMetrics(SM_CYSCREEN)
        End Get
    End Property

    Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
        SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
    End Sub

    Private IsMaximized As Boolean = False
    Public Sub Maximize(ByVal targetForm As Form)
        If Not IsMaximized Then
            IsMaximized = True
            Save(targetForm)
            targetForm.WindowState = FormWindowState.Maximized
            targetForm.FormBorderStyle = FormBorderStyle.None
            targetForm.TopMost = True
            SetWinFullScreen(targetForm.Handle)
        End If
    End Sub
    Public Sub Save(ByVal targetForm As Form)
        winState = targetForm.WindowState
        brdStyle = targetForm.FormBorderStyle
        isTopMost = targetForm.TopMost
        isBounds = targetForm.Bounds
    End Sub
    Public Sub Restore(ByVal targetForm As Form)
        targetForm.WindowState = winState
        targetForm.FormBorderStyle = brdStyle
        targetForm.TopMost = isTopMost
        targetForm.Bounds = isBounds
        IsMaximized = False
    End Sub
#End Region
    Private validityUntil As String = String.Empty
    Private mst_items As New DataTable("result")
    Private Sub vw_3_labelInput_Shown(sender As Object, e As EventArgs) Handles Me.Shown
        initREPORT()

        Call get_itemListA(cboitems, cbocondition, mst_items)

        Call get_itemListC(griditemList)
        dtTimeIn.Value = DateAndTime.Now

        With My.Settings
            cboemployee.Text = login_username
            cbomanager.Text = .nameOfManager
        End With

        vw_1_menu.lblheader.Text = "L A B E L   P R I N T I N G   I N P U T "

        dtTimeIn.Value = DateAndTime.Now.ToString("yyyy-MM-dd 07:00:00")
    End Sub
    Private Sub cboitems_TextChanged(sender As Object, e As EventArgs) Handles cboitems.TextChanged
        cbocondition.Text = Nothing
        cboquantity.Text = String.Empty
        lblunit.Text = String.Empty
        lblshelflife.Text = String.Empty
        lblshelflifeBy.Text = String.Empty
        lblstorage.Text = String.Empty
        lblusedBy.Text = String.Empty
        lblvalidity.Text = String.Empty
        validityUntil = String.Empty

        _exec_gridSearch(griditemList, cboitems.Text)

        If griditemList.Rows.Count = 0 Then
            picNew.Visible = True
        Else
            picNew.Visible = False
        End If
    End Sub
    Private Sub cbocondition_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbocondition.SelectedIndexChanged
        If cbocondition.Text <> String.Empty Then
            If cboitems.Text <> String.Empty Then
                Dim filter = mst_items.Select("`Item Name` = '" & cboitems.Text & "' AND `Condition` = '" & cbocondition.Text & "'")

                If filter.Length = 1 Then
                    lblunit.Text = filter.ToArray(0)("Unit")
                    lblshelflife.Text = filter.ToArray(0)("Shelflife")

                    Dim dec = Math.Truncate(filter.ToArray(0)("Shelflife"))
                    Dim toInt = Decimal.Parse(lblshelflife.Text) - dec
                    If toInt = 0 Then
                        lblshelflife.Text = CInt(lblshelflife.Text)
                    End If

                    lblshelflifeBy.Text = filter.ToArray(0)("Shelflife By")
                    lblstorage.Text = filter.ToArray(0)("Storage")

                    If filter.ToArray(0)("Default").ToString <> "" And filter.ToArray(0)("Default By").ToString <> "" Then
                        Call getDefaultProduction(filter.ToArray(0)("Default"), filter.ToArray(0)("Default By"))
                        lblproductionDefault.Text = " Default : " & CInt(filter.ToArray(0)("Default")) & " " & filter.ToArray(0)("Default By")

                        If filter.ToArray(0)("Add Days") > 0 Then
                            lblproductionDefault.Text &= " + " & filter.ToArray(0)("Add Days") & " Day(s)"

                            dateProduction.Value = dateProduction.Value.AddDays(filter.ToArray(0)("Add Days").ToString)
                        End If
                    Else
                        lblproductionDefault.Text = String.Empty

                        dateProduction.Checked = False

                        dateProduction_default = DateAndTime.Now
                        dateProduction_defaultNo = 0.0
                        dateProduction_defaultBy = String.Empty
                    End If

                    dtTimeIn.Focus()
                    On Error Resume Next
                    dtTimeIn.Value = DateAndTime.Now
                Else
                    MessageBox.Show("Record not found, Please ask SYSTEM-ADMIN to add.", "Item not found.", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If

                'getLastInput(cboitems.Text, cbocondition, cbotenure, cboterm, cboquantity, cboprocess, cbounit, cbostorage)
            End If
        End If
    End Sub

    Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
        If e.RowIndex >= 0 And e.ColumnIndex = 0 Then
            With griditemList
                Dim strItem As String = .Rows(e.RowIndex).Cells(1).Value.ToString.Trim
                Dim strCon As String = .Rows(e.RowIndex).Cells(2).Value.ToString.Trim

                cboitems.Text = strItem
                cbocondition.Text = strCon
            End With
        End If
    End Sub

    Private Sub cboitems_Enter(sender As Object, e As EventArgs) Handles _
        cboitems.Enter, _
        cbocondition.Enter, _
        dateProduction.Enter, _
        dtTimeIn.Enter, _
        cboquantity.Enter, _
        cboemployee.Enter, _
        cboremarks.Enter, _
        cbomanager.Enter, dtDate.Enter

        Dim strTag As String = sender.Tag

        If strTag = "A" Then
            lblA.BackColor = Color.Lime

        ElseIf strTag = "B" Then
            lblB.BackColor = Color.Lime

        ElseIf strTag = "C" Then
            lblC.BackColor = Color.Lime

        ElseIf strTag = "D" Then
            lblD.BackColor = Color.Lime

        ElseIf strTag = "E" Then
            lblE.BackColor = Color.Lime

        ElseIf strTag = "H" Then
            lblH.BackColor = Color.Lime

        ElseIf strTag = "I" Then
            lblI.BackColor = Color.Lime

        ElseIf strTag = "J" Then
            lblJ.BackColor = Color.Lime

        End If
    End Sub
    Private Sub cboitems_Leave(sender As Object, e As EventArgs) Handles _
        cboitems.Leave, _
        cbocondition.Leave, _
        dateProduction.Leave, _
        dtTimeIn.Leave, _
        cboquantity.Leave, _
        cboemployee.Leave, _
        cboremarks.Leave, _
        cbomanager.Leave, dtDate.Leave

        Dim strTag As String = sender.Tag

        If strTag = "A" Then
            lblA.BackColor = Color.Black

        ElseIf strTag = "B" Then
            lblB.BackColor = Color.Black

        ElseIf strTag = "C" Then
            lblC.BackColor = Color.Black

        ElseIf strTag = "D" Then
            lblD.BackColor = Color.Black

        ElseIf strTag = "E" Then
            lblE.BackColor = Color.Black

        ElseIf strTag = "F" Then
            lblF.BackColor = Color.Black

        ElseIf strTag = "G" Then
            lblG.BackColor = Color.Black

        ElseIf strTag = "H" Then
            lblH.BackColor = Color.Black

        ElseIf strTag = "I" Then
            lblI.BackColor = Color.Black

        ElseIf strTag = "J" Then
            lblJ.BackColor = Color.Black

        End If
    End Sub
    Private Sub displayDay()
        If lblshelflife.Text <> String.Empty Then
            Dim days As String = String.Empty

            If lblshelflifeBy.Text = "MINUTES" Then
                lblusedBy.Text = dtTimeIn.Value.AddMinutes(lblshelflife.Text).ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = dtTimeIn.Value.AddMinutes(lblshelflife.Text)
                days = dtTimeIn.Value.AddMinutes(lblshelflife.Text).ToString("dddd")

            ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddHours(lblshelflife.Text).ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = dtTimeIn.Value.AddHours(lblshelflife.Text)
                days = dtTimeIn.Value.AddHours(lblshelflife.Text).ToString("dddd")

            ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddDays(lblshelflife.Text).ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = dtTimeIn.Value.AddDays(lblshelflife.Text)
                days = dtTimeIn.Value.AddDays(lblshelflife.Text).ToString("dddd")

            ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                lblusedBy.Text = dtTimeIn.Value.AddDays(toDays).ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = dtTimeIn.Value.AddDays(toDays)
                days = dtTimeIn.Value.AddDays(toDays).ToString("dddd")

            ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddMonths(lblshelflife.Text).ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = dtTimeIn.Value.AddMonths(lblshelflife.Text)
                days = dtTimeIn.Value.AddMonths(lblshelflife.Text).ToString("dddd")

            ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                lblusedBy.Text = dtTimeIn.Value.AddYears(lblshelflife.Text).ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = dtTimeIn.Value.AddYears(lblshelflife.Text)
                days = dtTimeIn.Value.AddYears(lblshelflife.Text).ToString("dddd")

            End If

            lbldays.Text = String.Empty
            lbldays.Tag = days.ToUpper
            For i = 1 To days.Length
                lbldays.Text &= Mid(days, i, 1).ToString.ToUpper & vbNewLine
            Next
            lbldays.Text = lbldays.Text.Trim
        End If
    End Sub
    Private dateProduction_default As DateTime
    Private dateProduction_defaultNo As Decimal = 0.0
    Private dateProduction_defaultBy As String
    Private Sub getDefaultProduction(ByRef def As Decimal, ByRef defBy As String)
        If defBy = "MINUTES" Then
            dateProduction.Value = DateAndTime.Now.AddMinutes(-def)
            dateProduction_default = dateProduction.Value

        ElseIf defBy = "HOUR(S)" Then
            dateProduction.Value = DateAndTime.Now.AddHours(-def)
            dateProduction_default = dateProduction.Value

        ElseIf defBy = "DAY(S)" Then
            dateProduction.Value = DateAndTime.Now.AddDays(-def)
            dateProduction_default = dateProduction.Value

        ElseIf defBy = "WEEK(S)" Then
            Dim toDays = Decimal.Parse(def) * 7.0
            dateProduction.Value = DateAndTime.Now.AddDays(-toDays)
            dateProduction_default = dateProduction.Value

        ElseIf defBy = "MONTH(S)" Then
            dateProduction.Value = DateAndTime.Now.AddMonths(-def)
            dateProduction_default = dateProduction.Value

        ElseIf defBy = "YEAR(S)" Then
            dateProduction.Value = DateAndTime.Now.AddYears(-def)
            dateProduction_default = dateProduction.Value
            'Else
            '	def = 6
            '	defBy = "MONTH(S)"

            '	dateProduction.Value = DateAndTime.Now.AddMonths(-def)
            '	dateProduction_default = dateProduction.Value
        End If

        dateProduction_defaultNo = def
        dateProduction_defaultBy = defBy

        If My.Settings.check_ProductionDate = 1 Then
            dateProduction.Checked = True
        Else
            dateProduction.Checked = False
        End If
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnsavePrint.Click, btnsave.Click
        saveRecord(sender.Tag)
    End Sub
    Private Sub saveRecord(ByRef intPrint As Integer)
        If cboitems.SelectedIndex = -1 Or cboitems.Text = String.Empty Then
            MessageBox.Show("Please Select Item and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            cboitems.SelectAll() : cboitems.Focus()
        ElseIf cbocondition.SelectedIndex = -1 Then
            MessageBox.Show("Please select Condition and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            cbocondition.SelectAll() : cbocondition.Focus()
        ElseIf (cboquantity.Text = String.Empty) Then
            MessageBox.Show("Quantity Required! and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            cboquantity.SelectAll() : cboquantity.Focus()
        Else
            With My.Settings
                .nameOfEmployee = cboemployee.Text
                .nameOfManager = cbomanager.Text
                .remarks = cboremarks.Text
                .Save()
            End With

            Dim isPrinted As String = "0"

            Dim printedDate As String = "NULL"
            Dim printedby As String = "NULL"

            If intPrint Then
                Dim queryTOPrint As String = _
                    "SELECT 'PRINTING' `UID`,'" & lblpreview_days.Tag & "' `DAY`," & vbNewLine & _
                    "'" & lblpreview_itemName.Text & "' `ITEM`," & vbNewLine & _
                    "'" & lblpreview_productionDate.Text & "' `DATE`," & vbNewLine & _
                    "'" & lblpreview_quantityUnit.Text & "' `QUANTITY`," & vbNewLine & _
                    "'" & lblpreview_shelftLife.Text & "' `SHELFLIFE`," & vbNewLine & _
                    "'" & lblpreview_timeIN.Text & "' `TIME-IN`," & vbNewLine & _
                    "'" & lblpreview_employeeName.Text & "' `EMPLOYEE`," & vbNewLine & _
                    "'" & lblpreview_AM.Text & "' `AM`," & vbNewLine & _
                    "'" & lblpreview_PM.Text & "' `PM`," & vbNewLine & _
                    "'" & lblpreview_usedBy.Text & "' `USED BY`," & vbNewLine & _
                    "'" & lblpreview_manager.Text & "' `MANAGER`," & vbNewLine & _
                    "'" & lblpreview_remarks.Text & "' `REMARKS` "

                Dim result = quickPrint(queryTOPrint)

                With cReport
                    .DataSourceConnections.Clear()
                    .SetDataSource(result)
                    .PrintToPrinter(1, False, 0, 0)
                End With

                isPrinted = "1"
                printedDate = "NOW()"
                printedby = "'" & login_name & "'"
            End If

            Dim query As String = _
                "INSERT INTO `t_for_print`" & vbNewLine & _
                "(`DAY`," & vbNewLine & _
                "`ITEM`," & vbNewLine & _
                "`DATE`," & vbNewLine & _
                "`QUANTITY`," & vbNewLine & _
                "`SHELFLIFE`," & vbNewLine & _
                "`TIME-IN`," & vbNewLine & _
                "`EMPLOYEE`," & vbNewLine & _
                "`AM`," & vbNewLine & _
                "`PM`," & vbNewLine & _
                "`USED BY`," & vbNewLine & _
                "`MANAGER`," & vbNewLine & _
                "`REMARKS`," & vbNewLine & _
                "`Entry By`,`IsPrinted`,`Printed By`,`Printed Date`,`Validity`)" & vbNewLine & _
                "VALUES" & vbNewLine & _
                "('" & lblpreview_days.Tag & "'," & vbNewLine & _
                "'" & lblpreview_itemName.Text & "'," & vbNewLine & _
                "'" & lblpreview_productionDate.Text & "'," & vbNewLine & _
                "'" & lblpreview_quantityUnit.Text & "'," & vbNewLine & _
                "'" & lblpreview_shelftLife.Text & "'," & vbNewLine & _
                "'" & lblpreview_timeIN.Text & "'," & vbNewLine & _
                "'" & lblpreview_employeeName.Text & "'," & vbNewLine & _
                "'" & lblpreview_AM.Text & "'," & vbNewLine & _
                "'" & lblpreview_PM.Text & "'," & vbNewLine & _
                "'" & lblpreview_usedBy.Text & "'," & vbNewLine & _
                "'" & lblpreview_manager.Text & "'," & vbNewLine & _
                "'" & lblpreview_remarks.Text & "'," & vbNewLine & _
                "'" & login_name & "','" & isPrinted & "'," & printedby & "," & printedDate & ",'" & validityUntil & "');" & vbNewLine

            AddForPrint(query)

            MessageBox.Show("Record successfully save, Printing can be done later.", "Record Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)

            cboitems.SelectAll()
            cboitems.Focus()
        End If
    End Sub

    Private expirationDate As DateTime = DateAndTime.Now.AddMinutes(10)
    Private Sub minusShelfLife()
        'If boolMinus Then Return
        If lblshelflifeBy.Text = "MINUTES" Then
            dtTimeIn.MaxDate = dateProduction.Value.AddMinutes(-lblshelflife.Text)
        ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
            dtTimeIn.MaxDate = dateProduction.Value.AddHours(-lblshelflife.Text)
        ElseIf lblshelflifeBy.Text = "DAY(S)" Then
            dtTimeIn.MaxDate = dateProduction.Value.AddDays(-lblshelflife.Text)
        ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
            Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
            dtTimeIn.MaxDate = dateProduction.Value.AddDays(-toDays)
        ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
            dtTimeIn.MaxDate = dateProduction.Value.AddMonths(-lblshelflife.Text)
        ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
            dtTimeIn.MaxDate = dateProduction.Value.AddYears(-lblshelflife.Text)
        ElseIf lblshelflifeBy.Text = "EOD" Then
            dtTimeIn.MaxDate = dateProduction.Value.AddHours(-24)

        End If
    End Sub
    Private Sub checkExpiration()
        If cboitems.Text = String.Empty Then Return

        displayDay()

        If dateProduction.Checked Then
            dateProduction.Value = dateProduction.Value.ToString("yyyy-MM-dd") & " " & dtTimeIn.Value.ToString("HH:mm:ss")

            If dateProduction_defaultBy = "MINUTES" Then
                expirationDate = dateProduction.Value.AddMinutes(dateProduction_defaultNo)

            ElseIf dateProduction_defaultBy = "HOUR(S)" Then
                expirationDate = dateProduction.Value.AddHours(dateProduction_defaultNo)

            ElseIf dateProduction_defaultBy = "DAY(S)" Or dateProduction_defaultBy = "EOD" Then
                expirationDate = dateProduction.Value.AddDays(dateProduction_defaultNo)

            ElseIf dateProduction_defaultBy = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(dateProduction_defaultNo) * 7.0
                expirationDate = dateProduction.Value.AddDays(toDays)

            ElseIf dateProduction_defaultBy = "MONTH(S)" Then
                expirationDate = dateProduction.Value.AddMonths(dateProduction_defaultNo)

            ElseIf dateProduction_defaultBy = "YEAR(S)" Then
                expirationDate = dateProduction.Value.AddYears(dateProduction_defaultNo)

            Else
                If lblshelflifeBy.Text = "MINUTES" Then
                    expirationDate = dtTimeIn.Value.AddMinutes(lblshelflife.Text)

                ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                    expirationDate = dtTimeIn.Value.AddHours(lblshelflife.Text)

                ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                    expirationDate = dtTimeIn.Value.AddDays(lblshelflife.Text)

                ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                    Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                    expirationDate = dtTimeIn.Value.AddDays(toDays)

                ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                    expirationDate = dtTimeIn.Value.AddMonths(lblshelflife.Text)

                ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                    expirationDate = dtTimeIn.Value.AddYears(lblshelflife.Text)

                ElseIf lblshelflifeBy.Text = "EOD" Then
                    expirationDate = dtTimeIn.Value.AddHours(24)

                End If
            End If

            Dim toExp As New DateTime
            If lblshelflifeBy.Text = "MINUTES" Then
                toExp = dtTimeIn.Value.AddMinutes(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                toExp = dtTimeIn.Value.AddHours(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                toExp = dtTimeIn.Value.AddDays(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                toExp = dtTimeIn.Value.AddDays(toDays)

            ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                toExp = dtTimeIn.Value.AddMonths(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                toExp = dtTimeIn.Value.AddYears(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "EOD" Then
                toExp = dtTimeIn.Value.AddHours(24)

            End If

            If DateAndTime.Now > expirationDate Then
expNaA:
                lblvalidity.Text = "* material / product already exprired. (BF : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper & ")"
                lblvalidity.ForeColor = Color.Red

                cboremarks.Text = "EXP. DATE : " & CDate(expirationDate).ToString("MM/dd/yyyy hh:mm tt")

                btnsavePrint.ForeColor = Color.Gray : btnsavePrint.Enabled = False
                btnsave.ForeColor = Color.Gray : btnsave.Enabled = False
                Return
            ElseIf toExp > expirationDate Then
                GoTo expNaA
            Else
                If lblshelflifeBy.Text = "EOD" Then
                    validityUntil = dtTimeIn.Value.AddHours(24).ToString("yyyy-MM-dd HH:mm:ss")
                    lblvalidity.Text = "* Valid until : END OF THE DAY (EOD)"
                Else
                    validityUntil = expirationDate.ToString("yyyy-MM-dd HH:mm:ss")
                    lblvalidity.Text = "* Valid until : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper
                End If

                lblvalidity.ForeColor = Color.Lime

                lblusedBy.Text = toExp.ToString("MM/dd/yyyy  (hh:mm tt)").ToUpper
                lblusedBy.Tag = toExp

                cboremarks.Text = "Valid until : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper

                btnsavePrint.ForeColor = Color.Blue : btnsavePrint.Enabled = True
                btnsave.ForeColor = Color.Blue : btnsave.Enabled = True
            End If

        Else
            REM CHECK IF NOT EXPIRED IN DATE
            If lblshelflifeBy.Text = "MINUTES" Then
                expirationDate = dtTimeIn.Value.AddMinutes(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
                expirationDate = dtTimeIn.Value.AddHours(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "DAY(S)" Then
                expirationDate = dtTimeIn.Value.AddDays(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
                Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
                expirationDate = dtTimeIn.Value.AddDays(toDays)

            ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
                expirationDate = dtTimeIn.Value.AddMonths(lblshelflife.Text)

            ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
                expirationDate = dtTimeIn.Value.AddYears(lblshelflife.Text)

            End If

            If DateAndTime.Now > expirationDate Then
expNaB:
                lblvalidity.Text = "* material / product already exprired. (BF : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper & ")"
                lblvalidity.ForeColor = Color.Red

                cboremarks.Text = "EXP. DATE : " & CDate(expirationDate.Add(DateAndTime.Now.Subtract(dtTimeIn.Value))).ToString("MM/dd/yyyy hh:mm tt")

                btnsavePrint.ForeColor = Color.Gray : btnsavePrint.Enabled = False
                btnsave.ForeColor = Color.Gray : btnsave.Enabled = False
            Else
                If dtTimeIn.Value > expirationDate Then
                    GoTo expNaB
                Else
                    validityUntil = expirationDate.ToString("yyyy-MM-dd HH:mm:ss")
                    lblvalidity.Text = "* Valid until : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper
                    lblvalidity.ForeColor = Color.Lime

                    cboremarks.Text = "Valid until : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper

                    btnsavePrint.ForeColor = Color.Blue : btnsavePrint.Enabled = True
                    btnsave.ForeColor = Color.Blue : btnsave.Enabled = True
                End If
            End If
        End If
    End Sub

    Private Sub setPreview_Tick(sender As Object, e As EventArgs) Handles setPreview.Tick
        setPreview.Stop()

        If lblpreview_itemName.Text <> String.Empty Then
goPrev:
            If cboitems.Text = String.Empty Then
                lblpreview_days.Text = String.Empty
                lblpreview_days.Tag = String.Empty
                lblpreview_itemName.Text = String.Empty
                lblpreview_productionDate.Text = String.Empty
                lblpreview_quantityUnit.Text = String.Empty
                lblpreview_shelftLife.Text = String.Empty
                lblpreview_timeIN.Text = String.Empty
                lblpreview_employeeName.Text = String.Empty
                lblpreview_AM.Text = lblpreview_PM.Tag
                lblpreview_PM.Text = lblpreview_PM.Tag
                lblpreview_usedBy.Text = String.Empty
                lblpreview_manager.Text = String.Empty
                lblpreview_remarks.Text = String.Empty

                cboremarks.Text = String.Empty

                btnsavePrint.Visible = False
                btnsave.Visible = False
            Else
                GoTo setPrev
            End If
        Else
setPrev:
            If cboitems.Text <> String.Empty Then
                lblpreview_days.Text = lbldays.Text
                lblpreview_days.Tag = lbldays.Tag
                lblpreview_itemName.Text = cboitems.Text
                lblpreview_productionDate.Text = dtTimeIn.Value.ToString("MM/dd/yyyy (ddd)").ToUpper
                lblpreview_quantityUnit.Text = cboquantity.Text & " " & lblunit.Text
                lblpreview_shelftLife.Text = lblshelflife.Text & " " & lblshelflifeBy.Text
                lblpreview_timeIN.Text = dtTimeIn.Value.ToString("hh:mm tt").ToUpper
                lblpreview_employeeName.Text = cboemployee.Text

                If dtTimeIn.Value.ToString("tt").ToUpper = "AM" Then
                    lblpreview_AM.Text = lblpreview_AM.Tag
                    lblpreview_PM.Text = lblpreview_PM.Tag
                Else
                    lblpreview_AM.Text = lblpreview_PM.Tag
                    lblpreview_PM.Text = lblpreview_AM.Tag
                End If

                lblpreview_usedBy.Text = lblusedBy.Text
                lblpreview_manager.Text = cbomanager.Text
                lblpreview_remarks.Text = cboremarks.Text

                Call checkExpiration()

                If lblvalidity.ForeColor = Color.Lime Then

                    btnsavePrint.Visible = PrinterExists()
                    btnsave.Visible = True
                Else
                    btnsavePrint.Visible = False
                    btnsave.Visible = False
                End If
            Else
                GoTo goPrev
            End If
        End If
        setPreview.Start()
    End Sub

    Private Sub cboitems_KeyDown(sender As Object, e As KeyEventArgs) Handles dtTimeIn.KeyDown, dateProduction.KeyDown, cboremarks.KeyDown, cboquantity.KeyDown, cbomanager.KeyDown, cboitems.KeyDown, cboemployee.KeyDown
        If e.KeyCode = Keys.F5 Then
            dtTimeIn.Value = DateAndTime.Now
            cboitems.Text = String.Empty
            cboitems.Focus()
        ElseIf e.KeyCode = Keys.F1 Then
            If btnsavePrint.Visible Then
                saveRecord(1)
            End If
        ElseIf e.KeyCode = Keys.F2 Then
            If btnsave.Visible Then
                saveRecord(0)
            End If
        End If
    End Sub

    Private Sub tfocus_Tick(sender As Object, e As EventArgs) Handles tfocus.Tick
        tfocus.Stop()
        cboitems.Focus()
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        cboitems.Text = String.Empty
        cboitems.Focus()
    End Sub
End Class