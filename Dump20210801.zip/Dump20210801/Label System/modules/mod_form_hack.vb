﻿Module mod_form_hack
	Public Sub roundCorners(obj As Form, ByRef bColor As Color)

		obj.FormBorderStyle = FormBorderStyle.None
		obj.BackColor = bColor


		Dim DGP As New Drawing2D.GraphicsPath
		DGP.StartFigure()
		'top left corner
		DGP.AddArc(New Rectangle(0, 0, 40, 40), 180, 90)
		DGP.AddLine(40, 0, obj.Width - 40, 0)

		'top right corner
		DGP.AddArc(New Rectangle(obj.Width - 40, 0, 40, 40), -90, 90)
		DGP.AddLine(obj.Width, 40, obj.Width, obj.Height - 40)

		'buttom right corner
		DGP.AddArc(New Rectangle(obj.Width - 40, obj.Height - 40, 40, 40), 0, 90)
		DGP.AddLine(obj.Width - 40, obj.Height, 40, obj.Height)

		'buttom left corner
		DGP.AddArc(New Rectangle(0, obj.Height - 40, 40, 40), 90, 90)
		DGP.CloseFigure()

		obj.Region = New Region(DGP)
	End Sub
	Public Sub buttonBorderRadius(ByRef buttonObj As Object, ByVal borderRadiusINT As Integer)
		Dim p As New Drawing2D.GraphicsPath()
		p.StartFigure()
		'TOP LEFT CORNER
		p.AddArc(New Rectangle(0, 0, borderRadiusINT, borderRadiusINT), 180, 90)
		p.AddLine(40, 0, buttonObj.Width - borderRadiusINT, 0)
		'TOP RIGHT CORNER
		p.AddArc(New Rectangle(buttonObj.Width - borderRadiusINT, 0, borderRadiusINT, borderRadiusINT), -90, 90)
		p.AddLine(buttonObj.Width, 40, buttonObj.Width, buttonObj.Height - borderRadiusINT)
		'BOTTOM RIGHT CORNER
		p.AddArc(New Rectangle(buttonObj.Width - borderRadiusINT, buttonObj.Height - borderRadiusINT, borderRadiusINT, borderRadiusINT), 0, 90)
		p.AddLine(buttonObj.Width - borderRadiusINT, buttonObj.Height, borderRadiusINT, buttonObj.Height)
		'BOTTOM LEFT CORNER
		p.AddArc(New Rectangle(0, buttonObj.Height - borderRadiusINT, borderRadiusINT, borderRadiusINT), 90, 90)
		p.CloseFigure()
		buttonObj.Region = New Region(p)
	End Sub
End Module
