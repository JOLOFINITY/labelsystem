﻿Module mod_userlogin
	Private Sub _saveDATA(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys")
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()
				Using Comm = New MySqlCommand(query, Connection)
					Comm.ExecuteNonQuery()
				End Using
				Connection.Close()
			End Using
		Catch ex As Exception
			Call createErrorLogs(ex, query, connectionString)
		End Try
	End Sub
	Private Function _createTable(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys") As DataTable
		Dim temp As New DataTable
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()
				Using dA = New MySqlDataAdapter(query, Connection)
					Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
				End Using
				Connection.Close()
			End Using
		Catch ex As Exception
			Call createErrorLogs(ex, query, connectionString)
		End Try
		Return temp
	End Function


	Public login_access As String = String.Empty
	Public login_username As String = String.Empty
	Public login_name As String = String.Empty

	Public Function getUser(ByRef userName As String) As DataTable
		Dim result As New DataTable("result")

		result = _createTable( _
			"SELECT `ID`,`Access`, " & vbNewLine & _
			"`Name`, " & vbNewLine & _
			"`Username`,`Password`, " & vbNewLine & _
			"`Security Question 1`,`Answer Question 1`, " & vbNewLine & _
			"`Security Question 2`,`Answer Question 2`, " & vbNewLine & _
			"`Security Question 3`,`Answer Question 3`, " & vbNewLine & _
			"`Active` " & vbNewLine & _
			"FROM `t_user` " & vbNewLine & _
			"WHERE `Username` = '" & userName & "';")

		Return result
	End Function
	Public Sub add_newUser( _
			ByRef nameOfEmployee As String, _
			ByRef username As String, ByRef password As String, _
			ByRef question1 As String, ByRef answer1 As String, _
			ByRef question2 As String, ByRef answer2 As String, _
			ByRef question3 As String, ByRef answer3 As String)

		_saveDATA( _
			"INSERT INTO `t_user` " & vbNewLine & _
			"(`Name`, " & vbNewLine & _
			"`Username`,`Password`, " & vbNewLine & _
			"`Security Question 1`,`Answer Question 1`, " & vbNewLine & _
			"`Security Question 2`,`Answer Question 2`, " & vbNewLine & _
			"`Security Question 3`,`Answer Question 3`) " & vbNewLine & _
			"VALUES " & vbNewLine & _
			"('" & nameOfEmployee & "', " & vbNewLine & _
			"'" & username & "','" & password & "', " & vbNewLine & _
			"'" & question1 & "','" & answer1 & "', " & vbNewLine & _
			"'" & question2 & "','" & answer2 & "', " & vbNewLine & _
			"'" & question3 & "','" & answer3 & "');")

		MessageBox.Show("User added, pls. inform your superior to activate your account.", "Record Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)

	End Sub

	Public Sub accountUpdate(ByRef query As String)
		_saveDATA(query)
	End Sub

	Public Sub log_User(ByRef strAccess As String, ByRef username As String)
		_saveDATA( _
			"INSERT INTO `t_logins` " & vbNewLine & _
			"(`Access`,`Username`,`Terminal No`) " & vbNewLine & _
			"VALUES('" & strAccess & "','" & username & "','" & My.Computer.Name & "');")
	End Sub
End Module
