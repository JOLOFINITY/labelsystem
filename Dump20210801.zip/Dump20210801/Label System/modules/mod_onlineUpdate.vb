﻿Imports System.IO
Imports System.Net
Module mod_onlineUpdate
	Public version As String = String.Empty
	Public updateVersion As String = String.Empty
	Public Sub initializedUpdater()
		If Directory.Exists(Application.StartupPath & "\_") = False Then Directory.CreateDirectory(Application.StartupPath & "\_")

		If File.Exists(Application.StartupPath & "\version.dll") = False Then IO.File.WriteAllText(Application.StartupPath & "\version.dll", "19880529.529") : Application.DoEvents()

		version = IO.File.ReadAllText(Application.StartupPath & "\version.dll")
	End Sub

	Public Function checkUpdate(ByRef wb As WebBrowser, ByRef projectName As String) As Boolean
		Try
			Dim address As String = "https://raw.githubusercontent.com/JOLOFINITY/" & projectName & "/main/README.md"
			wb.Navigate(address)

			Return True
		Catch ex As Exception
			Return False
		End Try
	End Function

	Public Sub updateFile(ByRef execName As String)
		Dim fileName = Application.StartupPath & "\updater.bat"

		Using sw As New StreamWriter(fileName)
			sw.WriteLine("@ECHO OFF")
			sw.WriteLine("")
			sw.WriteLine("TITLE Programmer In-Charge : Jose Lorenzo Punto (Sir JOLo)")
			sw.WriteLine("")
			sw.WriteLine("SETLOCAL")
			sw.WriteLine("CALL :setESC")
			sw.WriteLine("")
			sw.WriteLine("CLS")
			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m  S Y S T E M   C A L L   :   S Y S T E M   U P D A T E R   v . 1  %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m  P L E A S E   D O N ' T   C L O S E   T H I S   W I N D O W .  %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m Forcely Terminating " & "" & execName & "" & " for Updating!! %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")
			sw.WriteLine("TASKKILL /F /IM """ & "" & execName & "" & """ /T")
			sw.WriteLine("ECHO %ESC%[101;93m P R O C E S S   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("DEL """ & "" & execName & "" & """ ")
			sw.WriteLine("ECHO %ESC%[101;93m D E L E T I N G   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 2")

			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m U P D A T E R   W I L L   C O P Y   S O M E   F I L E S . .  %ESC%[1m")

			For Each f In Directory.GetFiles(Application.StartupPath & "\_\")
				Dim fileC As String = f.Split("\")(f.Split("\").Length - 1)

				sw.WriteLine("xcopy """ & f & """ """ & Application.StartupPath & "\" & "" & """ /S /Y")
			Next

			sw.WriteLine("TIMEOUT 5")

			sw.WriteLine("REN update.zip """ & "" & execName & "" & """ ")
			sw.WriteLine("ECHO %ESC%[101;93m D E L E T I N G   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("")
			sw.WriteLine("ECHO %ESC%[101;93m EXECUTING PROGRAM, PLEASE WAIT... %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("")

			sw.WriteLine("DEL """ & "" & Application.StartupPath & "\_\update.zip" & "" & """ ")
			sw.WriteLine("ECHO %ESC%[101;93m D E L E T I N G   C O M P L E T E D ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("echo " & updateVersion & " > version.dll")
			sw.WriteLine("ECHO %ESC%[101;93m S A V I N G   V E R S I O N   U P D A T E ! . . %ESC%[1m")
			sw.WriteLine("TIMEOUT 1")

			sw.WriteLine("if not exist """ & "" & execName & "" & """ (")
			sw.WriteLine("msg " & My.User.Name & " /SERVER:" & My.Computer.Name & " /time:3 ""Program not found or failed to Copy, Call Local I.T. to fix the Problem!!!""")
			sw.WriteLine("GOTO EXIT0")
			sw.WriteLine(")")
			sw.WriteLine("")

			sw.WriteLine("TIMEOUT 1")
			sw.WriteLine("start /b """" cmd /c del ""%~f0""&exit /b")
			sw.WriteLine("")
			sw.WriteLine(":setESC")
			sw.WriteLine("for /F ""tokens=1,2 delims=#"" %%a in ('""prompt #$H#$E# & echo on & for %%b in (1) do rem""') do (")
			sw.WriteLine("  set ESC=%%b")
			sw.WriteLine("  exit /B 0")
			sw.WriteLine(")")
			sw.WriteLine(":EXIT0")
			sw.WriteLine("exit /B 0")
		End Using

		Dim start As New ProcessStartInfo
		start.FileName = fileName
		start.WindowStyle = ProcessWindowStyle.Normal
		start.CreateNoWindow = False

		Process.Start(start)
		End
	End Sub
	Public Sub getUpdate(ByRef projectName As String)
		'Using p As Process = New Process()
		'	Dim pi As ProcessStartInfo = New ProcessStartInfo()
		'	pi.Arguments = "https://raw.githubusercontent.com/JOLOFINITY/" & projectName & "/main/update.zip --output """ & Application.StartupPath & "\_\update.zip" & """"
		'	pi.FileName = "curl.exe"
		'	pi.CreateNoWindow = False

		'	p.StartInfo = pi
		'	p.StartInfo.CreateNoWindow = False
		'	p.Start()
		'End Using

		Try
			DownloadFileWithRedirect("https://raw.githubusercontent.com/JOLOFINITY/" & projectName & "/main/update.zip", Application.StartupPath & "\_\update.zip")
		Catch ex As Exception
			MessageBox.Show("An error occurred:" & Environment.NewLine & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
		End Try
	End Sub
	''' <summary>
	''' Downloads a file from an URL and allows the page to redirect you.
	''' </summary>
	''' <param name="Url">The URL to the file to download.</param>
	''' <param name="TargetPath">The path and file name to download the file to.</param>
	''' <param name="AllowedRedirections">The maximum allowed amount of redirections (default = 32).</param>
	''' <param name="DownloadBufferSize">The amount of bytes of the download buffer (default = 4096 = 4 KB).</param>
	''' <remarks></remarks>
	Private Sub DownloadFileWithRedirect(ByVal Url As String, _
										 ByVal TargetPath As String, _
										 Optional ByVal AllowedRedirections As Integer = 32, _
										 Optional ByVal DownloadBufferSize As Integer = 4096)
		'Create the request.
		Dim Request As HttpWebRequest = DirectCast(WebRequest.Create(Url), HttpWebRequest)
		Request.Timeout = 10000	'10 second timeout.
		Request.MaximumAutomaticRedirections = AllowedRedirections
		Request.AllowAutoRedirect = True

		'Get the response from the server.
		Using Response As HttpWebResponse = DirectCast(Request.GetResponse(), HttpWebResponse)
			'Get the stream to read the response.
			Using ResponseStream As Stream = Response.GetResponseStream()

				'Declare a download buffer.
				Dim Buffer() As Byte = New Byte(DownloadBufferSize - 1) {}
				Dim ReadBytes As Integer = 0

				'Create the target file and open a file stream to it.
				Using TargetFileStream As New FileStream(TargetPath, FileMode.Create, FileAccess.Write, FileShare.None)

					'Start reading into the buffer.
					ReadBytes = ResponseStream.Read(Buffer, 0, Buffer.Length)

					'Loop while there's something to read.
					While ReadBytes > 0
						'Write the read bytes to the file.
						TargetFileStream.Write(Buffer, 0, ReadBytes)

						'Read more into the buffer.
						ReadBytes = ResponseStream.Read(Buffer, 0, Buffer.Length)
					End While

				End Using

			End Using
		End Using
	End Sub
End Module
