﻿Module mod_user_maintenance
	Private Sub _saveDATA(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys")
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()
				Using Comm = New MySqlCommand(query, Connection)
					Comm.ExecuteNonQuery()
				End Using
				Connection.Close()
			End Using
		Catch ex As Exception
			Call createErrorLogs(ex, query, connectionString)
		End Try
	End Sub
	Private Function _createTable(ByRef query As String, Optional ByRef connectionString As String = "server=127.0.0.1;user id=endUser;password=endUser;persistsecurityinfo=True;database=db_lblsys") As DataTable
		Dim temp As New DataTable
		Try
			Using Connection = New MySqlConnection(connectionString)
				Connection.Open()
				Using dA = New MySqlDataAdapter(query, Connection)
					Dim dSet As New DataSet : dA.Fill(dSet, "Result") : temp = dSet.Tables("Result")
				End Using
				Connection.Close()
			End Using
		Catch ex As Exception
			Call createErrorLogs(ex, query, connectionString)
		End Try
		Return temp
	End Function

	Public Sub getUserlist(ByRef grid As DataGridView)
		With grid
			Dim result = _createTable( _
				"SELECT " & vbNewLine & _
				"`Access`,`Name`,`Username`, " & vbNewLine & _
				"CASE WHEN `Active` = 0 THEN 'NO' ELSE 'YES' END `Active`,`ID` " & vbNewLine & _
				"FROM `t_user` " & vbNewLine & _
				"WHERE `Username` <> '" & login_username & "' " & vbNewLine & _
				"ORDER BY `Access` ASC , `ID` ASC;")

			.DataSource = result

			.Columns(0).Width = 60
			.Columns(1).Width = 80
			.Columns(2).Width = 450
			.Columns(3).Width = 300
			.Columns(4).Width = 80
			.Columns(5).Width = 80
			.ClearSelection()
		End With
	End Sub
	Public Sub deleteUser(ByRef username As String)
		_saveDATA("DELETE FROM `t_user` WHERE `Username` = '" & username & "';")
	End Sub
	Public Sub activateUsers()
		_saveDATA("UPDATE `t_user` SET `Active` = 1 WHERE `Active` = 0;")
	End Sub
End Module
