﻿Imports System.Runtime.InteropServices
Public Class vw_2_management
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub vw_3_registration_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
		Dispose()
	End Sub

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, panelHeader.MouseDown, Label2.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub


#End Region
	Private Sub vw_2_management_Shown(sender As Object, e As EventArgs) Handles Me.Shown
		roundCorners(Me, Color.DimGray)

		Call comboList(cboq1)
		Call comboList(cboq2)
		Call comboList(cboq3)

		Dim user = getUser(login_username)
		If user.Rows.Count >= 1 Then
			txtname.Text = user.Rows(0)("Name").ToString
			txtusername.Text = user.Rows(0)("Username").ToString

			cboq1.Text = user.Rows(0)("Security Question 1").ToString
			cboa1.Text = user.Rows(0)("Answer Question 1").ToString

			cboq2.Text = user.Rows(0)("Security Question 2").ToString
			cboa2.Text = user.Rows(0)("Answer Question 2").ToString

			cboq3.Text = user.Rows(0)("Security Question 3").ToString
			cboa3.Text = user.Rows(0)("Answer Question 3").ToString
		End If
	End Sub

	Private Sub llblclose_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblclose.LinkClicked
		Dispose()
	End Sub

	Private Sub llblregister_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblregister.LinkClicked
		If txtname.Text.Length <= 3 Then
			txtname.SelectAll() : txtname.Focus()

		Else
			Dim update As String = _
				"UPDATE `t_user` " & vbNewLine & _
				"SET " & vbNewLine & _
				"`Security Question 1` = '" & cboq1.Text & "', " & vbNewLine & _
				"`Answer Question 1` = '" & cboa1.Text & "', " & vbNewLine & _
				"`Security Question 2` = '" & cboq2.Text & "', " & vbNewLine & _
				"`Answer Question 2` = '" & cboa2.Text & "', " & vbNewLine & _
				"`Security Question 3` = '" & cboq3.Text & "', " & vbNewLine & _
				"`Answer Question 3` = '" & cboa3.Text & "', " & vbNewLine

			If (txtpassword1.Text <> String.Empty And txtpassword2.Text <> String.Empty) Then
				If txtpassword1.Text = txtpassword2.Text Then
					update &= "`Password` = '" & txtpassword2.Text & "', " & vbNewLine
				End If
			End If

			update &= "`Name` = '" & txtname.Text & "' " & vbNewLine
			update &= "WHERE `Username` = '" & txtusername.Text & "';"

			Call accountUpdate(update)

			txtpassword1.Clear()
			txtpassword2.Clear()

			MessageBox.Show("User Account successfully Update..", "Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)

			txtname.Focus()
		End If
	End Sub

	Private Sub vw_2_management_Load(sender As Object, e As EventArgs) Handles MyBase.Load

	End Sub
End Class