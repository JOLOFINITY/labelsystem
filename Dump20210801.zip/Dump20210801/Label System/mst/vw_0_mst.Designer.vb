﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_0_mst
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pmain = New System.Windows.Forms.Panel()
        Me.lblbuildNo = New System.Windows.Forms.Label()
        Me.lblheaderSub = New System.Windows.Forms.Label()
        Me.llblhide = New System.Windows.Forms.LinkLabel()
        Me.llblmaximized = New System.Windows.Forms.LinkLabel()
        Me.lblclose = New System.Windows.Forms.LinkLabel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblheader = New System.Windows.Forms.Label()
        Me.pmain.SuspendLayout()
        Me.SuspendLayout()
        '
        'pmain
        '
        Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pmain.BackColor = System.Drawing.Color.White
        Me.pmain.Controls.Add(Me.lblbuildNo)
        Me.pmain.Controls.Add(Me.lblheaderSub)
        Me.pmain.Controls.Add(Me.llblhide)
        Me.pmain.Controls.Add(Me.llblmaximized)
        Me.pmain.Controls.Add(Me.lblclose)
        Me.pmain.Controls.Add(Me.Label1)
        Me.pmain.Controls.Add(Me.lblheader)
        Me.pmain.Location = New System.Drawing.Point(2, 5)
        Me.pmain.Name = "pmain"
        Me.pmain.Size = New System.Drawing.Size(922, 683)
        Me.pmain.TabIndex = 0
        '
        'lblbuildNo
        '
        Me.lblbuildNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblbuildNo.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbuildNo.Location = New System.Drawing.Point(786, 47)
        Me.lblbuildNo.Name = "lblbuildNo"
        Me.lblbuildNo.Size = New System.Drawing.Size(128, 20)
        Me.lblbuildNo.TabIndex = 7
        Me.lblbuildNo.Text = "Build.210713.01"
        Me.lblbuildNo.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'lblheaderSub
        '
        Me.lblheaderSub.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheaderSub.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblheaderSub.Location = New System.Drawing.Point(35, 47)
        Me.lblheaderSub.Name = "lblheaderSub"
        Me.lblheaderSub.Size = New System.Drawing.Size(745, 20)
        Me.lblheaderSub.TabIndex = 5
        Me.lblheaderSub.Text = "• Sub Name or Functions / Procedures"
        Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
        '
        'llblhide
        '
        Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblhide.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.llblhide.Location = New System.Drawing.Point(795, 9)
        Me.llblhide.Name = "llblhide"
        Me.llblhide.Size = New System.Drawing.Size(37, 25)
        Me.llblhide.TabIndex = 2
        Me.llblhide.TabStop = True
        Me.llblhide.Text = "◣"
        Me.llblhide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'llblmaximized
        '
        Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.llblmaximized.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.llblmaximized.Location = New System.Drawing.Point(836, 9)
        Me.llblmaximized.Name = "llblmaximized"
        Me.llblmaximized.Size = New System.Drawing.Size(37, 25)
        Me.llblmaximized.TabIndex = 1
        Me.llblmaximized.TabStop = True
        Me.llblmaximized.Text = "☐"
        Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblclose
        '
        Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblclose.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
        Me.lblclose.Location = New System.Drawing.Point(877, 9)
        Me.lblclose.Name = "lblclose"
        Me.lblclose.Size = New System.Drawing.Size(37, 25)
        Me.lblclose.TabIndex = 1
        Me.lblclose.TabStop = True
        Me.lblclose.Text = "✕"
        Me.lblclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.BackColor = System.Drawing.Color.DimGray
        Me.Label1.Location = New System.Drawing.Point(0, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(924, 6)
        Me.Label1.TabIndex = 0
        '
        'lblheader
        '
        Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblheader.Location = New System.Drawing.Point(10, 9)
        Me.lblheader.Name = "lblheader"
        Me.lblheader.Size = New System.Drawing.Size(777, 60)
        Me.lblheader.TabIndex = 6
        Me.lblheader.Text = "NAME OF FORM / VIEW"
        '
        'vw_0_mst
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.ClientSize = New System.Drawing.Size(926, 690)
        Me.Controls.Add(Me.pmain)
        Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "vw_0_mst"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ITEM / PRODUCT MASTER"
        Me.pmain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pmain As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
    Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
    Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
    Friend WithEvents lblbuildNo As System.Windows.Forms.Label
    Friend WithEvents lblheaderSub As System.Windows.Forms.Label
    Friend WithEvents lblheader As System.Windows.Forms.Label
End Class
