﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_labelHistory
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Me.pmain = New System.Windows.Forms.Panel()
		Me.btncommand = New System.Windows.Forms.Button()
		Me.txtsearch = New System.Windows.Forms.TextBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.rbdeleted = New System.Windows.Forms.RadioButton()
		Me.rbprinted = New System.Windows.Forms.RadioButton()
		Me.rbprint = New System.Windows.Forms.RadioButton()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.griditemList = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
		Me.Column2 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
		Me.DELETE = New System.Windows.Forms.DataGridViewCheckBoxColumn()
		Me.lblbuildNo = New System.Windows.Forms.Label()
		Me.lblheaderSub = New System.Windows.Forms.Label()
		Me.llblhide = New System.Windows.Forms.LinkLabel()
		Me.llblmaximized = New System.Windows.Forms.LinkLabel()
		Me.lblclose = New System.Windows.Forms.LinkLabel()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.lblheader = New System.Windows.Forms.Label()
		Me.llblprint = New System.Windows.Forms.LinkLabel()
		Me.llblprinted = New System.Windows.Forms.LinkLabel()
		Me.pmain.SuspendLayout()
		Me.Panel1.SuspendLayout()
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'pmain
		'
		Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.White
		Me.pmain.Controls.Add(Me.llblprinted)
		Me.pmain.Controls.Add(Me.llblprint)
		Me.pmain.Controls.Add(Me.btncommand)
		Me.pmain.Controls.Add(Me.txtsearch)
		Me.pmain.Controls.Add(Me.Label3)
		Me.pmain.Controls.Add(Me.Label2)
		Me.pmain.Controls.Add(Me.rbdeleted)
		Me.pmain.Controls.Add(Me.rbprinted)
		Me.pmain.Controls.Add(Me.rbprint)
		Me.pmain.Controls.Add(Me.Panel1)
		Me.pmain.Controls.Add(Me.lblbuildNo)
		Me.pmain.Controls.Add(Me.lblheaderSub)
		Me.pmain.Controls.Add(Me.llblhide)
		Me.pmain.Controls.Add(Me.llblmaximized)
		Me.pmain.Controls.Add(Me.lblclose)
		Me.pmain.Controls.Add(Me.Label1)
		Me.pmain.Controls.Add(Me.lblheader)
		Me.pmain.Location = New System.Drawing.Point(2, 5)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(922, 704)
		Me.pmain.TabIndex = 0
		'
		'btncommand
		'
		Me.btncommand.Location = New System.Drawing.Point(564, 130)
		Me.btncommand.Name = "btncommand"
		Me.btncommand.Size = New System.Drawing.Size(275, 28)
		Me.btncommand.TabIndex = 20
		Me.btncommand.Text = "PRINT / DELETE"
		Me.btncommand.UseVisualStyleBackColor = True
		'
		'txtsearch
		'
		Me.txtsearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtsearch.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtsearch.Location = New System.Drawing.Point(159, 131)
		Me.txtsearch.MaxLength = 32
		Me.txtsearch.Name = "txtsearch"
		Me.txtsearch.Size = New System.Drawing.Size(399, 26)
		Me.txtsearch.TabIndex = 19
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Location = New System.Drawing.Point(56, 133)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(100, 22)
		Me.Label3.TabIndex = 18
		Me.Label3.Text = "SEARCH :"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(62, 95)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(94, 22)
		Me.Label2.TabIndex = 18
		Me.Label2.Text = "STATUS :"
		'
		'rbdeleted
		'
		Me.rbdeleted.AutoSize = True
		Me.rbdeleted.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.rbdeleted.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rbdeleted.Location = New System.Drawing.Point(677, 95)
		Me.rbdeleted.Name = "rbdeleted"
		Me.rbdeleted.Size = New System.Drawing.Size(100, 22)
		Me.rbdeleted.TabIndex = 17
		Me.rbdeleted.Text = "DELETED"
		Me.rbdeleted.UseVisualStyleBackColor = True
		'
		'rbprinted
		'
		Me.rbprinted.AutoSize = True
		Me.rbprinted.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.rbprinted.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rbprinted.Location = New System.Drawing.Point(435, 95)
		Me.rbprinted.Name = "rbprinted"
		Me.rbprinted.Size = New System.Drawing.Size(93, 22)
		Me.rbprinted.TabIndex = 17
		Me.rbprinted.Text = "PRINTED"
		Me.rbprinted.UseVisualStyleBackColor = True
		'
		'rbprint
		'
		Me.rbprint.AutoSize = True
		Me.rbprint.FlatStyle = System.Windows.Forms.FlatStyle.Flat
		Me.rbprint.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rbprint.Location = New System.Drawing.Point(162, 95)
		Me.rbprint.Name = "rbprint"
		Me.rbprint.Size = New System.Drawing.Size(133, 22)
		Me.rbprint.TabIndex = 17
		Me.rbprint.Text = "FOR PRINTING"
		Me.rbprint.UseVisualStyleBackColor = True
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.Controls.Add(Me.griditemList)
		Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Panel1.Location = New System.Drawing.Point(3, 163)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(916, 538)
		Me.Panel1.TabIndex = 16
		'
		'griditemList
		'
		Me.griditemList.AllowUserToAddRows = False
		Me.griditemList.AllowUserToDeleteRows = False
		Me.griditemList.AllowUserToResizeColumns = False
		Me.griditemList.AllowUserToResizeRows = False
		Me.griditemList.BackgroundColor = System.Drawing.Color.White
		Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
		Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle7.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
		Me.griditemList.ColumnHeadersHeight = 36
		Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.DELETE})
		DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle8.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.griditemList.DefaultCellStyle = DataGridViewCellStyle8
		Me.griditemList.Dock = System.Windows.Forms.DockStyle.Fill
		Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.griditemList.EnableHeadersVisualStyles = False
		Me.griditemList.Location = New System.Drawing.Point(0, 0)
		Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
		Me.griditemList.MultiSelect = False
		Me.griditemList.Name = "griditemList"
		Me.griditemList.ReadOnly = True
		Me.griditemList.RowHeadersVisible = False
		Me.griditemList.RowTemplate.Height = 28
		Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.griditemList.ShowCellErrors = False
		Me.griditemList.ShowCellToolTips = False
		Me.griditemList.ShowEditingIcon = False
		Me.griditemList.ShowRowErrors = False
		Me.griditemList.Size = New System.Drawing.Size(916, 538)
		Me.griditemList.TabIndex = 0
		'
		'Column1
		'
		Me.Column1.HeaderText = "SELECT"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		Me.Column1.Width = 80
		'
		'Column2
		'
		Me.Column2.HeaderText = "PRINT"
		Me.Column2.Name = "Column2"
		Me.Column2.ReadOnly = True
		Me.Column2.Width = 60
		'
		'DELETE
		'
		Me.DELETE.HeaderText = "DELETE"
		Me.DELETE.Name = "DELETE"
		Me.DELETE.ReadOnly = True
		Me.DELETE.Width = 65
		'
		'lblbuildNo
		'
		Me.lblbuildNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblbuildNo.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblbuildNo.Location = New System.Drawing.Point(786, 47)
		Me.lblbuildNo.Name = "lblbuildNo"
		Me.lblbuildNo.Size = New System.Drawing.Size(128, 20)
		Me.lblbuildNo.TabIndex = 7
		Me.lblbuildNo.Text = "Build.210720.01"
		Me.lblbuildNo.TextAlign = System.Drawing.ContentAlignment.BottomRight
		'
		'lblheaderSub
		'
		Me.lblheaderSub.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheaderSub.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.lblheaderSub.Location = New System.Drawing.Point(35, 47)
		Me.lblheaderSub.Name = "lblheaderSub"
		Me.lblheaderSub.Size = New System.Drawing.Size(745, 20)
		Me.lblheaderSub.TabIndex = 5
		Me.lblheaderSub.Text = "• Print • Reprint • Delete Label(s)"
		Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
		'
		'llblhide
		'
		Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblhide.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblhide.Location = New System.Drawing.Point(795, 9)
		Me.llblhide.Name = "llblhide"
		Me.llblhide.Size = New System.Drawing.Size(37, 25)
		Me.llblhide.TabIndex = 2
		Me.llblhide.TabStop = True
		Me.llblhide.Text = "◣"
		Me.llblhide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.llblhide.Visible = False
		'
		'llblmaximized
		'
		Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblmaximized.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblmaximized.Location = New System.Drawing.Point(836, 9)
		Me.llblmaximized.Name = "llblmaximized"
		Me.llblmaximized.Size = New System.Drawing.Size(37, 25)
		Me.llblmaximized.TabIndex = 1
		Me.llblmaximized.TabStop = True
		Me.llblmaximized.Text = "☐"
		Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.llblmaximized.Visible = False
		'
		'lblclose
		'
		Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblclose.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblclose.Location = New System.Drawing.Point(877, 9)
		Me.lblclose.Name = "lblclose"
		Me.lblclose.Size = New System.Drawing.Size(37, 25)
		Me.lblclose.TabIndex = 1
		Me.lblclose.TabStop = True
		Me.lblclose.Text = "✕"
		Me.lblclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label1
		'
		Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label1.BackColor = System.Drawing.Color.DimGray
		Me.Label1.Location = New System.Drawing.Point(0, 72)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(924, 6)
		Me.Label1.TabIndex = 0
		'
		'lblheader
		'
		Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheader.Location = New System.Drawing.Point(10, 9)
		Me.lblheader.Name = "lblheader"
		Me.lblheader.Size = New System.Drawing.Size(777, 60)
		Me.lblheader.TabIndex = 6
		Me.lblheader.Text = "PRINT LABEL HISTORY"
		'
		'llblprint
		'
		Me.llblprint.AutoSize = True
		Me.llblprint.Font = New System.Drawing.Font("Arial", 12.0!)
		Me.llblprint.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblprint.Location = New System.Drawing.Point(302, 97)
		Me.llblprint.Name = "llblprint"
		Me.llblprint.Size = New System.Drawing.Size(97, 18)
		Me.llblprint.TabIndex = 21
		Me.llblprint.TabStop = True
		Me.llblprint.Text = "CHECK ALL"
		'
		'llblprinted
		'
		Me.llblprinted.AutoSize = True
		Me.llblprinted.Font = New System.Drawing.Font("Arial", 12.0!)
		Me.llblprinted.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblprinted.Location = New System.Drawing.Point(535, 97)
		Me.llblprinted.Name = "llblprinted"
		Me.llblprinted.Size = New System.Drawing.Size(97, 18)
		Me.llblprinted.TabIndex = 21
		Me.llblprinted.TabStop = True
		Me.llblprinted.Text = "CHECK ALL"
		'
		'vw_4_labelHistory
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.RoyalBlue
		Me.ClientSize = New System.Drawing.Size(926, 711)
		Me.Controls.Add(Me.pmain)
		Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_4_labelHistory"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ITEM / PRODUCT MASTER"
		Me.pmain.ResumeLayout(False)
		Me.pmain.PerformLayout()
		Me.Panel1.ResumeLayout(False)
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
	Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
	Friend WithEvents lblbuildNo As System.Windows.Forms.Label
	Friend WithEvents lblheaderSub As System.Windows.Forms.Label
	Friend WithEvents lblheader As System.Windows.Forms.Label
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents griditemList As System.Windows.Forms.DataGridView
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents rbprint As System.Windows.Forms.RadioButton
	Friend WithEvents rbprinted As System.Windows.Forms.RadioButton
	Friend WithEvents rbdeleted As System.Windows.Forms.RadioButton
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents txtsearch As System.Windows.Forms.TextBox
	Friend WithEvents btncommand As System.Windows.Forms.Button
	Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
	Friend WithEvents Column2 As System.Windows.Forms.DataGridViewCheckBoxColumn
	Friend WithEvents DELETE As System.Windows.Forms.DataGridViewCheckBoxColumn
	Friend WithEvents llblprint As System.Windows.Forms.LinkLabel
	Friend WithEvents llblprinted As System.Windows.Forms.LinkLabel
End Class
