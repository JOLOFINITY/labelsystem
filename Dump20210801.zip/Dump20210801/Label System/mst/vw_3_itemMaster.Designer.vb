﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_itemMaster
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Me.pmain = New System.Windows.Forms.Panel()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.cbautoSearch = New System.Windows.Forms.CheckBox()
		Me.llblrefresh = New System.Windows.Forms.LinkLabel()
		Me.llbladdSave = New System.Windows.Forms.LinkLabel()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.griditemList = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
		Me.lblbuildNo = New System.Windows.Forms.Label()
		Me.lblheaderSub = New System.Windows.Forms.Label()
		Me.llblhide = New System.Windows.Forms.LinkLabel()
		Me.llblmaximized = New System.Windows.Forms.LinkLabel()
		Me.lblclose = New System.Windows.Forms.LinkLabel()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.lblheader = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.cbostorage = New Label_System.modComboBox()
		Me.cbounit = New Label_System.modComboBox()
		Me.cboshelflifeBy = New Label_System.modComboBox()
		Me.cboshelflife = New Label_System.modComboBox()
		Me.cbocondition = New Label_System.modComboBox()
		Me.cboitemMat = New Label_System.modComboBox()
		Me.pmain.SuspendLayout()
		Me.Panel1.SuspendLayout()
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'pmain
		'
		Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.White
		Me.pmain.Controls.Add(Me.Label5)
		Me.pmain.Controls.Add(Me.cbautoSearch)
		Me.pmain.Controls.Add(Me.llblrefresh)
		Me.pmain.Controls.Add(Me.llbladdSave)
		Me.pmain.Controls.Add(Me.Panel1)
		Me.pmain.Controls.Add(Me.lblbuildNo)
		Me.pmain.Controls.Add(Me.lblheaderSub)
		Me.pmain.Controls.Add(Me.llblhide)
		Me.pmain.Controls.Add(Me.llblmaximized)
		Me.pmain.Controls.Add(Me.lblclose)
		Me.pmain.Controls.Add(Me.Label7)
		Me.pmain.Controls.Add(Me.Label1)
		Me.pmain.Controls.Add(Me.Label4)
		Me.pmain.Controls.Add(Me.Label6)
		Me.pmain.Controls.Add(Me.lblheader)
		Me.pmain.Controls.Add(Me.Label3)
		Me.pmain.Controls.Add(Me.Label2)
		Me.pmain.Controls.Add(Me.cbostorage)
		Me.pmain.Controls.Add(Me.cbounit)
		Me.pmain.Controls.Add(Me.cboshelflifeBy)
		Me.pmain.Controls.Add(Me.cboshelflife)
		Me.pmain.Controls.Add(Me.cbocondition)
		Me.pmain.Controls.Add(Me.cboitemMat)
		Me.pmain.Location = New System.Drawing.Point(2, 5)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(922, 683)
		Me.pmain.TabIndex = 0
		'
		'Label5
		'
		Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label5.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.Location = New System.Drawing.Point(592, 149)
		Me.Label5.Name = "Label5"
		Me.Label5.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label5.Size = New System.Drawing.Size(320, 24)
		Me.Label5.TabIndex = 17
		Me.Label5.Text = "SHELFLIFE (BY) :"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'cbautoSearch
		'
		Me.cbautoSearch.AutoSize = True
		Me.cbautoSearch.Location = New System.Drawing.Point(15, 284)
		Me.cbautoSearch.Name = "cbautoSearch"
		Me.cbautoSearch.Size = New System.Drawing.Size(115, 20)
		Me.cbautoSearch.TabIndex = 8
		Me.cbautoSearch.Text = "Auto Search"
		Me.cbautoSearch.UseVisualStyleBackColor = True
		'
		'llblrefresh
		'
		Me.llblrefresh.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblrefresh.AutoSize = True
		Me.llblrefresh.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblrefresh.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblrefresh.Location = New System.Drawing.Point(541, 283)
		Me.llblrefresh.Name = "llblrefresh"
		Me.llblrefresh.Size = New System.Drawing.Size(119, 19)
		Me.llblrefresh.TabIndex = 7
		Me.llblrefresh.TabStop = True
		Me.llblrefresh.Text = "Refresh...."
		'
		'llbladdSave
		'
		Me.llbladdSave.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llbladdSave.AutoSize = True
		Me.llbladdSave.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llbladdSave.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llbladdSave.Location = New System.Drawing.Point(681, 283)
		Me.llbladdSave.Name = "llbladdSave"
		Me.llbladdSave.Size = New System.Drawing.Size(229, 19)
		Me.llbladdSave.TabIndex = 6
		Me.llbladdSave.TabStop = True
		Me.llbladdSave.Text = "Add / Save to List...."
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.Controls.Add(Me.griditemList)
		Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Panel1.Location = New System.Drawing.Point(3, 313)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(916, 367)
		Me.Panel1.TabIndex = 11
		'
		'griditemList
		'
		Me.griditemList.AllowUserToAddRows = False
		Me.griditemList.AllowUserToDeleteRows = False
		Me.griditemList.AllowUserToResizeColumns = False
		Me.griditemList.AllowUserToResizeRows = False
		Me.griditemList.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.griditemList.BackgroundColor = System.Drawing.Color.White
		Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
		Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle3.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
		Me.griditemList.ColumnHeadersHeight = 36
		Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
		DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle4.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.griditemList.DefaultCellStyle = DataGridViewCellStyle4
		Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.griditemList.EnableHeadersVisualStyles = False
		Me.griditemList.Location = New System.Drawing.Point(0, 0)
		Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
		Me.griditemList.MultiSelect = False
		Me.griditemList.Name = "griditemList"
		Me.griditemList.ReadOnly = True
		Me.griditemList.RowHeadersVisible = False
		Me.griditemList.RowTemplate.Height = 30
		Me.griditemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.griditemList.ShowCellErrors = False
		Me.griditemList.ShowCellToolTips = False
		Me.griditemList.ShowEditingIcon = False
		Me.griditemList.ShowRowErrors = False
		Me.griditemList.Size = New System.Drawing.Size(916, 367)
		Me.griditemList.TabIndex = 0
		'
		'Column1
		'
		Me.Column1.HeaderText = "Remove"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		'
		'lblbuildNo
		'
		Me.lblbuildNo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblbuildNo.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblbuildNo.Location = New System.Drawing.Point(786, 47)
		Me.lblbuildNo.Name = "lblbuildNo"
		Me.lblbuildNo.Size = New System.Drawing.Size(128, 20)
		Me.lblbuildNo.TabIndex = 7
		Me.lblbuildNo.Text = "Build.210713.01"
		Me.lblbuildNo.TextAlign = System.Drawing.ContentAlignment.BottomRight
		'
		'lblheaderSub
		'
		Me.lblheaderSub.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheaderSub.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.lblheaderSub.Location = New System.Drawing.Point(35, 47)
		Me.lblheaderSub.Name = "lblheaderSub"
		Me.lblheaderSub.Size = New System.Drawing.Size(745, 20)
		Me.lblheaderSub.TabIndex = 5
		Me.lblheaderSub.Text = "• Maintenance [ Add / Update / Remove ]"
		Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
		'
		'llblhide
		'
		Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblhide.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblhide.Location = New System.Drawing.Point(795, 9)
		Me.llblhide.Name = "llblhide"
		Me.llblhide.Size = New System.Drawing.Size(37, 25)
		Me.llblhide.TabIndex = 9
		Me.llblhide.TabStop = True
		Me.llblhide.Text = "◣"
		Me.llblhide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.llblhide.Visible = False
		'
		'llblmaximized
		'
		Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblmaximized.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblmaximized.Location = New System.Drawing.Point(836, 9)
		Me.llblmaximized.Name = "llblmaximized"
		Me.llblmaximized.Size = New System.Drawing.Size(37, 25)
		Me.llblmaximized.TabIndex = 10
		Me.llblmaximized.TabStop = True
		Me.llblmaximized.Text = "☐"
		Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.llblmaximized.Visible = False
		'
		'lblclose
		'
		Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblclose.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblclose.Location = New System.Drawing.Point(877, 9)
		Me.lblclose.Name = "lblclose"
		Me.lblclose.Size = New System.Drawing.Size(37, 25)
		Me.lblclose.TabIndex = 11
		Me.lblclose.TabStop = True
		Me.lblclose.Text = "✕"
		Me.lblclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label7
		'
		Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label7.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.Location = New System.Drawing.Point(365, 212)
		Me.Label7.Name = "Label7"
		Me.Label7.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label7.Size = New System.Drawing.Size(547, 24)
		Me.Label7.TabIndex = 10
		Me.Label7.Text = "STORAGE :"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Label1
		'
		Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label1.BackColor = System.Drawing.Color.DimGray
		Me.Label1.Location = New System.Drawing.Point(0, 72)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(924, 6)
		Me.Label1.TabIndex = 0
		'
		'Label4
		'
		Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label4.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.Location = New System.Drawing.Point(365, 149)
		Me.Label4.Name = "Label4"
		Me.Label4.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label4.Size = New System.Drawing.Size(225, 24)
		Me.Label4.TabIndex = 10
		Me.Label4.Text = "SHELFLIFE :"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Label6
		'
		Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label6.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.Location = New System.Drawing.Point(11, 212)
		Me.Label6.Name = "Label6"
		Me.Label6.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label6.Size = New System.Drawing.Size(352, 24)
		Me.Label6.TabIndex = 10
		Me.Label6.Text = "UNIT :"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblheader
		'
		Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheader.Location = New System.Drawing.Point(10, 9)
		Me.lblheader.Name = "lblheader"
		Me.lblheader.Size = New System.Drawing.Size(777, 60)
		Me.lblheader.TabIndex = 6
		Me.lblheader.Text = "I T E M   /   M A T E R I A L   M A S T E R"
		'
		'Label3
		'
		Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label3.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Location = New System.Drawing.Point(11, 149)
		Me.Label3.Name = "Label3"
		Me.Label3.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label3.Size = New System.Drawing.Size(352, 24)
		Me.Label3.TabIndex = 10
		Me.Label3.Text = "CONDITION :"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Label2
		'
		Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label2.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(11, 88)
		Me.Label2.Name = "Label2"
		Me.Label2.Padding = New System.Windows.Forms.Padding(0, 0, 0, 2)
		Me.Label2.Size = New System.Drawing.Size(451, 24)
		Me.Label2.TabIndex = 10
		Me.Label2.Text = "ITEM / MATERIAL NAME :"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'cbostorage
		'
		Me.cbostorage.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cbostorage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbostorage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbostorage.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cbostorage.FormattingEnabled = True
		Me.cbostorage.Location = New System.Drawing.Point(369, 239)
		Me.cbostorage.Name = "cbostorage"
		Me.cbostorage.Size = New System.Drawing.Size(543, 27)
		Me.cbostorage.TabIndex = 5
		'
		'cbounit
		'
		Me.cbounit.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cbounit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbounit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbounit.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cbounit.FormattingEnabled = True
		Me.cbounit.Location = New System.Drawing.Point(15, 239)
		Me.cbounit.Name = "cbounit"
		Me.cbounit.Size = New System.Drawing.Size(348, 27)
		Me.cbounit.TabIndex = 4
		'
		'cboshelflifeBy
		'
		Me.cboshelflifeBy.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboshelflifeBy.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboshelflifeBy.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboshelflifeBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboshelflifeBy.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboshelflifeBy.FormattingEnabled = True
		Me.cboshelflifeBy.Items.AddRange(New Object() {"MINUTES", "HOUR(S)", "DAY(S)", "WEEK(S)", "MONTH(S)", "YEAR(S)"})
		Me.cboshelflifeBy.Location = New System.Drawing.Point(596, 176)
		Me.cboshelflifeBy.Name = "cboshelflifeBy"
		Me.cboshelflifeBy.Size = New System.Drawing.Size(316, 27)
		Me.cboshelflifeBy.TabIndex = 3
		'
		'cboshelflife
		'
		Me.cboshelflife.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboshelflife.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboshelflife.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboshelflife.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboshelflife.FormattingEnabled = True
		Me.cboshelflife.Location = New System.Drawing.Point(369, 176)
		Me.cboshelflife.Name = "cboshelflife"
		Me.cboshelflife.Size = New System.Drawing.Size(221, 27)
		Me.cboshelflife.TabIndex = 2
		Me.cboshelflife.Tag = "DECIMAL"
		'
		'cbocondition
		'
		Me.cbocondition.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cbocondition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbocondition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbocondition.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cbocondition.FormattingEnabled = True
		Me.cbocondition.Location = New System.Drawing.Point(15, 176)
		Me.cbocondition.Name = "cbocondition"
		Me.cbocondition.Size = New System.Drawing.Size(348, 27)
		Me.cbocondition.TabIndex = 1
		'
		'cboitemMat
		'
		Me.cboitemMat.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboitemMat.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboitemMat.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboitemMat.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboitemMat.FormattingEnabled = True
		Me.cboitemMat.Location = New System.Drawing.Point(15, 115)
		Me.cboitemMat.Name = "cboitemMat"
		Me.cboitemMat.Size = New System.Drawing.Size(897, 27)
		Me.cboitemMat.TabIndex = 0
		'
		'vw_3_itemMaster
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.RoyalBlue
		Me.ClientSize = New System.Drawing.Size(926, 690)
		Me.Controls.Add(Me.pmain)
		Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_3_itemMaster"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ITEM / PRODUCT MASTER"
		Me.pmain.ResumeLayout(False)
		Me.pmain.PerformLayout()
		Me.Panel1.ResumeLayout(False)
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
	Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
	Friend WithEvents lblbuildNo As System.Windows.Forms.Label
	Friend WithEvents lblheaderSub As System.Windows.Forms.Label
	Friend WithEvents lblheader As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents griditemList As System.Windows.Forms.DataGridView
	Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
	Friend WithEvents llbladdSave As System.Windows.Forms.LinkLabel
	Friend WithEvents llblrefresh As System.Windows.Forms.LinkLabel
	Friend WithEvents cbautoSearch As System.Windows.Forms.CheckBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents cboitemMat As Label_System.modComboBox
	Friend WithEvents cbostorage As Label_System.modComboBox
	Friend WithEvents cbounit As Label_System.modComboBox
	Friend WithEvents cboshelflifeBy As Label_System.modComboBox
	Friend WithEvents cboshelflife As Label_System.modComboBox
	Friend WithEvents cbocondition As Label_System.modComboBox
End Class
