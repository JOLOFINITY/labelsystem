﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_2_login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_2_login))
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.pmain = New System.Windows.Forms.Panel()
		Me.PictureBox1 = New System.Windows.Forms.PictureBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.llblregister = New System.Windows.Forms.LinkLabel()
		Me.llbllogin = New System.Windows.Forms.LinkLabel()
		Me.llblrecovery = New System.Windows.Forms.LinkLabel()
		Me.tfocus = New System.Windows.Forms.Timer(Me.components)
		Me.txtpassword = New Label_System.modTextbox()
		Me.txtusername = New Label_System.modTextbox()
		Me.cbrem = New System.Windows.Forms.CheckBox()
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(148, 110)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(81, 19)
		Me.Label1.TabIndex = 2
		Me.Label1.Text = "USERNAME"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Consolas", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(148, 166)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(81, 19)
		Me.Label2.TabIndex = 2
		Me.Label2.Text = "PASSWORD"
		'
		'pmain
		'
		Me.pmain.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.RoyalBlue
		Me.pmain.BackgroundImage = CType(resources.GetObject("pmain.BackgroundImage"), System.Drawing.Image)
		Me.pmain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
		Me.pmain.Location = New System.Drawing.Point(0, 0)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(541, 95)
		Me.pmain.TabIndex = 0
		'
		'PictureBox1
		'
		Me.PictureBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
		Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
		Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
		Me.PictureBox1.Location = New System.Drawing.Point(2, 106)
		Me.PictureBox1.Name = "PictureBox1"
		Me.PictureBox1.Size = New System.Drawing.Size(139, 161)
		Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
		Me.PictureBox1.TabIndex = 0
		Me.PictureBox1.TabStop = False
		'
		'Label3
		'
		Me.Label3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label3.BackColor = System.Drawing.Color.Black
		Me.Label3.Location = New System.Drawing.Point(-3, 94)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(544, 9)
		Me.Label3.TabIndex = 3
		Me.Label3.Text = "Label3"
		'
		'Label4
		'
		Me.Label4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label4.BackColor = System.Drawing.Color.Yellow
		Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.Yellow
		Me.Label4.Location = New System.Drawing.Point(0, 271)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(541, 45)
		Me.Label4.TabIndex = 4
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'llblregister
		'
		Me.llblregister.AutoSize = True
		Me.llblregister.BackColor = System.Drawing.Color.Yellow
		Me.llblregister.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblregister.LinkArea = New System.Windows.Forms.LinkArea(1, 22)
		Me.llblregister.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblregister.Location = New System.Drawing.Point(245, 280)
		Me.llblregister.Name = "llblregister"
		Me.llblregister.Size = New System.Drawing.Size(263, 29)
		Me.llblregister.TabIndex = 4
		Me.llblregister.TabStop = True
		Me.llblregister.Text = "[ REGISTER NEW ACCOUNT ]"
		Me.llblregister.UseCompatibleTextRendering = True
		'
		'llbllogin
		'
		Me.llbllogin.AutoSize = True
		Me.llbllogin.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llbllogin.LinkArea = New System.Windows.Forms.LinkArea(1, 7)
		Me.llbllogin.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llbllogin.Location = New System.Drawing.Point(413, 232)
		Me.llbllogin.Name = "llbllogin"
		Me.llbllogin.Size = New System.Drawing.Size(91, 29)
		Me.llbllogin.TabIndex = 2
		Me.llbllogin.TabStop = True
		Me.llbllogin.Text = "[ LOGIN ]"
		Me.llbllogin.UseCompatibleTextRendering = True
		'
		'llblrecovery
		'
		Me.llblrecovery.AutoSize = True
		Me.llblrecovery.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblrecovery.LinkArea = New System.Windows.Forms.LinkArea(1, 10)
		Me.llblrecovery.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblrecovery.Location = New System.Drawing.Point(278, 232)
		Me.llblrecovery.Name = "llblrecovery"
		Me.llblrecovery.Size = New System.Drawing.Size(129, 29)
		Me.llblrecovery.TabIndex = 3
		Me.llblrecovery.TabStop = True
		Me.llblrecovery.Text = "[ RECOVERY ]"
		Me.llblrecovery.UseCompatibleTextRendering = True
		'
		'tfocus
		'
		Me.tfocus.Enabled = True
		Me.tfocus.Interval = 500
		'
		'txtpassword
		'
		Me.txtpassword.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtpassword.Location = New System.Drawing.Point(151, 190)
		Me.txtpassword.MaxLength = 24
		Me.txtpassword.Name = "txtpassword"
		Me.txtpassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.txtpassword.Size = New System.Drawing.Size(353, 27)
		Me.txtpassword.TabIndex = 1
		'
		'txtusername
		'
		Me.txtusername.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtusername.Location = New System.Drawing.Point(151, 133)
		Me.txtusername.MaxLength = 32
		Me.txtusername.Name = "txtusername"
		Me.txtusername.Size = New System.Drawing.Size(353, 27)
		Me.txtusername.TabIndex = 0
		'
		'cbrem
		'
		Me.cbrem.AutoSize = True
		Me.cbrem.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cbrem.Location = New System.Drawing.Point(152, 233)
		Me.cbrem.Name = "cbrem"
		Me.cbrem.Size = New System.Drawing.Size(99, 22)
		Me.cbrem.TabIndex = 5
		Me.cbrem.Text = "Remember"
		Me.cbrem.UseVisualStyleBackColor = True
		'
		'vw_2_login
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.Color.MintCream
		Me.ClientSize = New System.Drawing.Size(541, 316)
		Me.Controls.Add(Me.cbrem)
		Me.Controls.Add(Me.txtpassword)
		Me.Controls.Add(Me.txtusername)
		Me.Controls.Add(Me.llblrecovery)
		Me.Controls.Add(Me.llbllogin)
		Me.Controls.Add(Me.llblregister)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.Label3)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.pmain)
		Me.Controls.Add(Me.PictureBox1)
		Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_2_login"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "LOGIN"
		CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents llblregister As System.Windows.Forms.LinkLabel
	Friend WithEvents llbllogin As System.Windows.Forms.LinkLabel
	Friend WithEvents txtusername As Label_System.modTextbox
	Friend WithEvents txtpassword As Label_System.modTextbox
	Friend WithEvents llblrecovery As System.Windows.Forms.LinkLabel
	Friend WithEvents tfocus As System.Windows.Forms.Timer
	Friend WithEvents cbrem As System.Windows.Forms.CheckBox
End Class
