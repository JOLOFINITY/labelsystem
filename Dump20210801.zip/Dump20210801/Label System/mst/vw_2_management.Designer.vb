﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_2_management
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_2_management))
		Me.panelHeader = New System.Windows.Forms.Panel()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.llblclose = New System.Windows.Forms.LinkLabel()
		Me.llblregister = New System.Windows.Forms.LinkLabel()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.grpsec = New System.Windows.Forms.GroupBox()
		Me.cboq3 = New Label_System.modComboBox()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.cboq2 = New Label_System.modComboBox()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.cboa3 = New Label_System.modTextbox()
		Me.cboq1 = New Label_System.modComboBox()
		Me.cboa2 = New Label_System.modTextbox()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.cboa1 = New Label_System.modTextbox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.txtpassword2 = New Label_System.modTextbox()
		Me.txtpassword1 = New Label_System.modTextbox()
		Me.txtusername = New Label_System.modTextbox()
		Me.txtname = New Label_System.modTextbox()
		Me.panelHeader.SuspendLayout()
		Me.Panel1.SuspendLayout()
		Me.grpsec.SuspendLayout()
		Me.SuspendLayout()
		'
		'panelHeader
		'
		Me.panelHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.panelHeader.BackColor = System.Drawing.Color.RoyalBlue
		Me.panelHeader.Controls.Add(Me.Label2)
		Me.panelHeader.Location = New System.Drawing.Point(-1, -3)
		Me.panelHeader.Name = "panelHeader"
		Me.panelHeader.Size = New System.Drawing.Size(633, 63)
		Me.panelHeader.TabIndex = 3
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.ForeColor = System.Drawing.Color.Yellow
		Me.Label2.Location = New System.Drawing.Point(36, 24)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(281, 27)
		Me.Label2.TabIndex = 0
		Me.Label2.Text = "• User Account Setting(s)"
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.BackColor = System.Drawing.Color.Yellow
		Me.Panel1.Controls.Add(Me.llblclose)
		Me.Panel1.Controls.Add(Me.llblregister)
		Me.Panel1.Location = New System.Drawing.Point(-1, 477)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(633, 49)
		Me.Panel1.TabIndex = 4
		'
		'llblclose
		'
		Me.llblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblclose.AutoSize = True
		Me.llblclose.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblclose.LinkArea = New System.Windows.Forms.LinkArea(1, 7)
		Me.llblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblclose.Location = New System.Drawing.Point(520, 11)
		Me.llblclose.Name = "llblclose"
		Me.llblclose.Size = New System.Drawing.Size(91, 29)
		Me.llblclose.TabIndex = 4
		Me.llblclose.TabStop = True
		Me.llblclose.Text = "[ CLOSE ]"
		Me.llblclose.UseCompatibleTextRendering = True
		'
		'llblregister
		'
		Me.llblregister.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblregister.AutoSize = True
		Me.llblregister.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblregister.LinkArea = New System.Windows.Forms.LinkArea(1, 8)
		Me.llblregister.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblregister.Location = New System.Drawing.Point(404, 11)
		Me.llblregister.Name = "llblregister"
		Me.llblregister.Size = New System.Drawing.Size(105, 29)
		Me.llblregister.TabIndex = 3
		Me.llblregister.TabStop = True
		Me.llblregister.Text = "[ UPDATE ]"
		Me.llblregister.UseCompatibleTextRendering = True
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label6.ForeColor = System.Drawing.Color.White
		Me.Label6.Location = New System.Drawing.Point(38, 188)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(157, 22)
		Me.Label6.TabIndex = 12
		Me.Label6.Text = "Verify Password :"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.ForeColor = System.Drawing.Color.White
		Me.Label5.Location = New System.Drawing.Point(91, 155)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(104, 22)
		Me.Label5.TabIndex = 5
		Me.Label5.Text = "Password :"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.White
		Me.Label4.Location = New System.Drawing.Point(88, 122)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(107, 22)
		Me.Label4.TabIndex = 6
		Me.Label4.Text = "Username :"
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.White
		Me.Label1.Location = New System.Drawing.Point(123, 82)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(70, 22)
		Me.Label1.TabIndex = 8
		Me.Label1.Text = "Name :"
		'
		'grpsec
		'
		Me.grpsec.Controls.Add(Me.cboq3)
		Me.grpsec.Controls.Add(Me.Label12)
		Me.grpsec.Controls.Add(Me.cboq2)
		Me.grpsec.Controls.Add(Me.Label10)
		Me.grpsec.Controls.Add(Me.cboa3)
		Me.grpsec.Controls.Add(Me.cboq1)
		Me.grpsec.Controls.Add(Me.cboa2)
		Me.grpsec.Controls.Add(Me.Label11)
		Me.grpsec.Controls.Add(Me.Label7)
		Me.grpsec.Controls.Add(Me.Label9)
		Me.grpsec.Controls.Add(Me.cboa1)
		Me.grpsec.Controls.Add(Me.Label8)
		Me.grpsec.Location = New System.Drawing.Point(12, 229)
		Me.grpsec.Name = "grpsec"
		Me.grpsec.Size = New System.Drawing.Size(605, 241)
		Me.grpsec.TabIndex = 13
		Me.grpsec.TabStop = False
		Me.grpsec.Text = "Account Recovery Question :"
		'
		'cboq3
		'
		Me.cboq3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboq3.FormattingEnabled = True
		Me.cboq3.Location = New System.Drawing.Point(147, 172)
		Me.cboq3.Name = "cboq3"
		Me.cboq3.Size = New System.Drawing.Size(448, 26)
		Me.cboq3.TabIndex = 4
		'
		'Label12
		'
		Me.Label12.AutoSize = True
		Me.Label12.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.ForeColor = System.Drawing.Color.White
		Me.Label12.Location = New System.Drawing.Point(29, 172)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(112, 22)
		Me.Label12.TabIndex = 0
		Me.Label12.Text = "Question 3 :"
		'
		'cboq2
		'
		Me.cboq2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboq2.FormattingEnabled = True
		Me.cboq2.Location = New System.Drawing.Point(147, 103)
		Me.cboq2.Name = "cboq2"
		Me.cboq2.Size = New System.Drawing.Size(448, 26)
		Me.cboq2.TabIndex = 2
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label10.ForeColor = System.Drawing.Color.White
		Me.Label10.Location = New System.Drawing.Point(29, 103)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(112, 22)
		Me.Label10.TabIndex = 0
		Me.Label10.Text = "Question 2 :"
		'
		'cboa3
		'
		Me.cboa3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa3.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa3.Location = New System.Drawing.Point(147, 201)
		Me.cboa3.MaxLength = 24
		Me.cboa3.Name = "cboa3"
		Me.cboa3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa3.Size = New System.Drawing.Size(448, 27)
		Me.cboa3.TabIndex = 5
		'
		'cboq1
		'
		Me.cboq1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboq1.FormattingEnabled = True
		Me.cboq1.Location = New System.Drawing.Point(147, 34)
		Me.cboq1.Name = "cboq1"
		Me.cboq1.Size = New System.Drawing.Size(448, 26)
		Me.cboq1.TabIndex = 0
		'
		'cboa2
		'
		Me.cboa2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa2.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa2.Location = New System.Drawing.Point(147, 132)
		Me.cboa2.MaxLength = 24
		Me.cboa2.Name = "cboa2"
		Me.cboa2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa2.Size = New System.Drawing.Size(448, 27)
		Me.cboa2.TabIndex = 3
		'
		'Label11
		'
		Me.Label11.AutoSize = True
		Me.Label11.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.ForeColor = System.Drawing.Color.White
		Me.Label11.Location = New System.Drawing.Point(42, 201)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(99, 22)
		Me.Label11.TabIndex = 4
		Me.Label11.Text = "Answer 3 :"
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.ForeColor = System.Drawing.Color.White
		Me.Label7.Location = New System.Drawing.Point(29, 34)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(112, 22)
		Me.Label7.TabIndex = 0
		Me.Label7.Text = "Question 1 :"
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label9.ForeColor = System.Drawing.Color.White
		Me.Label9.Location = New System.Drawing.Point(42, 132)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(99, 22)
		Me.Label9.TabIndex = 4
		Me.Label9.Text = "Answer 2 :"
		'
		'cboa1
		'
		Me.cboa1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa1.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa1.Location = New System.Drawing.Point(147, 63)
		Me.cboa1.MaxLength = 24
		Me.cboa1.Name = "cboa1"
		Me.cboa1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa1.Size = New System.Drawing.Size(448, 27)
		Me.cboa1.TabIndex = 1
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.ForeColor = System.Drawing.Color.White
		Me.Label8.Location = New System.Drawing.Point(42, 63)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(99, 22)
		Me.Label8.TabIndex = 4
		Me.Label8.Text = "Answer 1 :"
		'
		'txtpassword2
		'
		Me.txtpassword2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtpassword2.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtpassword2.Location = New System.Drawing.Point(199, 188)
		Me.txtpassword2.MaxLength = 24
		Me.txtpassword2.Name = "txtpassword2"
		Me.txtpassword2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.txtpassword2.Size = New System.Drawing.Size(274, 27)
		Me.txtpassword2.TabIndex = 11
		'
		'txtpassword1
		'
		Me.txtpassword1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtpassword1.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtpassword1.Location = New System.Drawing.Point(199, 155)
		Me.txtpassword1.MaxLength = 24
		Me.txtpassword1.Name = "txtpassword1"
		Me.txtpassword1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.txtpassword1.Size = New System.Drawing.Size(274, 27)
		Me.txtpassword1.TabIndex = 10
		'
		'txtusername
		'
		Me.txtusername.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtusername.Enabled = False
		Me.txtusername.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtusername.Location = New System.Drawing.Point(199, 122)
		Me.txtusername.MaxLength = 32
		Me.txtusername.Name = "txtusername"
		Me.txtusername.Size = New System.Drawing.Size(316, 27)
		Me.txtusername.TabIndex = 9
		'
		'txtname
		'
		Me.txtname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtname.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtname.Location = New System.Drawing.Point(199, 82)
		Me.txtname.MaxLength = 145
		Me.txtname.Name = "txtname"
		Me.txtname.Size = New System.Drawing.Size(418, 27)
		Me.txtname.TabIndex = 7
		'
		'vw_2_management
		'
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.Black
		Me.ClientSize = New System.Drawing.Size(631, 526)
		Me.Controls.Add(Me.grpsec)
		Me.Controls.Add(Me.txtpassword2)
		Me.Controls.Add(Me.Label6)
		Me.Controls.Add(Me.txtpassword1)
		Me.Controls.Add(Me.Label5)
		Me.Controls.Add(Me.txtusername)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.txtname)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.Panel1)
		Me.Controls.Add(Me.panelHeader)
		Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_2_management"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "MANAGE"
		Me.panelHeader.ResumeLayout(False)
		Me.panelHeader.PerformLayout()
		Me.Panel1.ResumeLayout(False)
		Me.Panel1.PerformLayout()
		Me.grpsec.ResumeLayout(False)
		Me.grpsec.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents panelHeader As System.Windows.Forms.Panel
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents llblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents llblregister As System.Windows.Forms.LinkLabel
	Friend WithEvents txtpassword2 As Label_System.modTextbox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents txtpassword1 As Label_System.modTextbox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents txtusername As Label_System.modTextbox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents txtname As Label_System.modTextbox
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents grpsec As System.Windows.Forms.GroupBox
	Friend WithEvents cboq3 As Label_System.modComboBox
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents cboq2 As Label_System.modComboBox
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents cboa3 As Label_System.modTextbox
	Friend WithEvents cboq1 As Label_System.modComboBox
	Friend WithEvents cboa2 As Label_System.modTextbox
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents cboa1 As Label_System.modTextbox
	Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
