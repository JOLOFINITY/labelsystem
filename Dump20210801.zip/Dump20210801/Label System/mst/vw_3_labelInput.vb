﻿Imports System.Runtime.InteropServices
Public Class vw_3_labelInput
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub vw_3_labelInput_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
		vw_1_menu.lblheader.Text = vw_1_menu.lblheader.Tag
	End Sub

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub
#End Region
	Private mst_items As New DataTable("result")
	Private Sub vw_3_labelInput_Shown(sender As Object, e As EventArgs) Handles Me.Shown
		Call get_itemListA(cboitems, cbocondition, mst_items)

		Call get_itemListC(griditemList)

		dtTimeIn.Value = DateAndTime.Now.ToString("MM-dd-yyyy 07:00")

		With My.Settings
			cboemployee.Text = .nameOfEmployee
			cbomanager.Text = .nameOfManager
		End With

		vw_1_menu.lblheader.Text = "L A B E L   P R I N T I N G   I N P U T "
	End Sub
	Private Sub cboitems_TextChanged(sender As Object, e As EventArgs) Handles cboitems.TextChanged
		cbocondition.Text = Nothing
		lblproduction.Text = String.Empty
		cboquantity.Text = String.Empty
		lblunit.Text = String.Empty
		lblshelflife.Text = String.Empty
		lblshelflifeBy.Text = String.Empty
		lblstorage.Text = String.Empty
		lblusedBy.Text = String.Empty
		lblvalidity.Text = String.Empty

		_exec_gridSearch(griditemList, cboitems.Text)

		If griditemList.Rows.Count = 0 Then
			picNew.Visible = True
		Else
			picNew.Visible = False
		End If
	End Sub
	Private Sub cbocondition_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbocondition.SelectedIndexChanged
		If cbocondition.Text <> String.Empty Then
			If cboitems.Text <> String.Empty Then
				Dim filter = mst_items.Select("`Item Name` = '" & cboitems.Text & "' AND `Condition` = '" & cbocondition.Text & "'")

				If filter.Length = 1 Then
					lblunit.Text = filter.ToArray(0)("Unit")
					lblshelflife.Text = filter.ToArray(0)("Shelflife")

					Dim dec = Math.Truncate(filter.ToArray(0)("Shelflife"))
					Dim toInt = Decimal.Parse(lblshelflife.Text) - dec
					If toInt = 0 Then
						lblshelflife.Text = CInt(lblshelflife.Text)
					End If

					lblshelflifeBy.Text = filter.ToArray(0)("Shelflife By")
					lblstorage.Text = filter.ToArray(0)("Storage")

					lblproduction.Text = "Enter the PRODUCTION DATE."
					dateProduction.Focus()

					UseByUntil()
				Else
					MessageBox.Show("Record not found, Please ask SYSTEM-ADMIN to add.", "Item not found.", MessageBoxButtons.OK, MessageBoxIcon.Information)
				End If

				'getLastInput(cboitems.Text, cbocondition, cbotenure, cboterm, cboquantity, cboprocess, cbounit, cbostorage)
			End If
		End If
	End Sub

	Private Sub griditemList_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles griditemList.CellClick
		If e.RowIndex >= 0 And e.ColumnIndex = 0 Then
			With griditemList
				Dim strItem As String = .Rows(e.RowIndex).Cells(1).Value.ToString.Trim
				Dim strCon As String = .Rows(e.RowIndex).Cells(2).Value.ToString.Trim

				cboitems.Text = strItem
				cbocondition.Text = strCon
			End With
		End If
	End Sub

	Private Sub cboitems_Enter(sender As Object, e As EventArgs) Handles _
		cboitems.Enter, _
		cbocondition.Enter, _
		dateProduction.Enter, _
		dtTimeIn.Enter, _
		cboquantity.Enter, _
		cboemployee.Enter, _
		cboremarks.Enter, _
		cbomanager.Enter, dtDate.Enter

		Dim strTag As String = sender.Tag

		If strTag = "A" Then
			lblA.BackColor = Color.Lime

		ElseIf strTag = "B" Then
			lblB.BackColor = Color.Lime

		ElseIf strTag = "C" Then
			lblC.BackColor = Color.Lime
			Call displayDay()

		ElseIf strTag = "D" Then
			lblD.BackColor = Color.Lime
			Call displayDay()

		ElseIf strTag = "E" Then
			lblE.BackColor = Color.Lime

		ElseIf strTag = "H" Then
			lblH.BackColor = Color.Lime

		ElseIf strTag = "I" Then
			lblI.BackColor = Color.Lime

		ElseIf strTag = "J" Then
			lblJ.BackColor = Color.Lime

		End If
	End Sub
	Private Sub cboitems_Leave(sender As Object, e As EventArgs) Handles _
		cboitems.Leave, _
		cbocondition.Leave, _
		dateProduction.Leave, _
		dtTimeIn.Leave, _
		cboquantity.Leave, _
		cboemployee.Leave, _
		cboremarks.Leave, _
		cbomanager.Leave, dtDate.Leave

		Dim strTag As String = sender.Tag

		If strTag = "A" Then
			lblA.BackColor = Color.Black

		ElseIf strTag = "B" Then
			lblB.BackColor = Color.Black

		ElseIf strTag = "C" Then
			lblC.BackColor = Color.Black

		ElseIf strTag = "D" Then
			lblD.BackColor = Color.Black

		ElseIf strTag = "E" Then
			lblE.BackColor = Color.Black

		ElseIf strTag = "F" Then
			lblF.BackColor = Color.Black

		ElseIf strTag = "G" Then
			lblG.BackColor = Color.Black

		ElseIf strTag = "H" Then
			lblH.BackColor = Color.Black

		ElseIf strTag = "I" Then
			lblI.BackColor = Color.Black

		ElseIf strTag = "J" Then
			lblJ.BackColor = Color.Black

		End If
	End Sub
	Private Sub displayDay()
		If lblshelflife.Text <> String.Empty Then
			If lblshelflifeBy.Text = "MINUTES" Then
				lblusedBy.Text = dtTimeIn.Value.AddMinutes(lblshelflife.Text).ToString("MM-dd-yyyy  (  hh:mm tt  )")

			ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddHours(lblshelflife.Text).ToString("MM-dd-yyyy  (  hh:mm tt  )")

			ElseIf lblshelflifeBy.Text = "DAY(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddDays(lblshelflife.Text).ToString("MM-dd-yyyy  (  hh:mm tt  )")

			ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
				Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
				lblusedBy.Text = dtTimeIn.Value.AddDays(toDays).ToString("MM-dd-yyyy  (  hh:mm tt  )")

			ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddMonths(lblshelflife.Text).ToString("MM-dd-yyyy  (  hh:mm tt  )")

			ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddYears(lblshelflife.Text).ToString("MM-dd-yyyy  (  hh:mm tt  )")

			End If
		End If

		Call UseByUntil()
	End Sub
	

	Private Sub dtTimeIn_ValueChanged(sender As Object, e As EventArgs) Handles dtTimeIn.ValueChanged
		UseByUntil()
	End Sub

	Public Sub UseByUntil()
		If lblshelflife.Text <> String.Empty Then
			Dim days As String = String.Empty
			If lblshelflifeBy.Text = "MINUTES" Then
				lblusedBy.Text = dtTimeIn.Value.AddMinutes(lblshelflife.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
				lblusedBy.Tag = dtTimeIn.Value.AddMinutes(lblshelflife.Text)
				days = dtTimeIn.Value.AddMinutes(lblshelflife.Text).ToString("dddd")

			ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddHours(lblshelflife.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
				lblusedBy.Tag = dtTimeIn.Value.AddHours(lblshelflife.Text)
				days = dtTimeIn.Value.AddHours(lblshelflife.Text).ToString("dddd")

			ElseIf lblshelflifeBy.Text = "DAY(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddDays(lblshelflife.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
				lblusedBy.Tag = dtTimeIn.Value.AddDays(lblshelflife.Text)
				days = dtTimeIn.Value.AddDays(lblshelflife.Text).ToString("dddd")

			ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
				Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
				lblusedBy.Text = dtTimeIn.Value.AddDays(toDays).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
				lblusedBy.Tag = dtTimeIn.Value.AddDays(toDays)
				days = dtTimeIn.Value.AddDays(toDays).ToString("dddd")

			ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddMonths(lblshelflife.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
				lblusedBy.Tag = dtTimeIn.Value.AddMonths(lblshelflife.Text)
				days = dtTimeIn.Value.AddMonths(lblshelflife.Text).ToString("dddd")

			ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
				lblusedBy.Text = dtTimeIn.Value.AddYears(lblshelflife.Text).ToString("yyyy/MM/dd  (  hh:mm:ss tt  )")
				lblusedBy.Tag = dtTimeIn.Value.AddYears(lblshelflife.Text)
				days = dtTimeIn.Value.AddYears(lblshelflife.Text).ToString("dddd")

			End If

			lbldays.Text = days.ToUpper
			lbldays.Tag = days.ToUpper

			Call checkExpiration()
		End If
	End Sub

	Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnsave.Click, btnsavePrint.Click
		Dim btn As Button = sender

		saveRecord(CBool(btn.Tag))
	End Sub
	Private Sub saveRecord(ByRef toPrint As Boolean)
		If toPrint = True Then
			cboitems.Text = String.Empty
			cboitems.Focus()
		ElseIf cboitems.SelectedIndex = -1 And cboitems.Text = String.Empty Then
			MessageBox.Show("Please Select Item and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
			cboitems.SelectAll() : cboitems.Focus()
		ElseIf cbocondition.SelectedIndex = -1 Then
			MessageBox.Show("Please select Condition and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
			cbocondition.SelectAll() : cbocondition.Focus()
		ElseIf (cboquantity.Text = String.Empty) Then
			MessageBox.Show("Quantity Required! and try again!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Information)
			cboquantity.SelectAll() : cboquantity.Focus()
		Else
			'Dim strDay As String = lbldays.Text
			'Dim itemName As String = cboitems.Text
			'Dim productionDate As Date = dateProduction.Value.Date
			'Dim qty As Decimal = Decimal.Parse(IIf(cboquantity.Text = String.Empty, 0, cboquantity.Text))
			'Dim shelfLife As String = String.Format("{0} {1}", cbotenure.Text, cboterm.Text)
			'Dim timeIn As DateTime = dtTimeIn.Value
			'Dim employee As String = cboemployee.Text
			'Dim manager As String = cbomanager.Text
			'Dim remarks As String = cboremarks.Text
			'Dim useBy As String = lblusedBy.Tag
			'Dim timeAMPM As String = DateTime.Parse(lblusedBy.Tag).ToString("tt")

			With My.Settings
				.nameOfEmployee = cboemployee.Text
				.nameOfManager = cbomanager.Text
				.remarks = cboremarks.Text
				.Save()
			End With

			'If checkItem_AddItem(cboitems.Text, dateProduction.Checked) Then
			'	Call addItemList(cboitems.Text, cbocondition.Text, cbotenure.Text, cboterm.Text, cbostorage.Text, cboquantity.Text, cboprocess.Text, cbounit.Text)
			'	Call get_itemListA(cboitems, mst_items)
			'Else
			'	If check_itemExistB(cbocondition.Text, cboitems.Text, cboterm.Text, cbostorage.Text) = False Then
			'		Call addItemList(cboitems.Text, cbocondition.Text, cbotenure.Text, cboterm.Text, cbostorage.Text, cboquantity.Text, cboprocess.Text, cbounit.Text)
			'		Call get_itemListA(cboitems, mst_items)
			'	End If
			'End If

			'AddForPrint(strDay, itemName, productionDate, qty, shelfLife, timeIn, employee, manager, remarks, useBy, timeAMPM)

			MessageBox.Show("Record successfully save, Printing can be done later.", "Record Saved.", MessageBoxButtons.OK, MessageBoxIcon.Information)

			cboitems.Text = String.Empty
		End If
	End Sub

	Private expirationDate As DateTime = DateAndTime.Now.AddMinutes(10)
	Private Sub dateProduction_ValueChanged(sender As Object, e As EventArgs) Handles dateProduction.ValueChanged, dtDate.ValueChanged, dtTimeIn.ValueChanged
		Call checkExpiration()
	End Sub
	Private Sub checkExpiration()
		lblvalidity.Text = String.Empty

		expirationDate = dateProduction.Value.AddMinutes(10)

		If dateProduction.Checked Then
			If lblshelflifeBy.Text = "MINUTES" Then
				expirationDate = dateProduction.Value.AddMinutes(lblshelflife.Text)

			ElseIf lblshelflifeBy.Text = "HOUR(S)" Then
				expirationDate = dateProduction.Value.AddHours(lblshelflife.Text)

			ElseIf lblshelflifeBy.Text = "DAY(S)" Then
				expirationDate = dateProduction.Value.AddDays(lblshelflife.Text)

			ElseIf lblshelflifeBy.Text = "WEEK(S)" Then
				Dim toDays = Decimal.Parse(lblshelflife.Text) * 7.0
				expirationDate = dateProduction.Value.AddDays(toDays)

			ElseIf lblshelflifeBy.Text = "MONTH(S)" Then
				expirationDate = dateProduction.Value.AddMonths(lblshelflife.Text)

			ElseIf lblshelflifeBy.Text = "YEAR(S)" Then
				expirationDate = dateProduction.Value.AddYears(lblshelflife.Text)

			Else
				Return
			End If

			If DateAndTime.Now > expirationDate Then
expNa:
				lblvalidity.Text = "* material / product already exprired. (BF : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper & ")"
				lblvalidity.ForeColor = Color.Red

				btnsave.ForeColor = Color.Gray : btnsave.Enabled = False
				'btnsavePrint.ForeColor = Color.Gray : btnsavePrint.Enabled = False
			Else
				If dtTimeIn.Value > expirationDate Then
					GoTo expNa
				Else
					lblvalidity.Text = "* use / valid until : " & expirationDate.ToString("MM/dd/yyyy hh:mm tt").ToUpper
					lblvalidity.ForeColor = Color.Lime

					btnsave.ForeColor = Color.Blue : btnsave.Enabled = True
					'btnsavePrint.ForeColor = Color.Blue : btnsavePrint.Enabled = True
				End If
			End If
		End If
	End Sub

	Private Sub vw_3_labelInput_Load(sender As Object, e As EventArgs) Handles MyBase.Load

	End Sub

	Private Sub lbldays_Paint(sender As Object, e As PaintEventArgs) Handles lbldays.Paint
		Dim rect As New RectangleF(lbldays.Left, lbldays.Top, lbldays.Width, lbldays.Height)

		Dim strText As String = lbldays.Text
		Dim fnt As New Font("Arial", 16) ' Optional
		Dim strfmt As New StringFormat
		strfmt.LineAlignment = StringAlignment.Center
		strfmt.FormatFlags = StringFormatFlags.DirectionVertical
		strfmt.Alignment = StringAlignment.Center

		Dim grfx As System.Drawing.Graphics = e.Graphics
		grfx.DrawString(strText, fnt, Brushes.Black, rect, strfmt)

		If lblshelflife.Text <> String.Empty Then
			If dtTimeIn.Value.ToString("dddd").ToUpper = "MONDAY" Then
				lbldays.BackColor = Color.DarkBlue
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "TUESDAY" Then
				lbldays.BackColor = Color.Goldenrod
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "WEDNESDAY" Then
				lbldays.BackColor = Color.Firebrick
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "THURSDAY" Then
				lbldays.BackColor = Color.SaddleBrown
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "FRIDAY" Then
				lbldays.BackColor = Color.ForestGreen
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "SATURDAY" Then
				lbldays.BackColor = Color.DarkOrange
			ElseIf dtTimeIn.Value.ToString("dddd").ToUpper = "SUNDAY" Then
				lbldays.BackColor = Color.Black
			Else
				'lbldays.BackColor = Color.DimGray
			End If
		End If
	End Sub
End Class