﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_2_recovery
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_2_recovery))
		Me.panelHeader = New System.Windows.Forms.Panel()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.llblclose = New System.Windows.Forms.LinkLabel()
		Me.llblshowPassword = New System.Windows.Forms.LinkLabel()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.grpsec = New System.Windows.Forms.GroupBox()
		Me.cboq2 = New System.Windows.Forms.Label()
		Me.cboq3 = New System.Windows.Forms.Label()
		Me.cboq1 = New System.Windows.Forms.Label()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.cboa3 = New Label_System.modTextbox()
		Me.cboa2 = New Label_System.modTextbox()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.cboa1 = New Label_System.modTextbox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.txtusername = New Label_System.modTextbox()
		Me.lblpassword = New System.Windows.Forms.Label()
		Me.tfocus = New System.Windows.Forms.Timer(Me.components)
		Me.thider = New System.Windows.Forms.Timer(Me.components)
		Me.Label1 = New System.Windows.Forms.Label()
		Me.panelHeader.SuspendLayout()
		Me.Panel1.SuspendLayout()
		Me.grpsec.SuspendLayout()
		Me.SuspendLayout()
		'
		'panelHeader
		'
		Me.panelHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.panelHeader.BackColor = System.Drawing.Color.RoyalBlue
		Me.panelHeader.Controls.Add(Me.Label2)
		Me.panelHeader.Location = New System.Drawing.Point(-1, -3)
		Me.panelHeader.Name = "panelHeader"
		Me.panelHeader.Size = New System.Drawing.Size(822, 63)
		Me.panelHeader.TabIndex = 3
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.ForeColor = System.Drawing.Color.Yellow
		Me.Label2.Location = New System.Drawing.Point(36, 24)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(220, 27)
		Me.Label2.TabIndex = 0
		Me.Label2.Text = "• Account Recovery"
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.BackColor = System.Drawing.Color.Yellow
		Me.Panel1.Controls.Add(Me.Label1)
		Me.Panel1.Controls.Add(Me.llblclose)
		Me.Panel1.Controls.Add(Me.llblshowPassword)
		Me.Panel1.Location = New System.Drawing.Point(-1, 477)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(822, 49)
		Me.Panel1.TabIndex = 4
		'
		'llblclose
		'
		Me.llblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblclose.AutoSize = True
		Me.llblclose.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblclose.LinkArea = New System.Windows.Forms.LinkArea(1, 7)
		Me.llblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblclose.Location = New System.Drawing.Point(709, 11)
		Me.llblclose.Name = "llblclose"
		Me.llblclose.Size = New System.Drawing.Size(91, 29)
		Me.llblclose.TabIndex = 4
		Me.llblclose.TabStop = True
		Me.llblclose.Text = "[ CLOSE ]"
		Me.llblclose.UseCompatibleTextRendering = True
		'
		'llblshowPassword
		'
		Me.llblshowPassword.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblshowPassword.AutoSize = True
		Me.llblshowPassword.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblshowPassword.LinkArea = New System.Windows.Forms.LinkArea(1, 15)
		Me.llblshowPassword.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblshowPassword.Location = New System.Drawing.Point(492, 11)
		Me.llblshowPassword.Name = "llblshowPassword"
		Me.llblshowPassword.Size = New System.Drawing.Size(197, 29)
		Me.llblshowPassword.TabIndex = 3
		Me.llblshowPassword.TabStop = True
		Me.llblshowPassword.Text = "[ SHOW PASSWORD ]"
		Me.llblshowPassword.UseCompatibleTextRendering = True
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.White
		Me.Label4.Location = New System.Drawing.Point(48, 75)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(107, 22)
		Me.Label4.TabIndex = 6
		Me.Label4.Text = "Username :"
		'
		'grpsec
		'
		Me.grpsec.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.grpsec.Controls.Add(Me.cboq2)
		Me.grpsec.Controls.Add(Me.cboq3)
		Me.grpsec.Controls.Add(Me.cboq1)
		Me.grpsec.Controls.Add(Me.Label12)
		Me.grpsec.Controls.Add(Me.Label10)
		Me.grpsec.Controls.Add(Me.cboa3)
		Me.grpsec.Controls.Add(Me.cboa2)
		Me.grpsec.Controls.Add(Me.Label11)
		Me.grpsec.Controls.Add(Me.Label7)
		Me.grpsec.Controls.Add(Me.Label9)
		Me.grpsec.Controls.Add(Me.cboa1)
		Me.grpsec.Controls.Add(Me.Label8)
		Me.grpsec.Enabled = False
		Me.grpsec.ForeColor = System.Drawing.Color.White
		Me.grpsec.Location = New System.Drawing.Point(12, 118)
		Me.grpsec.Name = "grpsec"
		Me.grpsec.Size = New System.Drawing.Size(794, 241)
		Me.grpsec.TabIndex = 13
		Me.grpsec.TabStop = False
		Me.grpsec.Text = "Account Recovery Question :"
		'
		'cboq2
		'
		Me.cboq2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.cboq2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboq2.ForeColor = System.Drawing.Color.White
		Me.cboq2.Location = New System.Drawing.Point(147, 101)
		Me.cboq2.Name = "cboq2"
		Me.cboq2.Size = New System.Drawing.Size(637, 26)
		Me.cboq2.TabIndex = 15
		Me.cboq2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'cboq3
		'
		Me.cboq3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.cboq3.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboq3.ForeColor = System.Drawing.Color.White
		Me.cboq3.Location = New System.Drawing.Point(147, 170)
		Me.cboq3.Name = "cboq3"
		Me.cboq3.Size = New System.Drawing.Size(637, 26)
		Me.cboq3.TabIndex = 15
		Me.cboq3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'cboq1
		'
		Me.cboq1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.cboq1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cboq1.ForeColor = System.Drawing.Color.White
		Me.cboq1.Location = New System.Drawing.Point(147, 32)
		Me.cboq1.Name = "cboq1"
		Me.cboq1.Size = New System.Drawing.Size(637, 26)
		Me.cboq1.TabIndex = 15
		Me.cboq1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'Label12
		'
		Me.Label12.AutoSize = True
		Me.Label12.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label12.ForeColor = System.Drawing.Color.White
		Me.Label12.Location = New System.Drawing.Point(29, 172)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(112, 22)
		Me.Label12.TabIndex = 0
		Me.Label12.Text = "Question 3 :"
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label10.ForeColor = System.Drawing.Color.White
		Me.Label10.Location = New System.Drawing.Point(29, 103)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(112, 22)
		Me.Label10.TabIndex = 0
		Me.Label10.Text = "Question 2 :"
		'
		'cboa3
		'
		Me.cboa3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa3.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa3.Location = New System.Drawing.Point(147, 201)
		Me.cboa3.MaxLength = 24
		Me.cboa3.Name = "cboa3"
		Me.cboa3.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa3.Size = New System.Drawing.Size(637, 27)
		Me.cboa3.TabIndex = 5
		'
		'cboa2
		'
		Me.cboa2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa2.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa2.Location = New System.Drawing.Point(147, 132)
		Me.cboa2.MaxLength = 24
		Me.cboa2.Name = "cboa2"
		Me.cboa2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa2.Size = New System.Drawing.Size(637, 27)
		Me.cboa2.TabIndex = 3
		'
		'Label11
		'
		Me.Label11.AutoSize = True
		Me.Label11.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label11.ForeColor = System.Drawing.Color.White
		Me.Label11.Location = New System.Drawing.Point(42, 201)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(99, 22)
		Me.Label11.TabIndex = 4
		Me.Label11.Text = "Answer 3 :"
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.ForeColor = System.Drawing.Color.White
		Me.Label7.Location = New System.Drawing.Point(29, 34)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(112, 22)
		Me.Label7.TabIndex = 0
		Me.Label7.Text = "Question 1 :"
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label9.ForeColor = System.Drawing.Color.White
		Me.Label9.Location = New System.Drawing.Point(42, 132)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(99, 22)
		Me.Label9.TabIndex = 4
		Me.Label9.Text = "Answer 2 :"
		'
		'cboa1
		'
		Me.cboa1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa1.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa1.Location = New System.Drawing.Point(147, 63)
		Me.cboa1.MaxLength = 24
		Me.cboa1.Name = "cboa1"
		Me.cboa1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa1.Size = New System.Drawing.Size(637, 27)
		Me.cboa1.TabIndex = 1
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.ForeColor = System.Drawing.Color.White
		Me.Label8.Location = New System.Drawing.Point(42, 63)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(99, 22)
		Me.Label8.TabIndex = 4
		Me.Label8.Text = "Answer 1 :"
		'
		'txtusername
		'
		Me.txtusername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.txtusername.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtusername.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtusername.Location = New System.Drawing.Point(159, 75)
		Me.txtusername.MaxLength = 32
		Me.txtusername.Name = "txtusername"
		Me.txtusername.Size = New System.Drawing.Size(637, 27)
		Me.txtusername.TabIndex = 9
		'
		'lblpassword
		'
		Me.lblpassword.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblpassword.Font = New System.Drawing.Font("Arial", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblpassword.ForeColor = System.Drawing.Color.White
		Me.lblpassword.Location = New System.Drawing.Point(12, 367)
		Me.lblpassword.Name = "lblpassword"
		Me.lblpassword.Size = New System.Drawing.Size(796, 103)
		Me.lblpassword.TabIndex = 14
		Me.lblpassword.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'tfocus
		'
		Me.tfocus.Enabled = True
		Me.tfocus.Interval = 500
		'
		'thider
		'
		Me.thider.Interval = 1000
		'
		'Label1
		'
		Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
		Me.Label1.AutoSize = True
		Me.Label1.Location = New System.Drawing.Point(13, 15)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(0, 18)
		Me.Label1.TabIndex = 5
		'
		'vw_2_recovery
		'
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.Black
		Me.ClientSize = New System.Drawing.Size(820, 526)
		Me.Controls.Add(Me.lblpassword)
		Me.Controls.Add(Me.grpsec)
		Me.Controls.Add(Me.txtusername)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.Panel1)
		Me.Controls.Add(Me.panelHeader)
		Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_2_recovery"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "MANAGE"
		Me.panelHeader.ResumeLayout(False)
		Me.panelHeader.PerformLayout()
		Me.Panel1.ResumeLayout(False)
		Me.Panel1.PerformLayout()
		Me.grpsec.ResumeLayout(False)
		Me.grpsec.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents panelHeader As System.Windows.Forms.Panel
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents llblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents llblshowPassword As System.Windows.Forms.LinkLabel
	Friend WithEvents txtusername As Label_System.modTextbox
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents grpsec As System.Windows.Forms.GroupBox
	Friend WithEvents Label12 As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents cboa3 As Label_System.modTextbox
	Friend WithEvents cboa2 As Label_System.modTextbox
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents cboa1 As Label_System.modTextbox
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents lblpassword As System.Windows.Forms.Label
	Friend WithEvents cboq1 As System.Windows.Forms.Label
	Friend WithEvents cboq2 As System.Windows.Forms.Label
	Friend WithEvents cboq3 As System.Windows.Forms.Label
	Friend WithEvents tfocus As System.Windows.Forms.Timer
	Friend WithEvents thider As System.Windows.Forms.Timer
	Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
