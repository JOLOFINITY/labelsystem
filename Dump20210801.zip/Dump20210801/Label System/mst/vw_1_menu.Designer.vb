﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_1_menu
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_1_menu))
		Me.pmain = New System.Windows.Forms.Panel()
		Me.lblversionInfo = New System.Windows.Forms.LinkLabel()
		Me.pController = New System.Windows.Forms.Panel()
		Me.pfooter = New System.Windows.Forms.Panel()
		Me.lblstatus = New System.Windows.Forms.Label()
		Me.lbldatetime = New System.Windows.Forms.Label()
		Me.picdownloading = New System.Windows.Forms.PictureBox()
		Me.PictureBox2 = New System.Windows.Forms.PictureBox()
		Me.pmenus = New System.Windows.Forms.Panel()
		Me.llbluserlogin = New System.Windows.Forms.LinkLabel()
		Me.mnStart = New System.Windows.Forms.MenuStrip()
		Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.CheckProgramUpdateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.mnupdateProgram = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
		Me.mnupdateDB = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
		Me.cmsettings = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
		Me.cmexit = New System.Windows.Forms.ToolStripMenuItem()
		Me.LabelPrintingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.cmlabelEntry = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripSeparator()
		Me.cmlabelHistory = New System.Windows.Forms.ToolStripMenuItem()
		Me.MasterMaintenanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.cmuserMan = New System.Windows.Forms.ToolStripMenuItem()
		Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
		Me.cmitemMst = New System.Windows.Forms.ToolStripMenuItem()
		Me.cmlogin_logout = New System.Windows.Forms.ToolStripMenuItem()
		Me.lblheaderSub = New System.Windows.Forms.Label()
		Me.llblhide = New System.Windows.Forms.LinkLabel()
		Me.llblmaximized = New System.Windows.Forms.LinkLabel()
		Me.lblclose = New System.Windows.Forms.LinkLabel()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.lblheader = New System.Windows.Forms.Label()
		Me.getDateTime = New System.Windows.Forms.Timer(Me.components)
		Me.updater = New System.Windows.Forms.Timer(Me.components)
		Me.tInitUpdate = New System.Windows.Forms.Timer(Me.components)
		Me.pmain.SuspendLayout()
		Me.pfooter.SuspendLayout()
		CType(Me.picdownloading, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.pmenus.SuspendLayout()
		Me.mnStart.SuspendLayout()
		Me.SuspendLayout()
		'
		'pmain
		'
		Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.White
		Me.pmain.Controls.Add(Me.lblversionInfo)
		Me.pmain.Controls.Add(Me.pController)
		Me.pmain.Controls.Add(Me.pfooter)
		Me.pmain.Controls.Add(Me.pmenus)
		Me.pmain.Controls.Add(Me.lblheaderSub)
		Me.pmain.Controls.Add(Me.llblhide)
		Me.pmain.Controls.Add(Me.llblmaximized)
		Me.pmain.Controls.Add(Me.lblclose)
		Me.pmain.Controls.Add(Me.Label1)
		Me.pmain.Controls.Add(Me.lblheader)
		Me.pmain.Location = New System.Drawing.Point(2, 5)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(1105, 810)
		Me.pmain.TabIndex = 0
		'
		'lblversionInfo
		'
		Me.lblversionInfo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblversionInfo.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblversionInfo.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.lblversionInfo.Location = New System.Drawing.Point(771, 36)
		Me.lblversionInfo.Name = "lblversionInfo"
		Me.lblversionInfo.Size = New System.Drawing.Size(331, 24)
		Me.lblversionInfo.TabIndex = 12
		Me.lblversionInfo.TextAlign = System.Drawing.ContentAlignment.BottomRight
		'
		'pController
		'
		Me.pController.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pController.Location = New System.Drawing.Point(2, 97)
		Me.pController.Name = "pController"
		Me.pController.Size = New System.Drawing.Size(1101, 668)
		Me.pController.TabIndex = 11
		'
		'pfooter
		'
		Me.pfooter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pfooter.BackColor = System.Drawing.Color.LightGray
		Me.pfooter.Controls.Add(Me.lblstatus)
		Me.pfooter.Controls.Add(Me.lbldatetime)
		Me.pfooter.Controls.Add(Me.picdownloading)
		Me.pfooter.Controls.Add(Me.PictureBox2)
		Me.pfooter.Location = New System.Drawing.Point(1, 766)
		Me.pfooter.Name = "pfooter"
		Me.pfooter.Size = New System.Drawing.Size(1103, 43)
		Me.pfooter.TabIndex = 10
		'
		'lblstatus
		'
		Me.lblstatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblstatus.Font = New System.Drawing.Font("Consolas", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblstatus.Location = New System.Drawing.Point(552, 8)
		Me.lblstatus.Name = "lblstatus"
		Me.lblstatus.Size = New System.Drawing.Size(510, 29)
		Me.lblstatus.TabIndex = 0
		Me.lblstatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lbldatetime
		'
		Me.lbldatetime.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lbldatetime.Font = New System.Drawing.Font("Consolas", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lbldatetime.Location = New System.Drawing.Point(9, 8)
		Me.lbldatetime.Name = "lbldatetime"
		Me.lbldatetime.Size = New System.Drawing.Size(533, 29)
		Me.lbldatetime.TabIndex = 0
		Me.lbldatetime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'picdownloading
		'
		Me.picdownloading.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.picdownloading.Image = CType(resources.GetObject("picdownloading.Image"), System.Drawing.Image)
		Me.picdownloading.Location = New System.Drawing.Point(1066, 6)
		Me.picdownloading.Name = "picdownloading"
		Me.picdownloading.Size = New System.Drawing.Size(32, 32)
		Me.picdownloading.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
		Me.picdownloading.TabIndex = 0
		Me.picdownloading.TabStop = False
		Me.picdownloading.Visible = False
		'
		'PictureBox2
		'
		Me.PictureBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
		Me.PictureBox2.Location = New System.Drawing.Point(1066, 6)
		Me.PictureBox2.Name = "PictureBox2"
		Me.PictureBox2.Size = New System.Drawing.Size(32, 32)
		Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
		Me.PictureBox2.TabIndex = 1
		Me.PictureBox2.TabStop = False
		'
		'pmenus
		'
		Me.pmenus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmenus.BackColor = System.Drawing.Color.Gainsboro
		Me.pmenus.Controls.Add(Me.llbluserlogin)
		Me.pmenus.Controls.Add(Me.mnStart)
		Me.pmenus.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.pmenus.Location = New System.Drawing.Point(0, 69)
		Me.pmenus.Name = "pmenus"
		Me.pmenus.Size = New System.Drawing.Size(1105, 27)
		Me.pmenus.TabIndex = 9
		'
		'llbluserlogin
		'
		Me.llbluserlogin.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llbluserlogin.Font = New System.Drawing.Font("Consolas", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llbluserlogin.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llbluserlogin.Location = New System.Drawing.Point(905, 2)
		Me.llbluserlogin.Name = "llbluserlogin"
		Me.llbluserlogin.Size = New System.Drawing.Size(192, 21)
		Me.llbluserlogin.TabIndex = 0
		Me.llbluserlogin.TabStop = True
		Me.llbluserlogin.Text = "Manage Account"
		Me.llbluserlogin.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		Me.llbluserlogin.Visible = False
		'
		'mnStart
		'
		Me.mnStart.BackColor = System.Drawing.Color.Gainsboro
		Me.mnStart.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.mnStart.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem, Me.LabelPrintingToolStripMenuItem, Me.MasterMaintenanceToolStripMenuItem, Me.cmlogin_logout})
		Me.mnStart.Location = New System.Drawing.Point(0, 0)
		Me.mnStart.Name = "mnStart"
		Me.mnStart.Padding = New System.Windows.Forms.Padding(6, 3, 0, 2)
		Me.mnStart.Size = New System.Drawing.Size(1105, 25)
		Me.mnStart.TabIndex = 8
		Me.mnStart.Text = "MenuStrip1"
		'
		'MenuToolStripMenuItem
		'
		Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CheckProgramUpdateToolStripMenuItem, Me.ToolStripMenuItem2, Me.cmsettings, Me.ToolStripMenuItem1, Me.cmexit})
		Me.MenuToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
		Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
		Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(74, 20)
		Me.MenuToolStripMenuItem.Text = "Menu  "
		'
		'CheckProgramUpdateToolStripMenuItem
		'
		Me.CheckProgramUpdateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnupdateProgram, Me.ToolStripMenuItem3, Me.mnupdateDB})
		Me.CheckProgramUpdateToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!)
		Me.CheckProgramUpdateToolStripMenuItem.Name = "CheckProgramUpdateToolStripMenuItem"
		Me.CheckProgramUpdateToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
		Me.CheckProgramUpdateToolStripMenuItem.Text = "Check Update"
		'
		'mnupdateProgram
		'
		Me.mnupdateProgram.Name = "mnupdateProgram"
		Me.mnupdateProgram.Size = New System.Drawing.Size(164, 22)
		Me.mnupdateProgram.Text = "Program App"
		'
		'ToolStripMenuItem3
		'
		Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
		Me.ToolStripMenuItem3.Size = New System.Drawing.Size(161, 6)
		'
		'mnupdateDB
		'
		Me.mnupdateDB.Enabled = False
		Me.mnupdateDB.Name = "mnupdateDB"
		Me.mnupdateDB.Size = New System.Drawing.Size(164, 22)
		Me.mnupdateDB.Text = "Database"
		'
		'ToolStripMenuItem2
		'
		Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
		Me.ToolStripMenuItem2.Size = New System.Drawing.Size(169, 6)
		'
		'cmsettings
		'
		Me.cmsettings.Enabled = False
		Me.cmsettings.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmsettings.Name = "cmsettings"
		Me.cmsettings.Size = New System.Drawing.Size(172, 22)
		Me.cmsettings.Text = "Setting(s)"
		'
		'ToolStripMenuItem1
		'
		Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
		Me.ToolStripMenuItem1.Size = New System.Drawing.Size(169, 6)
		'
		'cmexit
		'
		Me.cmexit.Font = New System.Drawing.Font("MS Gothic", 12.0!)
		Me.cmexit.Name = "cmexit"
		Me.cmexit.Size = New System.Drawing.Size(172, 22)
		Me.cmexit.Text = "Exit"
		'
		'LabelPrintingToolStripMenuItem
		'
		Me.LabelPrintingToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmlabelEntry, Me.ToolStripMenuItem5, Me.cmlabelHistory})
		Me.LabelPrintingToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
		Me.LabelPrintingToolStripMenuItem.Name = "LabelPrintingToolStripMenuItem"
		Me.LabelPrintingToolStripMenuItem.Size = New System.Drawing.Size(164, 20)
		Me.LabelPrintingToolStripMenuItem.Text = "Label Printing  "
		'
		'cmlabelEntry
		'
		Me.cmlabelEntry.Enabled = False
		Me.cmlabelEntry.Font = New System.Drawing.Font("MS Gothic", 12.0!)
		Me.cmlabelEntry.Name = "cmlabelEntry"
		Me.cmlabelEntry.Size = New System.Drawing.Size(244, 22)
		Me.cmlabelEntry.Text = "Label Entry"
		'
		'ToolStripMenuItem5
		'
		Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
		Me.ToolStripMenuItem5.Size = New System.Drawing.Size(241, 6)
		'
		'cmlabelHistory
		'
		Me.cmlabelHistory.Enabled = False
		Me.cmlabelHistory.Font = New System.Drawing.Font("MS Gothic", 12.0!)
		Me.cmlabelHistory.Name = "cmlabelHistory"
		Me.cmlabelHistory.Size = New System.Drawing.Size(244, 22)
		Me.cmlabelHistory.Text = "Print / Label History"
		'
		'MasterMaintenanceToolStripMenuItem
		'
		Me.MasterMaintenanceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cmuserMan, Me.ToolStripMenuItem4, Me.cmitemMst})
		Me.MasterMaintenanceToolStripMenuItem.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
		Me.MasterMaintenanceToolStripMenuItem.Name = "MasterMaintenanceToolStripMenuItem"
		Me.MasterMaintenanceToolStripMenuItem.Size = New System.Drawing.Size(200, 20)
		Me.MasterMaintenanceToolStripMenuItem.Text = "Master Maintenance  "
		'
		'cmuserMan
		'
		Me.cmuserMan.Enabled = False
		Me.cmuserMan.Font = New System.Drawing.Font("MS Gothic", 12.0!)
		Me.cmuserMan.Name = "cmuserMan"
		Me.cmuserMan.Size = New System.Drawing.Size(244, 22)
		Me.cmuserMan.Text = "User Management"
		'
		'ToolStripMenuItem4
		'
		Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
		Me.ToolStripMenuItem4.Size = New System.Drawing.Size(241, 6)
		'
		'cmitemMst
		'
		Me.cmitemMst.Enabled = False
		Me.cmitemMst.Font = New System.Drawing.Font("MS Gothic", 12.0!)
		Me.cmitemMst.Name = "cmitemMst"
		Me.cmitemMst.Size = New System.Drawing.Size(244, 22)
		Me.cmitemMst.Text = "Item(s) / Material(s)"
		'
		'cmlogin_logout
		'
		Me.cmlogin_logout.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Bold)
		Me.cmlogin_logout.Name = "cmlogin_logout"
		Me.cmlogin_logout.Size = New System.Drawing.Size(74, 20)
		Me.cmlogin_logout.Text = "Logout"
		Me.cmlogin_logout.Visible = False
		'
		'lblheaderSub
		'
		Me.lblheaderSub.Font = New System.Drawing.Font("MS Gothic", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheaderSub.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
		Me.lblheaderSub.Location = New System.Drawing.Point(26, 37)
		Me.lblheaderSub.Name = "lblheaderSub"
		Me.lblheaderSub.Size = New System.Drawing.Size(633, 24)
		Me.lblheaderSub.TabIndex = 5
		Me.lblheaderSub.Tag = "• Label Printing • Finished Goods • Inventory System"
		Me.lblheaderSub.TextAlign = System.Drawing.ContentAlignment.BottomLeft
		'
		'llblhide
		'
		Me.llblhide.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblhide.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblhide.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblhide.Location = New System.Drawing.Point(978, 9)
		Me.llblhide.Name = "llblhide"
		Me.llblhide.Size = New System.Drawing.Size(37, 25)
		Me.llblhide.TabIndex = 2
		Me.llblhide.TabStop = True
		Me.llblhide.Text = "◣"
		Me.llblhide.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'llblmaximized
		'
		Me.llblmaximized.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblmaximized.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblmaximized.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.llblmaximized.Location = New System.Drawing.Point(1019, 9)
		Me.llblmaximized.Name = "llblmaximized"
		Me.llblmaximized.Size = New System.Drawing.Size(37, 25)
		Me.llblmaximized.TabIndex = 1
		Me.llblmaximized.TabStop = True
		Me.llblmaximized.Text = "☐"
		Me.llblmaximized.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'lblclose
		'
		Me.lblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblclose.Font = New System.Drawing.Font("MS Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline
		Me.lblclose.Location = New System.Drawing.Point(1060, 9)
		Me.lblclose.Name = "lblclose"
		Me.lblclose.Size = New System.Drawing.Size(37, 25)
		Me.lblclose.TabIndex = 1
		Me.lblclose.TabStop = True
		Me.lblclose.Text = "✕"
		Me.lblclose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label1
		'
		Me.Label1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label1.BackColor = System.Drawing.Color.DimGray
		Me.Label1.Location = New System.Drawing.Point(0, 64)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(1107, 5)
		Me.Label1.TabIndex = 0
		'
		'lblheader
		'
		Me.lblheader.Font = New System.Drawing.Font("MS Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblheader.Location = New System.Drawing.Point(10, 7)
		Me.lblheader.Name = "lblheader"
		Me.lblheader.Size = New System.Drawing.Size(867, 60)
		Me.lblheader.TabIndex = 6
		Me.lblheader.Tag = "Integrated LFI Syetem Menu"
		'
		'getDateTime
		'
		Me.getDateTime.Enabled = True
		Me.getDateTime.Interval = 1000
		'
		'updater
		'
		Me.updater.Interval = 5000
		'
		'tInitUpdate
		'
		Me.tInitUpdate.Interval = 3000
		'
		'vw_1_menu
		'
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.RoyalBlue
		Me.ClientSize = New System.Drawing.Size(1109, 817)
		Me.Controls.Add(Me.pmain)
		Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_1_menu"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ITEM / PRODUCT MASTER"
		Me.pmain.ResumeLayout(False)
		Me.pfooter.ResumeLayout(False)
		CType(Me.picdownloading, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
		Me.pmenus.ResumeLayout(False)
		Me.pmenus.PerformLayout()
		Me.mnStart.ResumeLayout(False)
		Me.mnStart.PerformLayout()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents llblmaximized As System.Windows.Forms.LinkLabel
	Friend WithEvents llblhide As System.Windows.Forms.LinkLabel
	Friend WithEvents lblheaderSub As System.Windows.Forms.Label
	Friend WithEvents lblheader As System.Windows.Forms.Label
	Friend WithEvents mnStart As System.Windows.Forms.MenuStrip
	Friend WithEvents MenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents pmenus As System.Windows.Forms.Panel
	Friend WithEvents cmsettings As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents MasterMaintenanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents LabelPrintingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents cmexit As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmitemMst As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmlabelEntry As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents cmlabelHistory As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents pfooter As System.Windows.Forms.Panel
	Friend WithEvents pController As System.Windows.Forms.Panel
	Friend WithEvents lblversionInfo As System.Windows.Forms.LinkLabel
	Friend WithEvents CheckProgramUpdateToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents mnupdateProgram As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents mnupdateDB As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents lbldatetime As System.Windows.Forms.Label
	Friend WithEvents getDateTime As System.Windows.Forms.Timer
	Friend WithEvents lblstatus As System.Windows.Forms.Label
	Friend WithEvents picdownloading As System.Windows.Forms.PictureBox
	Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
	Friend WithEvents updater As System.Windows.Forms.Timer
	Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripSeparator
	Friend WithEvents tInitUpdate As System.Windows.Forms.Timer
	Friend WithEvents cmlogin_logout As System.Windows.Forms.ToolStripMenuItem
	Friend WithEvents llbluserlogin As System.Windows.Forms.LinkLabel
	Friend WithEvents cmuserMan As System.Windows.Forms.ToolStripMenuItem
End Class
