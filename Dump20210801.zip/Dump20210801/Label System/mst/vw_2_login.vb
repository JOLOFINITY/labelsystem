﻿Imports System.Runtime.InteropServices
Public Class vw_2_login
#Region "MOVING"
	Public Const WM_NCLBUTTONDOWN As Integer = 161
	Public Const HT_CAPTION As Integer = 2

	<DllImportAttribute("User32.dll")> _
	Public Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, vParam As Integer, lParam As Integer) As Integer
	End Function
	<DllImportAttribute("User32.dll")> _
	Public Shared Function ReleaseCapture() As Boolean
	End Function

	Private Sub panel_header_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown, pmain.MouseDown
		If e.Button = MouseButtons.Left Then
			ReleaseCapture()
			SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0)
		End If
	End Sub

	Private Const SM_CXSCREEN As Integer = 0
	Private Const SM_CYSCREEN As Integer = 1
	Private Shared HWND_TOP As IntPtr = IntPtr.Zero
	Private Const SWP_SHOWWINDOW As Integer = 64

	Private winState As FormWindowState
	Private brdStyle As FormBorderStyle
	Private isTopMost As Boolean
	Private isBounds As Rectangle

	<DllImport("user32.dll", EntryPoint:="GetSystemMetrics")>
	Public Shared Function GetSystemMetrics(ByVal which As Integer) As Integer

	End Function
	<DllImport("user32.dll")>
	Public Shared Sub SetWindowPos(ByVal hwnd As IntPtr, ByVal hwndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal flags As UInteger)

	End Sub
	Public Shared ReadOnly Property ScreenX As Integer
		Get
			Return GetSystemMetrics(SM_CXSCREEN)
		End Get
	End Property

	Public Shared ReadOnly Property ScreenY As Integer
		Get
			Return GetSystemMetrics(SM_CYSCREEN)
		End Get
	End Property

	Public Shared Sub SetWinFullScreen(ByVal hwnd As IntPtr)
		SetWindowPos(hwnd, HWND_TOP, 0, 0, ScreenX, ScreenY, SWP_SHOWWINDOW)
	End Sub

	Private IsMaximized As Boolean = False
	Public Sub Maximize(ByVal targetForm As Form)
		If Not IsMaximized Then
			IsMaximized = True
			Save(targetForm)
			targetForm.WindowState = FormWindowState.Maximized
			targetForm.FormBorderStyle = FormBorderStyle.None
			targetForm.TopMost = True
			SetWinFullScreen(targetForm.Handle)
		End If
	End Sub
	Public Sub Save(ByVal targetForm As Form)
		winState = targetForm.WindowState
		brdStyle = targetForm.FormBorderStyle
		isTopMost = targetForm.TopMost
		isBounds = targetForm.Bounds
	End Sub
	Public Sub Restore(ByVal targetForm As Form)
		targetForm.WindowState = winState
		targetForm.FormBorderStyle = brdStyle
		targetForm.TopMost = isTopMost
		targetForm.Bounds = isBounds
		IsMaximized = False
	End Sub


#End Region


	Private Sub Button1_Paint(sender As Object, e As PaintEventArgs)
		buttonBorderRadius(sender, 25)
	End Sub

	Private Sub Button2_Paint(sender As Object, e As PaintEventArgs)
		buttonBorderRadius(sender, 50)
	End Sub

	Private Sub vw_2_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		roundCorners(Me, Color.MintCream)
	End Sub
	'Public Function MakeFraction128(length As String) As String
	'	Try
	'		If length.ToString.Contains("/") Then
	'			Dim split = length.ToString.Split("/")

	'			MakeFraction128 = Decimal.Parse(CInt(split(0)) / CInt(split(1))).ToString("#0.00")
	'		Else
	'			Dim value As Double = Double.Parse(length)

	'			Dim n128 As Long = Math.Abs(CLng(Math.Round(value * 128, 0)))
	'			Dim f128 As Long = n128 Mod 128
	'			Dim fraction As String = "", denom As Integer = 128

	'			If f128 > 0 Then
	'				Do While f128 Mod 2 = 0
	'					f128 \= 2
	'					denom \= 2
	'				Loop
	'				fraction = String.Format("{0}/{1}", f128, denom)
	'			End If

	'			Dim sign As String = If(value < 0, "-", "")

	'			'MakeFraction128 = sign & Math.Floor(Math.Abs(value)).ToString & " " & fraction
	'			MakeFraction128 = fraction
	'		End If

	'	Catch ex As Exception
	'		MakeFraction128 = 0
	'	End Try
	'End Function

	'Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
	'	Try

	'		Label1.Text = MakeFraction128(TextBox1.Text)
	'	Catch ex As Exception
	'		Label1.Text = ""
	'	End Try
	'End Sub

	Private Sub tfocus_Tick(sender As Object, e As EventArgs) Handles tfocus.Tick
		tfocus.Stop()

		With My.Settings
			If .last_Username <> String.Empty Then
				cbrem.Checked = True

				txtusername.Text = .last_Username
				txtpassword.Text = .last_Password
			End If
		End With

		txtusername.Focus()
	End Sub

	Private Sub llblregister_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblregister.LinkClicked
		Dispose()

		vw_1_menu.showLogin(vw_2_registration)
	End Sub

	Private Sub llbllogin_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llbllogin.LinkClicked
		Call login()
	End Sub

	Sub login()
		If txtusername.Text = String.Empty Then
			txtusername.Focus()
		ElseIf txtpassword.Text = String.Empty Then
			txtpassword.Focus()
		Else
			Dim user = getUser(txtusername.Text)

			If user.Rows.Count >= 1 Then
				If txtpassword.Text = user.Rows(0)("Password").ToString Then
					login_access = user.Rows(0)("Access").ToString
					login_name = user.Rows(0)("Name").ToString
					login_username = user.Rows(0)("Username").ToString

					Call log_User("LOGIN", login_username)

					If user.Rows(0)("Active").ToString = "0" Then
						Hide()
						MessageBox.Show("Account is not yet activated, please inform your Superior.", "For Activation", MessageBoxButtons.OK, MessageBoxIcon.Information)
						vw_1_menu.menu_inactive()
					ElseIf login_access = "USER" Then
						vw_1_menu.menu_user()
					ElseIf login_access = "ADMIN" Then
						vw_1_menu.menu_admin()
					Else
						vw_1_menu.disabled()
					End If

					With My.Settings
						If cbrem.Checked Then
							.last_Username = txtusername.Text
							.last_Password = txtpassword.Text
						Else
							.last_Username = String.Empty
							.last_Password = String.Empty
						End If
						.Save()
					End With

					Dispose()
				Else
					MessageBox.Show("Invalid username or password, try again..", "Invalid User Login", MessageBoxButtons.OK, MessageBoxIcon.Error)
					txtusername.SelectAll() : txtusername.Focus()
				End If
			End If
		End If
	End Sub

	Private Sub txtusername_KeyDown(sender As Object, e As KeyEventArgs) Handles txtusername.KeyDown, txtpassword.KeyDown
		If e.KeyCode = Keys.Escape Then
			Dim txt As TextBox = sender

			txt.Clear()

		ElseIf e.KeyCode = Keys.Enter Then
			Call login()
		End If
	End Sub

	Private Sub llblrecovery_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles llblrecovery.LinkClicked
		Dispose()

		vw_1_menu.showLogin(New vw_2_recovery)
	End Sub
End Class