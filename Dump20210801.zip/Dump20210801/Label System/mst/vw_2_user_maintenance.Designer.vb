﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_2_user_maintenance
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.components = New System.ComponentModel.Container()
		Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_2_user_maintenance))
		Me.Label1 = New System.Windows.Forms.Label()
		Me.panelHeader = New System.Windows.Forms.Panel()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.llbldelete = New System.Windows.Forms.LinkLabel()
		Me.llblclose = New System.Windows.Forms.LinkLabel()
		Me.llblclear = New System.Windows.Forms.LinkLabel()
		Me.llblregister = New System.Windows.Forms.LinkLabel()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.grpsec = New System.Windows.Forms.GroupBox()
		Me.rbqa3 = New System.Windows.Forms.RadioButton()
		Me.rbqa2 = New System.Windows.Forms.RadioButton()
		Me.rbqa1 = New System.Windows.Forms.RadioButton()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.userChecker = New System.Windows.Forms.Timer(Me.components)
		Me.tfocus = New System.Windows.Forms.Timer(Me.components)
		Me.Panel2 = New System.Windows.Forms.Panel()
		Me.gridUsers = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.cboq1 = New Label_System.modComboBox()
		Me.cboa1 = New Label_System.modTextbox()
		Me.txtusername = New Label_System.modTextbox()
		Me.txtsearch = New Label_System.modTextbox()
		Me.txtname = New Label_System.modTextbox()
		Me.panelHeader.SuspendLayout()
		Me.Panel1.SuspendLayout()
		Me.grpsec.SuspendLayout()
		Me.Panel2.SuspendLayout()
		CType(Me.gridUsers, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.White
		Me.Label1.Location = New System.Drawing.Point(39, 71)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(183, 22)
		Me.Label1.TabIndex = 0
		Me.Label1.Text = "Name of Employee :"
		'
		'panelHeader
		'
		Me.panelHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.panelHeader.BackColor = System.Drawing.Color.RoyalBlue
		Me.panelHeader.Controls.Add(Me.Label3)
		Me.panelHeader.Controls.Add(Me.Label2)
		Me.panelHeader.Location = New System.Drawing.Point(0, 0)
		Me.panelHeader.Name = "panelHeader"
		Me.panelHeader.Size = New System.Drawing.Size(806, 63)
		Me.panelHeader.TabIndex = 2
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.ForeColor = System.Drawing.Color.Yellow
		Me.Label3.Location = New System.Drawing.Point(341, 31)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(353, 17)
		Me.Label3.TabIndex = 1
		Me.Label3.Text = "** All created account is for approval of Administrator."
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Arial", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.ForeColor = System.Drawing.Color.Yellow
		Me.Label2.Location = New System.Drawing.Point(36, 24)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(299, 27)
		Me.Label2.TabIndex = 0
		Me.Label2.Text = "• Create new User Account"
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.BackColor = System.Drawing.Color.Yellow
		Me.Panel1.Controls.Add(Me.llbldelete)
		Me.Panel1.Controls.Add(Me.llblclose)
		Me.Panel1.Controls.Add(Me.llblclear)
		Me.Panel1.Controls.Add(Me.llblregister)
		Me.Panel1.Location = New System.Drawing.Point(0, 585)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(806, 55)
		Me.Panel1.TabIndex = 3
		'
		'llbldelete
		'
		Me.llbldelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llbldelete.AutoSize = True
		Me.llbldelete.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llbldelete.LinkArea = New System.Windows.Forms.LinkArea(1, 8)
		Me.llbldelete.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llbldelete.Location = New System.Drawing.Point(427, 16)
		Me.llbldelete.Name = "llbldelete"
		Me.llbldelete.Size = New System.Drawing.Size(101, 29)
		Me.llbldelete.TabIndex = 5
		Me.llbldelete.TabStop = True
		Me.llbldelete.Text = "[ DELETE ]"
		Me.llbldelete.UseCompatibleTextRendering = True
		Me.llbldelete.Visible = False
		'
		'llblclose
		'
		Me.llblclose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblclose.AutoSize = True
		Me.llblclose.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblclose.LinkArea = New System.Windows.Forms.LinkArea(1, 7)
		Me.llblclose.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblclose.Location = New System.Drawing.Point(688, 16)
		Me.llblclose.Name = "llblclose"
		Me.llblclose.Size = New System.Drawing.Size(91, 29)
		Me.llblclose.TabIndex = 4
		Me.llblclose.TabStop = True
		Me.llblclose.Text = "[ CLOSE ]"
		Me.llblclose.UseCompatibleTextRendering = True
		'
		'llblclear
		'
		Me.llblclear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblclear.AutoSize = True
		Me.llblclear.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblclear.LinkArea = New System.Windows.Forms.LinkArea(1, 7)
		Me.llblclear.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblclear.Location = New System.Drawing.Point(563, 16)
		Me.llblclear.Name = "llblclear"
		Me.llblclear.Size = New System.Drawing.Size(90, 29)
		Me.llblclear.TabIndex = 4
		Me.llblclear.TabStop = True
		Me.llblclear.Text = "[ CLEAR ]"
		Me.llblclear.UseCompatibleTextRendering = True
		'
		'llblregister
		'
		Me.llblregister.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.llblregister.AutoSize = True
		Me.llblregister.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.llblregister.LinkArea = New System.Windows.Forms.LinkArea(1, 10)
		Me.llblregister.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
		Me.llblregister.Location = New System.Drawing.Point(270, 16)
		Me.llblregister.Name = "llblregister"
		Me.llblregister.Size = New System.Drawing.Size(122, 29)
		Me.llblregister.TabIndex = 3
		Me.llblregister.TabStop = True
		Me.llblregister.Text = "[ ACTIVATE ]"
		Me.llblregister.UseCompatibleTextRendering = True
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.ForeColor = System.Drawing.Color.White
		Me.Label4.Location = New System.Drawing.Point(115, 103)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(107, 22)
		Me.Label4.TabIndex = 0
		Me.Label4.Text = "Username :"
		'
		'grpsec
		'
		Me.grpsec.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.grpsec.Controls.Add(Me.rbqa3)
		Me.grpsec.Controls.Add(Me.rbqa2)
		Me.grpsec.Controls.Add(Me.rbqa1)
		Me.grpsec.Controls.Add(Me.cboq1)
		Me.grpsec.Controls.Add(Me.Label7)
		Me.grpsec.Controls.Add(Me.cboa1)
		Me.grpsec.Controls.Add(Me.Label8)
		Me.grpsec.ForeColor = System.Drawing.Color.White
		Me.grpsec.Location = New System.Drawing.Point(43, 140)
		Me.grpsec.Name = "grpsec"
		Me.grpsec.Size = New System.Drawing.Size(746, 116)
		Me.grpsec.TabIndex = 4
		Me.grpsec.TabStop = False
		Me.grpsec.Text = "Account Recovery Question :"
		'
		'rbqa3
		'
		Me.rbqa3.AutoSize = True
		Me.rbqa3.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rbqa3.ForeColor = System.Drawing.Color.White
		Me.rbqa3.Location = New System.Drawing.Point(508, 22)
		Me.rbqa3.Name = "rbqa3"
		Me.rbqa3.Size = New System.Drawing.Size(154, 27)
		Me.rbqa3.TabIndex = 5
		Me.rbqa3.Text = "3. Security Q/A"
		Me.rbqa3.UseVisualStyleBackColor = True
		'
		'rbqa2
		'
		Me.rbqa2.AutoSize = True
		Me.rbqa2.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rbqa2.ForeColor = System.Drawing.Color.White
		Me.rbqa2.Location = New System.Drawing.Point(346, 22)
		Me.rbqa2.Name = "rbqa2"
		Me.rbqa2.Size = New System.Drawing.Size(154, 27)
		Me.rbqa2.TabIndex = 5
		Me.rbqa2.Text = "2. Security Q/A"
		Me.rbqa2.UseVisualStyleBackColor = True
		'
		'rbqa1
		'
		Me.rbqa1.AutoSize = True
		Me.rbqa1.Checked = True
		Me.rbqa1.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.rbqa1.ForeColor = System.Drawing.Color.White
		Me.rbqa1.Location = New System.Drawing.Point(183, 22)
		Me.rbqa1.Name = "rbqa1"
		Me.rbqa1.Size = New System.Drawing.Size(154, 27)
		Me.rbqa1.TabIndex = 5
		Me.rbqa1.TabStop = True
		Me.rbqa1.Text = "1. Security Q/A"
		Me.rbqa1.UseVisualStyleBackColor = True
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label7.ForeColor = System.Drawing.Color.White
		Me.Label7.Location = New System.Drawing.Point(81, 52)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(96, 22)
		Me.Label7.TabIndex = 0
		Me.Label7.Text = "Question :"
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.ForeColor = System.Drawing.Color.White
		Me.Label8.Location = New System.Drawing.Point(94, 81)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(83, 22)
		Me.Label8.TabIndex = 4
		Me.Label8.Text = "Answer :"
		'
		'userChecker
		'
		Me.userChecker.Interval = 500
		'
		'tfocus
		'
		Me.tfocus.Enabled = True
		Me.tfocus.Interval = 1000
		'
		'Panel2
		'
		Me.Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel2.Controls.Add(Me.gridUsers)
		Me.Panel2.Location = New System.Drawing.Point(2, 295)
		Me.Panel2.Name = "Panel2"
		Me.Panel2.Size = New System.Drawing.Size(802, 289)
		Me.Panel2.TabIndex = 5
		'
		'gridUsers
		'
		Me.gridUsers.AllowUserToAddRows = False
		Me.gridUsers.AllowUserToDeleteRows = False
		Me.gridUsers.AllowUserToResizeColumns = False
		Me.gridUsers.AllowUserToResizeRows = False
		Me.gridUsers.BackgroundColor = System.Drawing.Color.White
		Me.gridUsers.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
		Me.gridUsers.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 12.0!)
		DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.gridUsers.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
		Me.gridUsers.ColumnHeadersHeight = 36
		Me.gridUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.gridUsers.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
		DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 12.0!)
		DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.gridUsers.DefaultCellStyle = DataGridViewCellStyle2
		Me.gridUsers.Dock = System.Windows.Forms.DockStyle.Fill
		Me.gridUsers.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.gridUsers.EnableHeadersVisualStyles = False
		Me.gridUsers.Location = New System.Drawing.Point(0, 0)
		Me.gridUsers.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
		Me.gridUsers.MultiSelect = False
		Me.gridUsers.Name = "gridUsers"
		Me.gridUsers.ReadOnly = True
		Me.gridUsers.RowHeadersVisible = False
		Me.gridUsers.RowTemplate.Height = 30
		Me.gridUsers.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.gridUsers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.gridUsers.ShowCellErrors = False
		Me.gridUsers.ShowCellToolTips = False
		Me.gridUsers.ShowEditingIcon = False
		Me.gridUsers.ShowRowErrors = False
		Me.gridUsers.Size = New System.Drawing.Size(802, 289)
		Me.gridUsers.TabIndex = 2
		'
		'Column1
		'
		Me.Column1.HeaderText = "Select"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label5.ForeColor = System.Drawing.Color.White
		Me.Label5.Location = New System.Drawing.Point(69, 262)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(153, 22)
		Me.Label5.TabIndex = 0
		Me.Label5.Text = "Search Account :"
		'
		'cboq1
		'
		Me.cboq1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboq1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cboq1.FormattingEnabled = True
		Me.cboq1.Location = New System.Drawing.Point(183, 52)
		Me.cboq1.Name = "cboq1"
		Me.cboq1.Size = New System.Drawing.Size(551, 26)
		Me.cboq1.TabIndex = 0
		'
		'cboa1
		'
		Me.cboa1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.cboa1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.cboa1.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.cboa1.Location = New System.Drawing.Point(183, 81)
		Me.cboa1.MaxLength = 24
		Me.cboa1.Name = "cboa1"
		Me.cboa1.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9788)
		Me.cboa1.Size = New System.Drawing.Size(551, 27)
		Me.cboa1.TabIndex = 1
		'
		'txtusername
		'
		Me.txtusername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.txtusername.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtusername.Enabled = False
		Me.txtusername.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtusername.Location = New System.Drawing.Point(226, 103)
		Me.txtusername.MaxLength = 32
		Me.txtusername.Name = "txtusername"
		Me.txtusername.Size = New System.Drawing.Size(316, 27)
		Me.txtusername.TabIndex = 1
		'
		'txtsearch
		'
		Me.txtsearch.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.txtsearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtsearch.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtsearch.Location = New System.Drawing.Point(226, 262)
		Me.txtsearch.MaxLength = 145
		Me.txtsearch.Name = "txtsearch"
		Me.txtsearch.Size = New System.Drawing.Size(551, 27)
		Me.txtsearch.TabIndex = 0
		'
		'txtname
		'
		Me.txtname.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.txtname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
		Me.txtname.Font = New System.Drawing.Font("Tahoma", 12.0!)
		Me.txtname.Location = New System.Drawing.Point(226, 71)
		Me.txtname.MaxLength = 145
		Me.txtname.Name = "txtname"
		Me.txtname.Size = New System.Drawing.Size(551, 27)
		Me.txtname.TabIndex = 0
		'
		'vw_2_user_maintenance
		'
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.DimGray
		Me.ClientSize = New System.Drawing.Size(806, 640)
		Me.Controls.Add(Me.Panel2)
		Me.Controls.Add(Me.grpsec)
		Me.Controls.Add(Me.Panel1)
		Me.Controls.Add(Me.panelHeader)
		Me.Controls.Add(Me.txtusername)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.txtsearch)
		Me.Controls.Add(Me.txtname)
		Me.Controls.Add(Me.Label5)
		Me.Controls.Add(Me.Label1)
		Me.Font = New System.Drawing.Font("Arial", 12.0!)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_2_user_maintenance"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
		Me.Text = "REGISTRATION"
		Me.panelHeader.ResumeLayout(False)
		Me.panelHeader.PerformLayout()
		Me.Panel1.ResumeLayout(False)
		Me.Panel1.PerformLayout()
		Me.grpsec.ResumeLayout(False)
		Me.grpsec.PerformLayout()
		Me.Panel2.ResumeLayout(False)
		CType(Me.gridUsers, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents txtname As Label_System.modTextbox
	Friend WithEvents panelHeader As System.Windows.Forms.Panel
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents txtusername As Label_System.modTextbox
	Friend WithEvents grpsec As System.Windows.Forms.GroupBox
	Friend WithEvents cboq1 As Label_System.modComboBox
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents cboa1 As Label_System.modTextbox
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents llblregister As System.Windows.Forms.LinkLabel
	Friend WithEvents llblclear As System.Windows.Forms.LinkLabel
	Friend WithEvents llblclose As System.Windows.Forms.LinkLabel
	Friend WithEvents userChecker As System.Windows.Forms.Timer
	Friend WithEvents tfocus As System.Windows.Forms.Timer
	Friend WithEvents rbqa1 As System.Windows.Forms.RadioButton
	Friend WithEvents rbqa3 As System.Windows.Forms.RadioButton
	Friend WithEvents rbqa2 As System.Windows.Forms.RadioButton
	Friend WithEvents llbldelete As System.Windows.Forms.LinkLabel
	Friend WithEvents Panel2 As System.Windows.Forms.Panel
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents txtsearch As Label_System.modTextbox
	Friend WithEvents gridUsers As System.Windows.Forms.DataGridView
	Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
End Class
