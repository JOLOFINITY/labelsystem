﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class vw_3_labelInput
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(vw_3_labelInput))
		Me.pmain = New System.Windows.Forms.Panel()
		Me.Panel1 = New System.Windows.Forms.Panel()
		Me.griditemList = New System.Windows.Forms.DataGridView()
		Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.lblshelflife = New System.Windows.Forms.Label()
		Me.Label15 = New System.Windows.Forms.Label()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.lblshelflifeBy = New System.Windows.Forms.Label()
		Me.lblvalidity = New System.Windows.Forms.Label()
		Me.dtTimeIn = New System.Windows.Forms.DateTimePicker()
		Me.btnsave = New System.Windows.Forms.Button()
		Me.btnsavePrint = New System.Windows.Forms.Button()
		Me.lbldays = New System.Windows.Forms.Label()
		Me.lblproduction = New System.Windows.Forms.Label()
		Me.lblusedBy = New System.Windows.Forms.Label()
		Me.dateProduction = New System.Windows.Forms.DateTimePicker()
		Me.picNew = New System.Windows.Forms.PictureBox()
		Me.lblA = New System.Windows.Forms.Label()
		Me.lblD = New System.Windows.Forms.Label()
		Me.lblC = New System.Windows.Forms.Label()
		Me.lblB = New System.Windows.Forms.Label()
		Me.lblstorage = New System.Windows.Forms.Label()
		Me.lblJ = New System.Windows.Forms.Label()
		Me.lblI = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label17 = New System.Windows.Forms.Label()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.lblG = New System.Windows.Forms.Label()
		Me.lblF = New System.Windows.Forms.Label()
		Me.lblH = New System.Windows.Forms.Label()
		Me.lblunit = New System.Windows.Forms.Label()
		Me.lblE = New System.Windows.Forms.Label()
		Me.dtDate = New System.Windows.Forms.DateTimePicker()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.cboquantity = New Label_System.modComboBox()
		Me.cboremarks = New Label_System.modComboBox()
		Me.cboemployee = New Label_System.modComboBox()
		Me.cbomanager = New Label_System.modComboBox()
		Me.cbocondition = New Label_System.modComboBox()
		Me.cboitems = New Label_System.modComboBox()
		Me.pmain.SuspendLayout()
		Me.Panel1.SuspendLayout()
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.GroupBox1.SuspendLayout()
		CType(Me.picNew, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.SuspendLayout()
		'
		'pmain
		'
		Me.pmain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.pmain.BackColor = System.Drawing.Color.White
		Me.pmain.Controls.Add(Me.Panel1)
		Me.pmain.Controls.Add(Me.GroupBox1)
		Me.pmain.Location = New System.Drawing.Point(2, 2)
		Me.pmain.Name = "pmain"
		Me.pmain.Size = New System.Drawing.Size(944, 774)
		Me.pmain.TabIndex = 0
		'
		'Panel1
		'
		Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Panel1.Controls.Add(Me.griditemList)
		Me.Panel1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Panel1.Location = New System.Drawing.Point(3, 470)
		Me.Panel1.Name = "Panel1"
		Me.Panel1.Size = New System.Drawing.Size(938, 301)
		Me.Panel1.TabIndex = 15
		'
		'griditemList
		'
		Me.griditemList.AllowUserToAddRows = False
		Me.griditemList.AllowUserToDeleteRows = False
		Me.griditemList.AllowUserToResizeColumns = False
		Me.griditemList.AllowUserToResizeRows = False
		Me.griditemList.BackgroundColor = System.Drawing.Color.White
		Me.griditemList.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable
		Me.griditemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
		DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
		DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
		DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
		Me.griditemList.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
		Me.griditemList.ColumnHeadersHeight = 36
		Me.griditemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
		Me.griditemList.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1})
		DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
		DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
		DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial Narrow", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
		DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Firebrick
		DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Yellow
		DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
		Me.griditemList.DefaultCellStyle = DataGridViewCellStyle2
		Me.griditemList.Dock = System.Windows.Forms.DockStyle.Fill
		Me.griditemList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
		Me.griditemList.EnableHeadersVisualStyles = False
		Me.griditemList.Location = New System.Drawing.Point(0, 0)
		Me.griditemList.Margin = New System.Windows.Forms.Padding(2, 3, 2, 3)
		Me.griditemList.MultiSelect = False
		Me.griditemList.Name = "griditemList"
		Me.griditemList.ReadOnly = True
		Me.griditemList.RowHeadersVisible = False
		Me.griditemList.RowTemplate.Height = 28
		Me.griditemList.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.griditemList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.griditemList.ShowCellErrors = False
		Me.griditemList.ShowCellToolTips = False
		Me.griditemList.ShowEditingIcon = False
		Me.griditemList.ShowRowErrors = False
		Me.griditemList.Size = New System.Drawing.Size(938, 301)
		Me.griditemList.TabIndex = 0
		'
		'Column1
		'
		Me.Column1.HeaderText = "Select"
		Me.Column1.Name = "Column1"
		Me.Column1.ReadOnly = True
		'
		'GroupBox1
		'
		Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.GroupBox1.Controls.Add(Me.Label2)
		Me.GroupBox1.Controls.Add(Me.dtTimeIn)
		Me.GroupBox1.Controls.Add(Me.lblshelflife)
		Me.GroupBox1.Controls.Add(Me.Label15)
		Me.GroupBox1.Controls.Add(Me.Label3)
		Me.GroupBox1.Controls.Add(Me.Label5)
		Me.GroupBox1.Controls.Add(Me.Label6)
		Me.GroupBox1.Controls.Add(Me.Label7)
		Me.GroupBox1.Controls.Add(Me.Label10)
		Me.GroupBox1.Controls.Add(Me.lblshelflifeBy)
		Me.GroupBox1.Controls.Add(Me.lblvalidity)
		Me.GroupBox1.Controls.Add(Me.btnsave)
		Me.GroupBox1.Controls.Add(Me.btnsavePrint)
		Me.GroupBox1.Controls.Add(Me.lbldays)
		Me.GroupBox1.Controls.Add(Me.cboquantity)
		Me.GroupBox1.Controls.Add(Me.lblproduction)
		Me.GroupBox1.Controls.Add(Me.cboremarks)
		Me.GroupBox1.Controls.Add(Me.cboemployee)
		Me.GroupBox1.Controls.Add(Me.cbomanager)
		Me.GroupBox1.Controls.Add(Me.lblusedBy)
		Me.GroupBox1.Controls.Add(Me.dtDate)
		Me.GroupBox1.Controls.Add(Me.dateProduction)
		Me.GroupBox1.Controls.Add(Me.cbocondition)
		Me.GroupBox1.Controls.Add(Me.cboitems)
		Me.GroupBox1.Controls.Add(Me.picNew)
		Me.GroupBox1.Controls.Add(Me.lblA)
		Me.GroupBox1.Controls.Add(Me.lblC)
		Me.GroupBox1.Controls.Add(Me.lblB)
		Me.GroupBox1.Controls.Add(Me.lblstorage)
		Me.GroupBox1.Controls.Add(Me.lblJ)
		Me.GroupBox1.Controls.Add(Me.lblI)
		Me.GroupBox1.Controls.Add(Me.Label1)
		Me.GroupBox1.Controls.Add(Me.Label17)
		Me.GroupBox1.Controls.Add(Me.Label11)
		Me.GroupBox1.Controls.Add(Me.Label14)
		Me.GroupBox1.Controls.Add(Me.lblG)
		Me.GroupBox1.Controls.Add(Me.lblF)
		Me.GroupBox1.Controls.Add(Me.lblH)
		Me.GroupBox1.Controls.Add(Me.lblunit)
		Me.GroupBox1.Controls.Add(Me.lblE)
		Me.GroupBox1.Controls.Add(Me.Label4)
		Me.GroupBox1.Controls.Add(Me.lblD)
		Me.GroupBox1.Font = New System.Drawing.Font("MS Gothic", 1.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.GroupBox1.Location = New System.Drawing.Point(5, 3)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(934, 464)
		Me.GroupBox1.TabIndex = 0
		Me.GroupBox1.TabStop = False
		'
		'lblshelflife
		'
		Me.lblshelflife.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblshelflife.BackColor = System.Drawing.Color.Transparent
		Me.lblshelflife.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblshelflife.ForeColor = System.Drawing.Color.White
		Me.lblshelflife.Location = New System.Drawing.Point(667, 174)
		Me.lblshelflife.Name = "lblshelflife"
		Me.lblshelflife.Size = New System.Drawing.Size(102, 30)
		Me.lblshelflife.TabIndex = 41
		Me.lblshelflife.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label15
		'
		Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label15.BackColor = System.Drawing.Color.DimGray
		Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label15.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label15.ForeColor = System.Drawing.Color.White
		Me.Label15.Location = New System.Drawing.Point(89, 380)
		Me.Label15.Name = "Label15"
		Me.Label15.Size = New System.Drawing.Size(227, 30)
		Me.Label15.TabIndex = 25
		Me.Label15.Tag = "G"
		Me.Label15.Text = "REMARKS :"
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label3
		'
		Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label3.BackColor = System.Drawing.Color.DimGray
		Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label3.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label3.ForeColor = System.Drawing.Color.White
		Me.Label3.Location = New System.Drawing.Point(89, 340)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(227, 30)
		Me.Label3.TabIndex = 25
		Me.Label3.Tag = "G"
		Me.Label3.Text = "MANAGER :"
		Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label5
		'
		Me.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label5.BackColor = System.Drawing.Color.DimGray
		Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label5.ForeColor = System.Drawing.Color.White
		Me.Label5.Location = New System.Drawing.Point(89, 94)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(227, 29)
		Me.Label5.TabIndex = 10
		Me.Label5.Tag = "C"
		Me.Label5.Text = "PRODUCTION DATE :"
		Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label6
		'
		Me.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label6.BackColor = System.Drawing.Color.DimGray
		Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label6.ForeColor = System.Drawing.Color.White
		Me.Label6.Location = New System.Drawing.Point(89, 54)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(227, 30)
		Me.Label6.TabIndex = 11
		Me.Label6.Tag = "B"
		Me.Label6.Text = "CONDITION :"
		Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label4
		'
		Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label4.BackColor = System.Drawing.Color.DimGray
		Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label4.ForeColor = System.Drawing.Color.White
		Me.Label4.Location = New System.Drawing.Point(89, 134)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(227, 29)
		Me.Label4.TabIndex = 32
		Me.Label4.Tag = "C"
		Me.Label4.Text = "TIME IN :"
		Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label7
		'
		Me.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label7.BackColor = System.Drawing.Color.DimGray
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label7.ForeColor = System.Drawing.Color.White
		Me.Label7.Location = New System.Drawing.Point(89, 14)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(227, 30)
		Me.Label7.TabIndex = 12
		Me.Label7.Tag = "A"
		Me.Label7.Text = "ITEM :"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label10
		'
		Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label10.BackColor = System.Drawing.Color.DimGray
		Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label10.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label10.ForeColor = System.Drawing.Color.White
		Me.Label10.Location = New System.Drawing.Point(89, 174)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(227, 30)
		Me.Label10.TabIndex = 19
		Me.Label10.Tag = "E"
		Me.Label10.Text = "QUANTITY :"
		Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblshelflifeBy
		'
		Me.lblshelflifeBy.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblshelflifeBy.BackColor = System.Drawing.Color.Transparent
		Me.lblshelflifeBy.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblshelflifeBy.ForeColor = System.Drawing.Color.White
		Me.lblshelflifeBy.Location = New System.Drawing.Point(771, 174)
		Me.lblshelflifeBy.Name = "lblshelflifeBy"
		Me.lblshelflifeBy.Size = New System.Drawing.Size(152, 30)
		Me.lblshelflifeBy.TabIndex = 39
		Me.lblshelflifeBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblvalidity
		'
		Me.lblvalidity.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.lblvalidity.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.lblvalidity.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblvalidity.ForeColor = System.Drawing.Color.Lime
		Me.lblvalidity.Location = New System.Drawing.Point(65, 421)
		Me.lblvalidity.Name = "lblvalidity"
		Me.lblvalidity.Size = New System.Drawing.Size(600, 29)
		Me.lblvalidity.TabIndex = 29
		Me.lblvalidity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'dtTimeIn
		'
		Me.dtTimeIn.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.dtTimeIn.Checked = False
		Me.dtTimeIn.CustomFormat = "MM-dd-yyyy hh:mm tt"
		Me.dtTimeIn.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.dtTimeIn.Format = System.Windows.Forms.DateTimePickerFormat.Custom
		Me.dtTimeIn.Location = New System.Drawing.Point(317, 134)
		Me.dtTimeIn.MinDate = New Date(2020, 1, 29, 0, 0, 0, 0)
		Me.dtTimeIn.Name = "dtTimeIn"
		Me.dtTimeIn.Size = New System.Drawing.Size(238, 29)
		Me.dtTimeIn.TabIndex = 9
		Me.dtTimeIn.Tag = "D"
		Me.dtTimeIn.Value = New Date(2021, 8, 1, 7, 0, 0, 0)
		'
		'btnsave
		'
		Me.btnsave.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.btnsave.Enabled = False
		Me.btnsave.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnsave.ForeColor = System.Drawing.Color.Gray
		Me.btnsave.Location = New System.Drawing.Point(671, 419)
		Me.btnsave.Name = "btnsave"
		Me.btnsave.Size = New System.Drawing.Size(124, 34)
		Me.btnsave.TabIndex = 37
		Me.btnsave.Tag = "0"
		Me.btnsave.Text = "Save [F2]"
		Me.btnsave.UseVisualStyleBackColor = True
		'
		'btnsavePrint
		'
		Me.btnsavePrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.btnsavePrint.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.btnsavePrint.ForeColor = System.Drawing.Color.Blue
		Me.btnsavePrint.Location = New System.Drawing.Point(801, 419)
		Me.btnsavePrint.Name = "btnsavePrint"
		Me.btnsavePrint.Size = New System.Drawing.Size(122, 34)
		Me.btnsavePrint.TabIndex = 37
		Me.btnsavePrint.Tag = "1"
		Me.btnsavePrint.Text = "Clear [F5]"
		Me.btnsavePrint.UseVisualStyleBackColor = True
		'
		'lbldays
		'
		Me.lbldays.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lbldays.BackColor = System.Drawing.Color.DimGray
		Me.lbldays.Font = New System.Drawing.Font("Arial", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lbldays.ForeColor = System.Drawing.Color.White
		Me.lbldays.Location = New System.Drawing.Point(6, 13)
		Me.lbldays.Name = "lbldays"
		Me.lbldays.Size = New System.Drawing.Size(69, 398)
		Me.lbldays.TabIndex = 36
		Me.lbldays.Tag = ""
		Me.lbldays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'lblproduction
		'
		Me.lblproduction.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblproduction.BackColor = System.Drawing.Color.Transparent
		Me.lblproduction.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblproduction.ForeColor = System.Drawing.Color.Lime
		Me.lblproduction.Location = New System.Drawing.Point(555, 94)
		Me.lblproduction.Name = "lblproduction"
		Me.lblproduction.Size = New System.Drawing.Size(368, 29)
		Me.lblproduction.TabIndex = 29
		Me.lblproduction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblusedBy
		'
		Me.lblusedBy.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblusedBy.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
		Me.lblusedBy.Font = New System.Drawing.Font("Arial", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblusedBy.ForeColor = System.Drawing.Color.White
		Me.lblusedBy.Location = New System.Drawing.Point(317, 254)
		Me.lblusedBy.Name = "lblusedBy"
		Me.lblusedBy.Size = New System.Drawing.Size(606, 36)
		Me.lblusedBy.TabIndex = 17
		Me.lblusedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'dateProduction
		'
		Me.dateProduction.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.dateProduction.Checked = False
		Me.dateProduction.CustomFormat = "MM-dd-yyyy"
		Me.dateProduction.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.dateProduction.Format = System.Windows.Forms.DateTimePickerFormat.Custom
		Me.dateProduction.Location = New System.Drawing.Point(317, 94)
		Me.dateProduction.MinDate = New Date(2020, 1, 29, 0, 0, 0, 0)
		Me.dateProduction.Name = "dateProduction"
		Me.dateProduction.Size = New System.Drawing.Size(238, 29)
		Me.dateProduction.TabIndex = 2
		Me.dateProduction.Tag = "C"
		'
		'picNew
		'
		Me.picNew.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
		Me.picNew.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
		Me.picNew.Image = CType(resources.GetObject("picNew.Image"), System.Drawing.Image)
		Me.picNew.Location = New System.Drawing.Point(6, 413)
		Me.picNew.Name = "picNew"
		Me.picNew.Size = New System.Drawing.Size(49, 43)
		Me.picNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.picNew.TabIndex = 38
		Me.picNew.TabStop = False
		Me.picNew.Visible = False
		'
		'lblA
		'
		Me.lblA.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblA.BackColor = System.Drawing.Color.Black
		Me.lblA.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblA.ForeColor = System.Drawing.Color.White
		Me.lblA.Location = New System.Drawing.Point(87, 12)
		Me.lblA.Name = "lblA"
		Me.lblA.Size = New System.Drawing.Size(838, 34)
		Me.lblA.TabIndex = 16
		Me.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblD
		'
		Me.lblD.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblD.BackColor = System.Drawing.Color.Black
		Me.lblD.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblD.ForeColor = System.Drawing.Color.White
		Me.lblD.Location = New System.Drawing.Point(87, 132)
		Me.lblD.Name = "lblD"
		Me.lblD.Size = New System.Drawing.Size(470, 33)
		Me.lblD.TabIndex = 30
		Me.lblD.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblC
		'
		Me.lblC.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblC.BackColor = System.Drawing.Color.Black
		Me.lblC.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblC.ForeColor = System.Drawing.Color.White
		Me.lblC.Location = New System.Drawing.Point(87, 92)
		Me.lblC.Name = "lblC"
		Me.lblC.Size = New System.Drawing.Size(838, 33)
		Me.lblC.TabIndex = 14
		Me.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblB
		'
		Me.lblB.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblB.BackColor = System.Drawing.Color.Black
		Me.lblB.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblB.ForeColor = System.Drawing.Color.White
		Me.lblB.Location = New System.Drawing.Point(87, 52)
		Me.lblB.Name = "lblB"
		Me.lblB.Size = New System.Drawing.Size(838, 34)
		Me.lblB.TabIndex = 15
		Me.lblB.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblstorage
		'
		Me.lblstorage.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblstorage.BackColor = System.Drawing.Color.Transparent
		Me.lblstorage.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblstorage.ForeColor = System.Drawing.Color.Lime
		Me.lblstorage.Location = New System.Drawing.Point(317, 214)
		Me.lblstorage.Name = "lblstorage"
		Me.lblstorage.Size = New System.Drawing.Size(606, 30)
		Me.lblstorage.TabIndex = 39
		Me.lblstorage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblJ
		'
		Me.lblJ.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblJ.BackColor = System.Drawing.Color.Black
		Me.lblJ.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblJ.ForeColor = System.Drawing.Color.White
		Me.lblJ.Location = New System.Drawing.Point(87, 378)
		Me.lblJ.Name = "lblJ"
		Me.lblJ.Size = New System.Drawing.Size(838, 34)
		Me.lblJ.TabIndex = 26
		Me.lblJ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblI
		'
		Me.lblI.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblI.BackColor = System.Drawing.Color.Black
		Me.lblI.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblI.ForeColor = System.Drawing.Color.White
		Me.lblI.Location = New System.Drawing.Point(87, 338)
		Me.lblI.Name = "lblI"
		Me.lblI.Size = New System.Drawing.Size(838, 34)
		Me.lblI.TabIndex = 26
		Me.lblI.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label1
		'
		Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label1.BackColor = System.Drawing.Color.White
		Me.Label1.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.ForeColor = System.Drawing.Color.White
		Me.Label1.Location = New System.Drawing.Point(5, 12)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(71, 400)
		Me.Label1.TabIndex = 40
		Me.Label1.Tag = ""
		Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label17
		'
		Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label17.BackColor = System.Drawing.Color.DimGray
		Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label17.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label17.ForeColor = System.Drawing.Color.White
		Me.Label17.Location = New System.Drawing.Point(89, 300)
		Me.Label17.Name = "Label17"
		Me.Label17.Size = New System.Drawing.Size(227, 30)
		Me.Label17.TabIndex = 25
		Me.Label17.Tag = "G"
		Me.Label17.Text = "EMPLOYEE :"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label11
		'
		Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label11.BackColor = System.Drawing.Color.DimGray
		Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label11.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label11.ForeColor = System.Drawing.Color.White
		Me.Label11.Location = New System.Drawing.Point(89, 254)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(227, 36)
		Me.Label11.TabIndex = 34
		Me.Label11.Tag = "C"
		Me.Label11.Text = "USE BY ( UNTIL ) :"
		Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'Label14
		'
		Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label14.BackColor = System.Drawing.Color.DimGray
		Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label14.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label14.ForeColor = System.Drawing.Color.White
		Me.Label14.Location = New System.Drawing.Point(89, 214)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(227, 30)
		Me.Label14.TabIndex = 25
		Me.Label14.Tag = "G"
		Me.Label14.Text = "STORAGE :"
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblG
		'
		Me.lblG.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblG.BackColor = System.Drawing.Color.Black
		Me.lblG.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblG.ForeColor = System.Drawing.Color.White
		Me.lblG.Location = New System.Drawing.Point(87, 252)
		Me.lblG.Name = "lblG"
		Me.lblG.Size = New System.Drawing.Size(838, 40)
		Me.lblG.TabIndex = 33
		Me.lblG.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblF
		'
		Me.lblF.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblF.BackColor = System.Drawing.Color.White
		Me.lblF.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblF.ForeColor = System.Drawing.Color.White
		Me.lblF.Location = New System.Drawing.Point(87, 212)
		Me.lblF.Name = "lblF"
		Me.lblF.Size = New System.Drawing.Size(838, 34)
		Me.lblF.TabIndex = 26
		Me.lblF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblH
		'
		Me.lblH.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblH.BackColor = System.Drawing.Color.Black
		Me.lblH.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblH.ForeColor = System.Drawing.Color.White
		Me.lblH.Location = New System.Drawing.Point(87, 298)
		Me.lblH.Name = "lblH"
		Me.lblH.Size = New System.Drawing.Size(838, 34)
		Me.lblH.TabIndex = 26
		Me.lblH.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'lblunit
		'
		Me.lblunit.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblunit.BackColor = System.Drawing.Color.Transparent
		Me.lblunit.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblunit.ForeColor = System.Drawing.Color.White
		Me.lblunit.Location = New System.Drawing.Point(494, 174)
		Me.lblunit.Name = "lblunit"
		Me.lblunit.Size = New System.Drawing.Size(171, 30)
		Me.lblunit.TabIndex = 39
		Me.lblunit.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		'
		'lblE
		'
		Me.lblE.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.lblE.BackColor = System.Drawing.Color.Black
		Me.lblE.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.lblE.ForeColor = System.Drawing.Color.White
		Me.lblE.Location = New System.Drawing.Point(87, 172)
		Me.lblE.Name = "lblE"
		Me.lblE.Size = New System.Drawing.Size(838, 34)
		Me.lblE.TabIndex = 20
		Me.lblE.TextAlign = System.Drawing.ContentAlignment.MiddleRight
		'
		'dtDate
		'
		Me.dtDate.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.dtDate.Checked = False
		Me.dtDate.CustomFormat = "MM-dd-yyyy"
		Me.dtDate.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.dtDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
		Me.dtDate.Location = New System.Drawing.Point(317, 134)
		Me.dtDate.MinDate = New Date(2020, 1, 29, 0, 0, 0, 0)
		Me.dtDate.Name = "dtDate"
		Me.dtDate.Size = New System.Drawing.Size(238, 29)
		Me.dtDate.TabIndex = 2
		Me.dtDate.Tag = "D"
		'
		'Label2
		'
		Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.Label2.BackColor = System.Drawing.Color.Transparent
		Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.Label2.ForeColor = System.Drawing.Color.White
		Me.Label2.Location = New System.Drawing.Point(667, 140)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(171, 29)
		Me.Label2.TabIndex = 32
		Me.Label2.Tag = "C"
		Me.Label2.Text = "SHELFLIFE"
		Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'cboquantity
		'
		Me.cboquantity.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboquantity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboquantity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboquantity.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboquantity.FormattingEnabled = True
		Me.cboquantity.Location = New System.Drawing.Point(317, 174)
		Me.cboquantity.Name = "cboquantity"
		Me.cboquantity.Size = New System.Drawing.Size(174, 30)
		Me.cboquantity.TabIndex = 5
		Me.cboquantity.Tag = "E"
		'
		'cboremarks
		'
		Me.cboremarks.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboremarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboremarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboremarks.DropDownHeight = 400
		Me.cboremarks.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboremarks.FormattingEnabled = True
		Me.cboremarks.IntegralHeight = False
		Me.cboremarks.Location = New System.Drawing.Point(317, 380)
		Me.cboremarks.Name = "cboremarks"
		Me.cboremarks.Size = New System.Drawing.Size(606, 30)
		Me.cboremarks.TabIndex = 12
		Me.cboremarks.Tag = "J"
		'
		'cboemployee
		'
		Me.cboemployee.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboemployee.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboemployee.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboemployee.DropDownHeight = 400
		Me.cboemployee.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboemployee.FormattingEnabled = True
		Me.cboemployee.IntegralHeight = False
		Me.cboemployee.Location = New System.Drawing.Point(317, 300)
		Me.cboemployee.Name = "cboemployee"
		Me.cboemployee.Size = New System.Drawing.Size(606, 30)
		Me.cboemployee.TabIndex = 10
		Me.cboemployee.Tag = "H"
		'
		'cbomanager
		'
		Me.cbomanager.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbomanager.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbomanager.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbomanager.DropDownHeight = 400
		Me.cbomanager.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbomanager.FormattingEnabled = True
		Me.cbomanager.IntegralHeight = False
		Me.cbomanager.Location = New System.Drawing.Point(317, 340)
		Me.cbomanager.Name = "cbomanager"
		Me.cbomanager.Size = New System.Drawing.Size(606, 30)
		Me.cbomanager.TabIndex = 11
		Me.cbomanager.Tag = "I"
		'
		'cbocondition
		'
		Me.cbocondition.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cbocondition.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cbocondition.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cbocondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.cbocondition.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cbocondition.FormattingEnabled = True
		Me.cbocondition.Location = New System.Drawing.Point(317, 54)
		Me.cbocondition.Name = "cbocondition"
		Me.cbocondition.Size = New System.Drawing.Size(606, 30)
		Me.cbocondition.TabIndex = 1
		Me.cbocondition.Tag = "B"
		'
		'cboitems
		'
		Me.cboitems.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.cboitems.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
		Me.cboitems.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
		Me.cboitems.DropDownHeight = 400
		Me.cboitems.Font = New System.Drawing.Font("Arial", 14.25!)
		Me.cboitems.FormattingEnabled = True
		Me.cboitems.IntegralHeight = False
		Me.cboitems.Location = New System.Drawing.Point(317, 14)
		Me.cboitems.Name = "cboitems"
		Me.cboitems.Size = New System.Drawing.Size(606, 30)
		Me.cboitems.TabIndex = 0
		Me.cboitems.Tag = "A"
		'
		'vw_3_labelInput
		'
		Me.AcceptButton = Me.btnsave
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
		Me.BackColor = System.Drawing.Color.RoyalBlue
		Me.ClientSize = New System.Drawing.Size(948, 778)
		Me.Controls.Add(Me.pmain)
		Me.Font = New System.Drawing.Font("MS Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
		Me.Margin = New System.Windows.Forms.Padding(4)
		Me.Name = "vw_3_labelInput"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "ITEM / PRODUCT MASTER"
		Me.pmain.ResumeLayout(False)
		Me.Panel1.ResumeLayout(False)
		CType(Me.griditemList, System.ComponentModel.ISupportInitialize).EndInit()
		Me.GroupBox1.ResumeLayout(False)
		CType(Me.picNew, System.ComponentModel.ISupportInitialize).EndInit()
		Me.ResumeLayout(False)

	End Sub
	Friend WithEvents pmain As System.Windows.Forms.Panel
	Friend WithEvents cboitems As modComboBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents cbocondition As modComboBox
	Friend WithEvents dateProduction As System.Windows.Forms.DateTimePicker
	Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
	Friend WithEvents lblC As System.Windows.Forms.Label
	Friend WithEvents lblB As System.Windows.Forms.Label
	Friend WithEvents lblA As System.Windows.Forms.Label
	Friend WithEvents lblusedBy As System.Windows.Forms.Label
	Friend WithEvents lblE As System.Windows.Forms.Label
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents lblF As System.Windows.Forms.Label
	Friend WithEvents Label14 As System.Windows.Forms.Label
	Friend WithEvents Panel1 As System.Windows.Forms.Panel
	Friend WithEvents griditemList As System.Windows.Forms.DataGridView
	Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
	Friend WithEvents lblproduction As System.Windows.Forms.Label
	Friend WithEvents lblD As System.Windows.Forms.Label
	Friend WithEvents cboquantity As modComboBox
	Friend WithEvents lblG As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents dtTimeIn As System.Windows.Forms.DateTimePicker
	Friend WithEvents Label11 As System.Windows.Forms.Label
	Friend WithEvents lblJ As System.Windows.Forms.Label
	Friend WithEvents lblH As System.Windows.Forms.Label
	Friend WithEvents lblI As System.Windows.Forms.Label
	Friend WithEvents Label15 As System.Windows.Forms.Label
	Friend WithEvents Label17 As System.Windows.Forms.Label
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents cboremarks As modComboBox
	Friend WithEvents cboemployee As modComboBox
	Friend WithEvents cbomanager As modComboBox
	Friend WithEvents lbldays As System.Windows.Forms.Label
	Friend WithEvents btnsave As Button
	Friend WithEvents btnsavePrint As System.Windows.Forms.Button
	Friend WithEvents picNew As System.Windows.Forms.PictureBox
	Friend WithEvents lblvalidity As System.Windows.Forms.Label
	Friend WithEvents lblshelflifeBy As System.Windows.Forms.Label
	Friend WithEvents lblstorage As System.Windows.Forms.Label
	Friend WithEvents lblunit As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents lblshelflife As System.Windows.Forms.Label
	Friend WithEvents dtDate As System.Windows.Forms.DateTimePicker
	Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
