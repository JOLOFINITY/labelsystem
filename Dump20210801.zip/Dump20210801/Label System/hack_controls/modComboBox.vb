﻿Public Class modComboBox
	Inherits ComboBox

	Public Sub New()
		
	End Sub

	Private Sub modComboBox_Enter(sender As Object, e As EventArgs) Handles Me.Enter
		Me.BackColor = Color.LightPink
	End Sub

	Private Sub modComboBox_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
		If sender.Tag = "DECIMAL" Then
			Dim DecimalSeparator As String = Application.CurrentCulture.NumberFormat.NumberDecimalSeparator
			e.Handled = Not (Char.IsDigit(e.KeyChar) Or
				Asc(e.KeyChar) = 8 Or
				(e.KeyChar = DecimalSeparator And sender.Text.IndexOf(DecimalSeparator) = -1))
		End If
	End Sub

	Private Sub modComboBox_Layout(sender As Object, e As LayoutEventArgs) Handles Me.Layout

	End Sub

	Private Sub modComboBox_Leave(sender As Object, e As EventArgs) Handles Me.Leave
		BackColor = Color.White
	End Sub

	Protected Overrides Sub Finalize()
		MyBase.Finalize()
	End Sub
End Class
